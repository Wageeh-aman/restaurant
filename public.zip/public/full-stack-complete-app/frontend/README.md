# 🍽️ Savoria — Full-Stack Complete App: Frontend

The complete customer-facing site, wired live to the backend API: dynamic menu, shopping cart, checkout, table reservations, and full authentication (login/register/logout) with role-aware navigation.

## 📁 Structure

```
frontend/
├── index.html          # Main site — live menu, cart, checkout, reservations
├── login.html            # Login page
├── register.html          # Registration page
├── forgot-password.html    # Request a password reset link
├── reset-password.html      # Set a new password (consumes ?token= from the email/dev link)
├── my-orders.html             # Logged-in customer's order history
├── track-order.html            # Guest/customer order tracking by order # + phone
├── admin.html                    # Staff/admin panel — manage orders & reservations
├── privacy.html            # Privacy policy
├── terms.html                # Terms of service
├── cookies.html                # Cookie policy
├── css/
│   ├── styles.css                # "Ember" design system (light + dark) + cart/auth additions
│   └── i18n.css                 # Language switcher, Arabic typography, RTL adjustments
├── js/
│   ├── api.js                      # Fetch wrapper + token/session management
│   ├── app.js                       # Menu rendering, cart, checkout, reservations, auth nav
│   ├── content.js                    # Website content loader (texts, images, reviews)
│   ├── admin.js                      # Site Management panel logic
│   ├── admin-content.js               # Website Content Management tools
│   ├── theme.js                      # Dark/light toggle + scroll-to-top
│   ├── i18n.js                       # Translation engine (t(), apply, setLang, dir/lang)
│   ├── lang-switcher.js               # The language control in the navbar
│   └── locales/
│       ├── en.js                       # English reference dictionary
│       └── ar.js                       # Arabic dictionary (same key tree)
├── assets/
│   ├── logo.svg                    # Monogram + wordmark
│   ├── favicon.svg
│   └── banner.svg
└── requirements.txt
```

## 🌍 Languages (Arabic / English)

The site speaks **Arabic and English**. The visitor picks the language with the
control in the navbar — the site is never forced into either language, and
the English version stays the default until the visitor chooses otherwise.

### The switcher

`js/lang-switcher.js` builds the control once and inserts it into the existing
navbar (inside `.nav-cta`, or next to the theme toggle on the small auth
pages). It reuses the navbar's own design language — same cream colour, same
hairline border, same 38px control height, same rounded shape as the theme
toggle — so the bar is not redesigned. The globe button shows the current
language (`English` / `العربية`); the dropdown lists both, with a check mark
on the active one. Below 1080px the button falls back to its short code
(`EN` / `ع`) so the logo and the menu keep their space.

Switching happens **instantly, without a page reload**: the engine
re-translates the DOM, flips the document direction, and notifies every
module, so the menu cards, the cart, the tables and the admin panel are
re-rendered in the new language.

### How the translation layer works

`js/i18n.js` is a small dependency-free engine (the project has no build
step, so a library could not be bundled):

| Piece | Purpose |
|---|---|
| `SavoriaI18n.t('key', {params})` | Translate a key, with `{placeholder}` interpolation and `a \| b` plural forms |
| `data-i18n="nav.home"` | Element text |
| `data-i18n-html="cart.emptyHtml"` | Element HTML (markup allowed) |
| `data-i18n-attr="placeholder:form.x"` | Attribute bindings |
| `SavoriaI18n.setLang(lang)` | Switch language, persist, update `lang`/`dir`, notify listeners |
| `SavoriaI18n.onChange(fn)` | React to a language switch |
| `SavoriaI18n.localize(row, 'name')` | Pick the right language out of a database row |

The dictionaries live in `js/locales/en.js` and `js/locales/ar.js` and share
one key tree, so a missing translation is easy to spot and always falls back
to English. The English copy of every element is remembered on the first
pass, so a key that was never translated shows the shipped text instead of a
raw key.

### The choice is remembered

The selected language is stored in `localStorage` under `savoria_lang` and
restored on the next visit — on the public pages and in the admin panel
alike. Until the visitor picks a language, the site's existing default
(English) is used; the browser language is never applied automatically and
never overrides an explicit choice.

### Right-to-left

`dir="rtl"` and `lang="ar"` are set on `<html>` (by an inline script in
`<head>`, before the first paint, so there is no flash of the wrong
direction). Flexbox, grid and logical text alignment flip automatically;
`css/i18n.css` mirrors the handful of elements that are positioned with
physical `left`/`right` properties (the hero accents, the menu badge, the
cart drawer, the scroll-to-top button, the toast stack, the tables, the
toggle switches …). Phone numbers, e-mail addresses and URLs keep their own
left-to-right direction inside the Arabic layout.

### Typography

English keeps the existing identity untouched (Playfair Display + Inter).
Arabic uses **IBM Plex Sans Arabic** for the body copy — it sits next to
Inter in the same humanist-sans family — and **Cairo** for the display
headings. Both are downloaded from Google Fonts **only when Arabic is
selected**, so English visitors pay nothing.

### Translating the database content

Menu items, categories, reviews and the website texts live in the database.
Each of them keeps its original English column untouched and gains an
`_ar` companion column, so nothing that already exists is modified and a
missing translation simply falls back to the English value. See
`../backend/README.md` and `database/add_multilanguage_support.sql`.

## 🔢 Calories

A dish can carry a calorie value, edited in **Site Management → Menu &
Categories → Edit**. The value joins the existing muted label of the menu
card ("Starters · 420 kcal") instead of adding a new element, so the card
keeps exactly the same structure and spacing — and nothing shows at all
when a dish has no published value.

## 🖼️ Changing the pictures

Two places in the panel, both without touching the public layout:

- **Website Content → Website Images** — one card per picture slot (logo,
  hero, story, gallery) with an *Upload new* button. Each card previews the
  picture **in the exact ratio of its slot** (400×400, 1000×1250, 700×700,
  900×1125, 800×600), so the manager sees the real shape before saving.
- **Menu & Categories → Image** — a button on every dish row opens a small
  dialog with the current picture, an *Upload file* button and a URL field.

Either way the picture is cropped **on the server** to the exact aspect
ratio of the container it lives in (4:3 for the menu cards, 3:2 for the
categories, 4:5 for the hero and story frames, 1:1 for the logo and the
square accents), so the result looks exactly like the shipped one — no
stretching, no letterboxing, no change to the design.

## 🌗 Light & Dark Mode

Every page ships with a theme toggle (sun/moon icon in the navbar). The chosen theme is saved to `localStorage` under `savoria_theme`, defaults to the visitor's OS preference on first visit, and is applied via an inline script in `<head>` before first paint — no flash of the wrong theme on load. Brand-dark sections (hero, footer, reservation banner, auth pages) stay charcoal in both themes by design; only page surfaces, cards, and text invert.

## ▶️ Running Locally

1. **Start the backend first** (see `../backend/README.md`):
   ```bash
   cd ../backend
   php -S localhost:8000 index.php
   ```
2. **Serve this frontend:**
   ```bash
   python3 -m http.server 8080
   ```
3. Visit `http://localhost:8080`.

If you run the backend on a different host/port, update `BASE_URL` at the top of `js/api.js`.

## ✨ What's Wired to the Backend

| Feature | API Calls |
|---|---|
| Menu grid | `GET /categories`, `GET /menu-items` |
| Add to cart / checkout | `POST /orders` |
| Reservation form | `POST /reservations` |
| Login | `POST /auth/login` |
| Register | `POST /auth/register` |
| Account dropdown | `GET /auth/me` (via stored token), `POST /auth/logout` |

Session state (JWT + user info) is kept in `localStorage` under `savoria_token` / `savoria_user`, read and written entirely by `js/api.js`.

## 🗂️ Website Content (managed from the admin panel)

The public pages do not hard-code their copy. `js/content.js` fetches `GET /site-content` and applies it to the elements that carry a `data-content` / `data-content-img` attribute:

```html
<h2 data-content="about_title">A kitchen built on craft, not shortcuts.</h2>
<img src="assets/logo.svg" alt="Tarmez" data-content-img="logo">
```

- The shipped text stays in the HTML — it is only replaced when a manager saved a different value, so a missing API or an empty database changes nothing on screen.
- `data-content-attr="href"` binds a value to an attribute instead of the text (the footer social links).
- The homepage reviews are rendered from the `reviews` table into the same slider markup, and the slider is rebuilt through `window.SavoriaApp.initTestimonials()`.
- Content is revalidated when the visitor returns to the tab (weak ETag), so edits appear without a manual reload.
- The payload carries the English **and** the Arabic texts (`settings` / `settings_ar`), so a language switch swaps the copy instantly without another request.

## 🛒 Cart & Checkout Flow

1. Items are added client-side into an in-memory cart (`js/app.js`).
2. The cart drawer shows running quantities and a live total.
3. On **Place Order**, the cart is sent to `POST /orders` — the backend recalculates every price server-side and returns the authoritative total.
4. If the visitor is logged in, their JWT is automatically attached so the order is linked to their account (visible later via `GET /my/orders`); guests can still check out without an account.

## 🔗 Where This Fits

This is the frontend half of the full-stack build. See `../backend/README.md` for the API it depends on, and the root [README](../../README.md) for how this fits with Projects 1–4.
