<?php
/**
 * Savoria — Full Stack Complete App
 * backend/lib/i18n.php — multi-language helpers for the REST API.
 *
 * The API never changes its contract: routes, field names and status
 * codes stay exactly as they were. Translations are added alongside
 * the original values, so a client that does not know about languages
 * keeps working untouched.
 *
 * Two mechanisms live here:
 *
 *   1. Content that exists in the database (menu items, categories,
 *      reviews, website texts) gains an "_ar" companion column. The
 *      original English column is never modified, so the current data
 *      stays intact and a missing translation simply falls back to it.
 *
 *   2. Requests may carry ?lang=ar (the frontend always sends the
 *      visitor's choice). The language is only used to decide what the
 *      server answers with — the payloads contain both languages
 *      wherever it makes sense, so the page can switch instantly
 *      without another round trip.
 *
 * The helpers below check whether the optional columns exist before
 * they are used, so the API keeps working on a database that has not
 * received the multi-language migration yet.
 */

declare(strict_types=1);

const I18N_DEFAULT_LANG  = 'en';
const I18N_SUPPORTED_LANGS = ['en', 'ar'];
const I18N_RTL_LANGS     = ['ar'];

/** Every language the platform currently speaks. */
function i18n_supported_languages(): array
{
    return I18N_SUPPORTED_LANGS;
}

/**
 * The language of the current request.
 * Order: explicit ?lang= → Accept-Language → the site default (English).
 */
function i18n_requested_language(): string
{
    static $resolved = null;
    if ($resolved !== null) return $resolved;

    $requested = strtolower(trim((string) ($_GET['lang'] ?? '')));
    if (in_array($requested, I18N_SUPPORTED_LANGS, true)) {
        $resolved = $requested;
        return $resolved;
    }

    $header = (string) ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '');
    foreach (explode(',', $header) as $part) {
        $code = strtolower(trim(explode(';', $part)[0]));
        if ($code === '') continue;
        $short = substr($code, 0, 2);
        if (in_array($short, I18N_SUPPORTED_LANGS, true)) {
            $resolved = $short;
            return $resolved;
        }
    }

    $resolved = I18N_DEFAULT_LANG;
    return $resolved;
}

/** Is the given (or current) language written right-to-left? */
function i18n_is_rtl(?string $lang = null): bool
{
    return in_array($lang ?? i18n_requested_language(), I18N_RTL_LANGS, true);
}

/*
 * Schema cache: information_schema lookups are slow and were the main
 * cost of the public endpoints, so the column list of the whole database
 * is read in one query and shared between requests through a small file
 * for SCHEMA_CACHE_TTL seconds. Columns added by the code itself go
 * through schema_ensure_column(), which clears the cache immediately.
 */
const SCHEMA_CACHE_TTL = 300;

function schema_cache_file(): string
{
    $id = md5(__DIR__ . '|' . env('DB_HOST', '') . '|' . env('DB_PORT', '') . '|' . env('DB_NAME', ''));
    return rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'savoria_schema_' . $id . '.json';
}

/** table => [column => true], or null when the cache must be rebuilt. */
function &schema_cache_state(): ?array
{
    static $tables = null;
    return $tables;
}

function schema_tables(PDO $pdo): array
{
    $tables = &schema_cache_state();
    if ($tables !== null) return $tables;

    $file = schema_cache_file();
    $raw = @file_get_contents($file);
    if ($raw !== false) {
        $cached = json_decode($raw, true);
        if (is_array($cached) && ($cached['expires'] ?? 0) > time() && is_array($cached['tables'] ?? null)) {
            return $tables = $cached['tables'];
        }
    }

    try {
        $stmt = $pdo->query(
            'SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()'
        );
        $fresh = [];
        foreach ($stmt->fetchAll(PDO::FETCH_NUM) as [$table, $column]) {
            $fresh[strtolower($table)][strtolower($column)] = true;
        }
    } catch (Throwable $e) {
        return [];
    }

    $tmp = $file . '.' . getmypid() . '.' . mt_rand() . '.tmp';
    if (@file_put_contents($tmp, json_encode(['expires' => time() + SCHEMA_CACHE_TTL, 'tables' => $fresh])) !== false) {
        if (!@rename($tmp, $file)) @unlink($tmp);
    }

    return $tables = $fresh;
}

function schema_cache_forget(): void
{
    $tables = &schema_cache_state();
    $tables = null;
    @unlink(schema_cache_file());
}

function schema_table_exists(PDO $pdo, string $table): bool
{
    return isset(schema_tables($pdo)[strtolower($table)]);
}

/**
 * Adds a missing column with the given ALTER statement and reports
 * whether the column exists afterwards (also true when another request
 * added it first).
 */
function schema_ensure_column(PDO $pdo, string $table, string $column, string $alterSql): bool
{
    if (i18n_column_exists($pdo, $table, $column)) return true;
    try {
        $pdo->exec($alterSql);
    } catch (Throwable $e) {
    }
    schema_cache_forget();
    return i18n_column_exists($pdo, $table, $column);
}

/** Does the given table have the given column? */
function i18n_column_exists(PDO $pdo, string $table, string $column): bool
{
    return isset(schema_tables($pdo)[strtolower($table)][strtolower($column)]);
}

/**
 * The SQL column list for a set of fields, adding the "_ar" companion
 * column of every field that has one in the database.
 * Example: ['id', 'name', 'description'] → "id, name, name_ar, description, description_ar"
 */
function i18n_select_list(PDO $pdo, string $table, array $fields, string $alias = ''): string
{
    $prefix = $alias !== '' ? $alias . '.' : '';
    $columns = [];
    foreach ($fields as $field) {
        $columns[] = $prefix . $field;
        if (i18n_column_exists($pdo, $table, $field . '_ar')) {
            $columns[] = $prefix . $field . '_ar';
        }
    }
    return implode(', ', $columns);
}

/**
 * The list of fields that can carry a translated value in a table
 * (only the ones whose "_ar" column really exists).
 */
function i18n_translatable_fields(PDO $pdo, string $table, array $fields): array
{
    $out = [];
    foreach ($fields as $field) {
        if (i18n_column_exists($pdo, $table, $field . '_ar')) $out[] = $field;
    }
    return $out;
}

/** Clean an incoming translated value (no HTML, trimmed). */
function i18n_clean_text($value): string
{
    return trim(strip_tags((string) $value));
}

/**
 * Keep only the translated fields of a payload that the table can
 * actually store, so an unknown key can never reach the SQL statement.
 *
 * The payload and the column use the same name ("name" → "name_ar"),
 * which is what the API returns and what the panel sends.
 */
function i18n_pick_translated(PDO $pdo, string $table, array $fields, array $payload): array
{
    $out = [];
    foreach (i18n_translatable_fields($pdo, $table, $fields) as $field) {
        $key = $field . '_ar';
        if (array_key_exists($key, $payload)) {
            $out[$key] = i18n_clean_text($payload[$key]);
        }
    }
    return $out;
}

/**
 * The same map with PDO-style ":name" placeholders, ready to be
 * merged into a statement's parameter list.
 */
function i18n_bind_params(array $translatable): array
{
    $out = [];
    foreach ($translatable as $column => $value) {
        $out[':' . $column] = $value;
    }
    return $out;
}
