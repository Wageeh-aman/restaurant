<?php
/**
 * Savoria — Full-Stack Complete App
 * lib/loyalty.php — customer loyalty & points engine
 *
 * Guarantees:
 *   • Ledger-based: balances live in loyalty_transactions rows that are
 *     never edited or deleted; corrections happen through new rows.
 *   • Double-count safe: an order can accrue points at most once —
 *     FOR UPDATE row locks AND the generated order_op_key unique index
 *     guard this, so a race or a retried request can never double-earn.
 *   • Never negative: every mutation re-checks the balance after locking
 *     the account row inside the same transaction.
 *   • Deferred accrual (historical/admin balance engine): points were earned
 *     only when an order reached "delivered" and reversed on cancellation.
 *     The storefront checkout no longer uses balances — it applies an
 *     instant per-bill discount through loyalty_calculate_instant_discount(),
 *     driven by the same live settings and with no phone involvement.
 *   • Rule-driven: amounts/thresholds come from loyalty_settings, which
 *     super admins edit at runtime. Historic rows keep their values.
 */

declare(strict_types=1);

/* =========================================================
   Settings
   ========================================================= */

function loyalty_get_settings(PDO $pdo): array
{
    $stmt = $pdo->prepare('SELECT * FROM loyalty_settings WHERE id = 1');
    $stmt->execute();
    $row = $stmt->fetch();
    if (!$row) {
        $pdo->exec('INSERT IGNORE INTO loyalty_settings (id) VALUES (1)');
        $row = loyalty_get_settings($pdo);
        return $row;
    }
    $row['id'] = (int) $row['id'];
    $row['enabled'] = (bool) $row['enabled'];
    $row['earn_amount_per_point'] = (float) $row['earn_amount_per_point'];
    $row['earn_min_order_amount'] = (float) $row['earn_min_order_amount'];
    $row['redeem_min_points'] = (int) $row['redeem_min_points'];
    $row['redeem_point_value'] = (float) $row['redeem_point_value'];
    $row['vat_rate'] = isset($row['vat_rate']) ? (float) $row['vat_rate'] : 15.00;
    $row['updated_by'] = $row['updated_by'] !== null ? (int) $row['updated_by'] : null;
    return $row;
}

/* =========================================================
   Instant, per-bill loyalty (storefront checkout)
   ---------------------------------------------------------
   The storefront does NOT keep a phone-keyed balance anymore.
   Every bill is evaluated on its own against the live settings:

     earned   = floor(bill / earn_amount_per_point)   (bill >= min order)
     discount = earned × redeem_point_value           (earned >= min points)

   No login, no phone, no stored balance. The server recomputes
   this exact figure inside the order transaction, so the cart is
   only a preview and the client can never dictate the discount.
   ========================================================= */

function loyalty_calculate_instant_discount(PDO $pdo, float $billAmount): array
{
    $settings = loyalty_get_settings($pdo);
    $bill = max(0.0, round($billAmount, 2));

    $enabled   = (bool) $settings['enabled'];
    $earnRate  = (float) $settings['earn_amount_per_point']; // SAR per 1 point
    $minOrder  = (float) $settings['earn_min_order_amount'];
    $minRedeem = (int) $settings['redeem_min_points'];
    $pointVal  = (float) $settings['redeem_point_value'];

    $earned = 0;
    $eligible = false;
    $discount = 0.0;

    if ($enabled && $earnRate > 0 && $pointVal > 0 && $bill >= $minOrder) {
        $earned = (int) floor($bill / $earnRate);
        if ($earned >= $minRedeem) {
            $eligible = true;
            $discount = round(min($earned * $pointVal, $bill), 2);
        }
    }

    return [
        'enabled'       => $enabled,
        'earned_points' => $earned,
        'eligible'      => $eligible,
        'discount'      => $discount,
        'settings'      => $settings,
    ];
}

/* =========================================================
   Phone / account helpers (legacy balance engine retained
   for historical ledger data and admin tooling)
   ========================================================= */

/** Orders and loyalty accounts share digits-only phone keys (max 15).
    Handles Arabic-Indic digits so phones typed on Arabic keyboards match. */
function loyalty_normalize_phone(string $raw): string
{
    $digits = preg_replace('/\D/', '', normalize_digits($raw));
    return substr((string) $digits, 0, 15);
}

function loyalty_get_account(PDO $pdo, string $phone): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM loyalty_accounts WHERE phone = :phone');
    $stmt->execute([':phone' => loyalty_normalize_phone($phone)]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Fetch a loyalty account or create it on first sight. Used by the
 * accrual + manual-grant paths; the read-only customer lookup uses
 * loyalty_get_account() instead so viewers never create rows.
 */
function loyalty_get_or_create_account(PDO $pdo, string $phone, ?string $name = null): array
{
    $phone = loyalty_normalize_phone($phone);
    $account = loyalty_get_account($pdo, $phone);
    if ($account) {
        if ($name && empty($account['customer_name'])) {
            $up = $pdo->prepare('UPDATE loyalty_accounts SET customer_name = :n WHERE id = :id');
            $up->execute([':n' => sanitize_string($name), ':id' => $account['id']]);
            $account['customer_name'] = sanitize_string($name);
        }
        return $account;
    }

    $stmt = $pdo->prepare('
        INSERT INTO loyalty_accounts (phone, customer_name)
        VALUES (:phone, :name)
    ');
    try {
        $stmt->execute([':phone' => $phone, ':name' => $name ? sanitize_string($name) : null]);
    } catch (PDOException $e) {
        if (!str_contains($e->getMessage(), '1062')) throw $e; // 1062 = already created racing
    }
    return loyalty_get_account($pdo, $phone);
}

/* =========================================================
   Audit trail
   ========================================================= */

function loyalty_log_action(
    PDO $pdo,
    ?array $actor,
    string $action,
    string $entityType,
    $entityId,
    $details
): void {
    $stmt = $pdo->prepare('
        INSERT INTO admin_audit_log (user_id, actor_name, action, entity_type, entity_id, details, ip_address)
        VALUES (:user_id, :actor_name, :action, :entity_type, :entity_id, :details, :ip)
    ');
    $actorId = $actor['sub'] ?? null;
    $actorName = null;
    if ($actorId) {
        $u = $pdo->prepare('SELECT full_name FROM users WHERE id = :id');
        $u->execute([':id' => (int) $actorId]);
        $actorName = $u->fetchColumn();
    }
    $stmt->execute([
        ':user_id'     => $actorId !== null ? (int) $actorId : null,
        ':actor_name'  => $actorName ?: ($actor['email'] ?? 'system'),
        ':action'      => $action,
        ':entity_type' => $entityType,
        ':entity_id'   => (string) $entityId,
        ':details'     => is_array($details) ? json_encode($details, JSON_UNESCAPED_SLASHES) : (string) $details,
        ':ip'          => $_SERVER['REMOTE_ADDR'] ?? null,
    ]);
}

/* =========================================================
   Core mutation — everything below is transaction-safe
   ========================================================= */

/**
 * Lock the account row and apply a signed points delta guarded against
 * a negative balance. Updates the matching running-total column by the
 * direction the caller declared ($flag: 'earn'|'redeem'|'adjust'|'reverse').
 * Callers MUST already be inside a transaction.
 */
function loyalty_apply_delta(PDO $pdo, int $accountId, int $delta, string $flag): array
{
    $lock = $pdo->prepare('SELECT * FROM loyalty_accounts WHERE id = :id FOR UPDATE');
    $lock->execute([':id' => $accountId]);
    $account = $lock->fetch();
    if (!$account) throw new RuntimeException('Loyalty account not found.');

    $balance = (int) $account['points_balance'];
    $newBalance = $balance + $delta;
    if ($newBalance < 0) {
        throw new RuntimeException("Insufficient points balance — account {$account['phone']} has {$balance} points.");
    }

    $up = $pdo->prepare('
        UPDATE loyalty_accounts
        SET points_balance = :balance,
            total_earned   = total_earned   + :earned,
            total_redeemed = total_redeemed + :redeemed,
            total_adjusted = total_adjusted + :adjusted,
            total_reversed = total_reversed + :reversed
        WHERE id = :id
    ');
    $up->execute([
        ':balance'  => $newBalance,
        ':earned'   => $flag === 'earn' && $delta > 0 ? $delta : 0,
        ':redeemed' => $flag === 'redeem' && $delta < 0 ? -$delta : 0,
        ':adjusted' => $flag === 'adjust' ? $delta : 0,
        ':reversed' => $flag === 'reverse' && $delta < 0 ? -$delta : 0,
        ':id'       => $accountId,
    ]);

    $account['points_balance'] = $newBalance;
    return [$account, $newBalance];
}

/** Insert a ledger row (caller inside transaction). Returns the row id. */
function loyalty_insert_tx(
    PDO $pdo,
    int $accountId,
    string $type,
    int $delta,
    int $balanceAfter,
    ?int $orderId = null,
    ?float $qualifiedAmount = null,
    ?float $cashValue = null,
    ?string $reason = null,
    ?array $actor = null
): int {
    $stmt = $pdo->prepare('
        INSERT INTO loyalty_transactions
            (loyalty_account_id, order_id, type, points_delta, points_balance_after,
             qualified_amount, cash_value, reason, created_by, created_by_name)
        VALUES (:acct, :order_id, :type, :delta, :after, :qualified, :cash, :reason, :uid, :uname)
    ');
    $uid = $actor['sub'] ?? null;
    $uname = null;
    if ($uid) {
        $u = $pdo->prepare('SELECT full_name FROM users WHERE id = :id');
        $u->execute([':id' => (int) $uid]);
        $found = $u->fetchColumn();
        $uname = $found ?: null;
    }
    $stmt->execute([
        ':acct' => $accountId,
        ':order_id' => $orderId,
        ':type' => $type,
        ':delta' => $delta,
        ':after' => $balanceAfter,
        ':qualified' => $qualifiedAmount,
        ':cash' => $cashValue,
        ':reason' => $reason,
        ':uid' => $uid !== null ? (int) $uid : null,
        ':uname' => $uname,
    ]);
    return (int) $pdo->lastInsertId();
}

/**
 * Accrue loyalty points for a completed (delivered) order. Idempotent:
 * repeated or racing calls yield exactly one 'earn' row. Returns the
 * ledger row id, or null when the order is not eligible / done before.
 */
function loyalty_accrue_for_order(PDO $pdo, int $orderId, ?array $actor = null): ?int
{
    // May be called standalone OR inside the caller's (PATCH handler)
    // transaction. Only own the transaction if we opened it.
    $owns = !$pdo->inTransaction();
    if ($owns) $pdo->beginTransaction();
    try {
        $orderStmt = $pdo->prepare('SELECT * FROM orders WHERE id = :id FOR UPDATE');
        $orderStmt->execute([':id' => $orderId]);
        $order = $orderStmt->fetch();

        if (!$order || $order['status'] !== 'delivered') {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return null;
        }

        // Already earned? (covers re-delivery, retries, and race paths)
        $dupe = $pdo->prepare('SELECT id FROM loyalty_transactions WHERE order_id = :oid AND type = "earn"');
        $dupe->execute([':oid' => $orderId]);
        $existing = $dupe->fetch();
        if ($existing) {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return (int) $existing['id'];
        }

        $settings = loyalty_get_settings($pdo);
        $phone = loyalty_normalize_phone((string) $order['phone']);
        if ($phone === '') {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return null;
        }

        // Qualified amount = the customer's final paid bill after every
        // discount (promo + any points redemption applied to this order).
        $qualified = (float) $order['total_amount'];

        if (!$settings['enabled']
            || $qualified < $settings['earn_min_order_amount']
            || $settings['earn_amount_per_point'] <= 0) {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return null;
        }

        $points = (int) floor($qualified / $settings['earn_amount_per_point']);
        if ($points < 1) {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return null;
        }

        $account = loyalty_get_or_create_account($pdo, $phone, $order['customer_name']);

        [, $balanceAfter] = loyalty_apply_delta($pdo, (int) $account['id'], $points, 'earn');
        $txId = loyalty_insert_tx(
            $pdo,
            (int) $account['id'],
            'earn',
            $points,
            $balanceAfter,
            $orderId,
            $qualified,
            null,
            "Order #{$orderId} completed — 1 pt per SAR " . $settings['earn_amount_per_point'],
            $actor
        );

        if ($owns && $pdo->inTransaction()) $pdo->commit();
        loyalty_log_action($pdo, $actor, 'loyalty.earn', 'order', $orderId,
            ["points" => $points, "phone" => $phone, "qualified_amount" => $qualified]);
        return $txId;
    } catch (Throwable $e) {
        if ($owns && $pdo->inTransaction()) $pdo->rollBack();
        if ($e instanceof PDOException && str_contains($e->getMessage(), '1062')) {
            return null; // lost a concurrent duplicate-earn race — the winner stands
        }
        throw $e;
    }
}

/**
 * Cancellation after delivery: take the earned points back. If part of
 * the earned points was already redeemed, only the remaining balance is
 * reversed, and the ledger row explains that. Ledger stays immutable.
 */
function loyalty_reverse_earn_for_order(PDO $pdo, int $orderId, string $reason, ?array $actor = null): ?int
{
    // May run standalone or inside the caller's transaction.
    $owns = !$pdo->inTransaction();
    if ($owns) $pdo->beginTransaction();
    try {
        $earnStmt = $pdo->prepare('SELECT * FROM loyalty_transactions WHERE order_id = :oid AND type = "earn"');
        $earnStmt->execute([':oid' => $orderId]);
        $earn = $earnStmt->fetch();
        if (!$earn) {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return null;
        }

        $check = $pdo->prepare('SELECT id FROM loyalty_transactions WHERE order_id = :oid AND type = "reverse"');
        $check->execute([':oid' => $orderId]);
        if ($check->fetch()) {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return null; // already reversed
        }

        $lock = $pdo->prepare('SELECT points_balance FROM loyalty_accounts WHERE id = :id FOR UPDATE');
        $lock->execute([':id' => (int) $earn['loyalty_account_id']]);
        $balance = (int) $lock->fetchColumn();

        $reversable = min((int) $earn['points_delta'], $balance);
        if ($reversable <= 0) {
            if ($owns && $pdo->inTransaction()) $pdo->rollBack();
            return null;
        }

        [, $balanceAfter] = loyalty_apply_delta($pdo, (int) $earn['loyalty_account_id'], -$reversable, 'reverse');
        $note = $reversable < (int) $earn['points_delta']
            ? "Order #{$orderId} cancelled — reversed {$reversable} pts (rest was already redeemed)"
            : "Order #{$orderId} cancelled — earned points reversed";
        $txId = loyalty_insert_tx(
            $pdo, (int) $earn['loyalty_account_id'], 'reverse', -$reversable, $balanceAfter,
            $orderId, null, null, $note . ' · ' . $reason, $actor
        );

        if ($owns && $pdo->inTransaction()) $pdo->commit();
        loyalty_log_action($pdo, $actor, 'loyalty.reverse', 'order', $orderId, ["reversed_points" => $reversable]);
        return $txId;
    } catch (Throwable $e) {
        if ($owns && $pdo->inTransaction()) $pdo->rollBack();
        if ($e instanceof PDOException && str_contains($e->getMessage(), '1062')) {
            return null; // already reversed concurrently
        }
        throw $e;
    }
}

/**
 * Manual adjustment (authorized staff grants/deducts points with a
 * recorded reason). Adding points auto-creates the account if the
 * customer is new; deducting requires an existing account.
 */
function loyalty_adjust_points(
    PDO $pdo,
    string $phone,
    int $delta,
    string $reason,
    ?array $actor = null,
    ?string $customerName = null
): array {
    $phone = loyalty_normalize_phone($phone);
    if ($delta === 0) throw new RuntimeException('Points delta must not be zero.');
    if (trim($reason) === '') throw new RuntimeException('A reason is required for manual adjustments.');

    $pdo->beginTransaction();
    try {
        if ($delta > 0) {
            $account = loyalty_get_or_create_account($pdo, $phone, $customerName);
        } else {
            $account = loyalty_get_account($pdo, $phone);
            if (!$account) {
                $pdo->rollBack();
                throw new RuntimeException('No loyalty account exists for this phone number.');
            }
        }

        [, $balanceAfter] = loyalty_apply_delta($pdo, (int) $account['id'], $delta, 'adjust');
        $txId = loyalty_insert_tx(
            $pdo,
            (int) $account['id'],
            'adjust',
            $delta,
            $balanceAfter,
            null,
            null,
            null,
            "Manual " . ($delta > 0 ? 'grant' : 'deduction') . ': ' . $reason,
            $actor
        );
        $pdo->commit();

        loyalty_log_action($pdo, $actor, 'loyalty.adjust', 'loyalty_account', $account['id'],
            ["delta" => $delta, "reason" => $reason, "phone" => $phone, "balance_after" => $balanceAfter]);
        return ["tx_id" => $txId, "balance" => $balanceAfter];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/**
 * Redeem points for a cash-equivalent reward. When linked to an order,
 * the cash value becomes a live discount on that order's bill inside
 * the same transaction, recorded in orders.points_discount — so later
 * earning on that order uses the reduced amount. Spent points are gone
 * immediately, guaranteeing a single use of every point.
 */
function loyalty_redeem_points(
    PDO $pdo,
    string $phone,
    int $points,
    ?array $actor = null,
    ?string $reason = null,
    ?int $orderId = null
): array {
    if ($points <= 0) throw new RuntimeException('Points to redeem must be a positive number.');

    $settings = loyalty_get_settings($pdo);
    $phone = loyalty_normalize_phone($phone);

    // May run standalone OR inside the caller's transaction (e.g. checkout).
    $owns = !$pdo->inTransaction();
    if ($owns) $pdo->beginTransaction();
    try {
        $account = loyalty_get_account($pdo, $phone);
        if (!$account) {
            if ($owns) $pdo->rollBack();
            throw new RuntimeException('No loyalty account exists for this phone number.');
        }

        if ($points < $settings['redeem_min_points']) {
            if ($owns) $pdo->rollBack();
            throw new RuntimeException("Minimum redemption is {$settings['redeem_min_points']} points.");
        }

        if (!$settings['enabled']) {
            if ($owns) $pdo->rollBack();
            throw new RuntimeException('The loyalty program is currently disabled.');
        }

        $lock = $pdo->prepare('SELECT * FROM loyalty_accounts WHERE id = :id FOR UPDATE');
        $lock->execute([':id' => (int) $account['id']]);
        $account = $lock->fetch();
        if ($points > (int) $account['points_balance']) {
            if ($owns) $pdo->rollBack();
            throw new RuntimeException("Balance too low — {$account['phone']} has {$account['points_balance']} points.");
        }

        $cashValue = round($points * $settings['redeem_point_value'], 2);

        if ($orderId !== null) {
            $o = $pdo->prepare('SELECT * FROM orders WHERE id = :id FOR UPDATE');
            $o->execute([':id' => $orderId]);
            $linkedOrder = $o->fetch();
            if (!$linkedOrder) {
                if ($owns) $pdo->rollBack();
                throw new RuntimeException("Order {$orderId} not found.");
            }
            if ($linkedOrder['status'] === 'cancelled') {
                if ($owns) $pdo->rollBack();
                throw new RuntimeException('Points cannot be redeemed against a cancelled order.');
            }
            if ($linkedOrder['status'] === 'delivered') {
                if ($owns) $pdo->rollBack();
                throw new RuntimeException('Points cannot be redeemed on an already-delivered order.');
            }
            if ($cashValue <= 0) {
                if ($owns) $pdo->rollBack();
                throw new RuntimeException('Redeem point value is currently zero — redeem without an order instead.');
            }
            if ($cashValue > (float) $linkedOrder['total_amount']) {
                if ($owns) $pdo->rollBack();
                throw new RuntimeException(sprintf(
                    'Discount exceeds the remaining order total (SAR %.2f). Redeem fewer points.',
                    (float) $linkedOrder['total_amount']
                ));
            }

            $upd = $pdo->prepare('
                UPDATE orders
                SET total_amount = total_amount - :cash,
                    points_discount = points_discount + :cash2
                WHERE id = :id
            ');
            $upd->execute([':cash' => $cashValue, ':cash2' => $cashValue, ':id' => $orderId]);
        }

        // Spent immediately — every redeemed point is exactly used once.
        [, $balanceAfter] = loyalty_apply_delta($pdo, (int) $account['id'], -$points, 'redeem');

        if ($orderId !== null) {
            $txReason = "Redeem against order #{$orderId} — " . (($reason ?? '') !== '' ? $reason : 'bill discount');
        } else {
            $txReason = ($reason ?? '') !== '' ? $reason : 'Cash reward redemption';
        }

        $txId = loyalty_insert_tx(
            $pdo, (int) $account['id'], 'redeem', -$points, $balanceAfter,
            $orderId, null, $cashValue, $txReason, $actor
        );
        if ($owns) $pdo->commit();

        loyalty_log_action($pdo, $actor, 'loyalty.redeem', 'loyalty_account', $account['id'],
            ["points" => $points, "cash_value" => $cashValue, "order_id" => $orderId,
             "phone" => $phone, "balance_after" => $balanceAfter]);

        return [
            "tx_id" => $txId,
            "points_redeemed" => $points,
            "cash_value" => $cashValue,
            "balance" => $balanceAfter,
            "order_id" => $orderId,
        ];
    } catch (Throwable $e) {
        if ($owns && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/**
 * Zero out the customer's balance through a logged settlement row —
 * never by deleting history. Previous and new balance stay traceable
 * in the ledger and the audit log.
 */
function loyalty_zero_balance(PDO $pdo, string $phone, string $reason, ?array $actor = null): array
{
    $phone = loyalty_normalize_phone($phone);
    if (trim($reason) === '') throw new RuntimeException('A reason is required when zeroing a balance.');

    $pdo->beginTransaction();
    try {
        $account = loyalty_get_account($pdo, $phone);
        if (!$account) {
            $pdo->rollBack();
            throw new RuntimeException('No loyalty account exists for this phone number.');
        }
        $balance = (int) $account['points_balance'];
        if ($balance === 0) {
            $pdo->rollBack();
            return ["tx_id" => null, "balance" => 0, "cleared" => 0];
        }

        [, $balanceAfter] = loyalty_apply_delta($pdo, (int) $account['id'], -$balance, 'adjust');
        $txId = loyalty_insert_tx(
            $pdo, (int) $account['id'], 'adjust', -$balance, $balanceAfter,
            null, null, null,
            "ZERO BALANCE (was {$balance} pts): " . $reason,
            $actor
        );
        $pdo->commit();

        loyalty_log_action($pdo, $actor, 'loyalty.zero', 'loyalty_account', $account['id'],
            ["cleared" => $balance, "reason" => $reason, "phone" => $phone, "balance_after" => $balanceAfter]);
        return ["tx_id" => $txId, "balance" => $balanceAfter, "cleared" => $balance];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/** Full customer loyalty summary + ledger history for the admin tool. */
function loyalty_customer_summary(PDO $pdo, string $phone): ?array
{
    $phone = loyalty_normalize_phone($phone);
    $account = loyalty_get_account($pdo, $phone);
    if (!$account) return null;

    $txStmt = $pdo->prepare('
        SELECT t.*, o.customer_name AS linked_order_customer, o.status AS linked_order_status
        FROM loyalty_transactions t
        LEFT JOIN orders o ON o.id = t.order_id
        WHERE t.loyalty_account_id = :id
        ORDER BY t.created_at DESC, t.id DESC
    ');
    $txStmt->execute([':id' => (int) $account['id']]);
    $transactions = $txStmt->fetchAll();

    foreach ($transactions as &$tx) {
        $tx['id'] = (int) $tx['id'];
        $tx['loyalty_account_id'] = (int) $tx['loyalty_account_id'];
        $tx['order_id'] = $tx['order_id'] !== null ? (int) $tx['order_id'] : null;
        $tx['points_delta'] = (int) $tx['points_delta'];
        $tx['points_balance_after'] = (int) $tx['points_balance_after'];
        $tx['qualified_amount'] = $tx['qualified_amount'] !== null ? (float) $tx['qualified_amount'] : null;
        $tx['cash_value'] = $tx['cash_value'] !== null ? (float) $tx['cash_value'] : null;
        $tx['created_by'] = $tx['created_by'] !== null ? (int) $tx['created_by'] : null;
    }
    unset($tx);

    $orderStats = $pdo->prepare("
        SELECT COUNT(*) AS order_count, COALESCE(SUM(total_amount), 0) AS spend
        FROM orders
        WHERE REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '+', '') = :phone
          AND status != 'cancelled'
    ");
    $orderStats->execute([':phone' => $phone]);
    $stats = $orderStats->fetch();

    $account['id'] = (int) $account['id'];
    $account['points_balance'] = (int) $account['points_balance'];
    $account['total_earned'] = (int) $account['total_earned'];
    $account['total_redeemed'] = (int) $account['total_redeemed'];
    $account['total_adjusted'] = (int) $account['total_adjusted'];
    $account['total_reversed'] = (int) $account['total_reversed'];

    return [
        'phone' => $phone,
        'account' => $account,
        'order_count' => (int) $stats['order_count'],
        'total_spend' => (float) $stats['spend'],
        'transactions' => $transactions,
    ];
}

/** List loyalty accounts for the admin overview table. */
function loyalty_list_accounts(PDO $pdo, string $search = ''): array
{
    $stmt = $pdo->prepare('
        SELECT a.*, u.id AS linked_user_id, u.email AS linked_user_email
        FROM loyalty_accounts a
        LEFT JOIN users u ON u.phone IS NOT NULL AND REPLACE(REPLACE(REPLACE(u.phone, " ", ""), "-", ""), "+", "") = a.phone
        WHERE (:search = "" OR a.phone LIKE :like OR a.customer_name LIKE :like2)
        ORDER BY a.updated_at DESC, a.id DESC
        LIMIT 200
    ');
    $search = trim($search);
    $like = $search === '' ? null : '%' . $search . '%';
    $stmt->execute([':search' => $search, ':like' => $like, ':like2' => $like]);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int) $r['id'];
        $r['points_balance'] = (int) $r['points_balance'];
        $r['total_earned'] = (int) $r['total_earned'];
        $r['total_redeemed'] = (int) $r['total_redeemed'];
        $r['total_adjusted'] = (int) $r['total_adjusted'];
        $r['total_reversed'] = (int) $r['total_reversed'];
        $r['linked_user_id'] = $r['linked_user_id'] !== null ? (int) $r['linked_user_id'] : null;
    }
    return $rows;
}

