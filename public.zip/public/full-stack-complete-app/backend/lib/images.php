<?php
/**
 * Savoria — Full-Stack Complete App
 * lib/images.php — safe server-side image processing for menu uploads
 *
 * Every uploaded image is re-processed server-side (client previews are
 * never trusted): validated by sniffed MIME type, size-limited, then
 * center-cropped and resized to the exact aspect ratio used by the
 * customer-facing menu cards (4:3) so cards keep their layout without
 * stretching or distortion. Output is a clean JPEG re-encode, which
 * also strips any embedded payloads (EXIF/metadata).
 */

declare(strict_types=1);

const IMG_UPLOAD_DIR_REL = '/assets/uploads';  // served by the frontend web root
const IMG_MAX_BYTES     = 5 * 1024 * 1024;    // 5 MB raw input cap
const IMG_MENU_WIDTH    = 800;                // 4:3 -> 800x600, matches .menu-card-media aspect
const IMG_MENU_HEIGHT   = 600;
const IMG_CAT_WIDTH     = 900;
const IMG_CAT_HEIGHT    = 600;

require_once __DIR__ . '/../config/env.php';

/**
 * Validate + process an uploaded image and move it into the frontend
 * uploads directory. Returns the public URL relative to the frontend,
 * e.g. "/assets/uploads/menu_68f2a1c4.jpg".
 *
 * @param array  $fileEntry    One entry from $_FILES
 * @param string $prefix       Filename prefix ("menu"|"category"|"site")
 * @param array|null $target   Optional explicit target size ['w'=>int,'h'=>int]
 *                             (used by the website image slots so each
 *                              picture is cropped to the aspect ratio of
 *                              the container it lives in)
 * @return string              Public relative URL of the saved image
 */
function savoria_process_upload(array $fileEntry, string $prefix = 'menu', ?array $target = null): string
{
    if (!empty($fileEntry['error'])) {
        throw new RuntimeException(match ((int) $fileEntry['error']) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Image is too large (max 5 MB).',
            UPLOAD_ERR_NO_FILE => 'No image file was provided.',
            default => 'Image upload failed (error code ' . (int) $fileEntry['error'] . ').',
        });
    }

    $path = (string) ($fileEntry['tmp_name'] ?? '');
    if ($path === '' || !is_file($path)) {
        throw new RuntimeException('No image file was provided.');
    }
    if (filesize($path) > IMG_MAX_BYTES) {
        throw new RuntimeException('Image is too large (max 5 MB).');
    }

    // Sniff the real file type — never trust the browser-supplied name/MIME.
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string) $finfo->file($path);
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Only JPG, PNG or WebP images are allowed.');
    }
    $extension = $allowed[$mime];

    // Decode with the engine matching the sniffed type.
    $source = match ($extension) {
        'jpg'  => @imagecreatefromjpeg($path),
        'png'  => @imagecreatefrompng($path),
        'webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : false,
        default => false,
    };
    if ($source === false) {
        throw new RuntimeException('This file could not be read as an image.');
    }

    if ($target !== null && !empty($target['w']) && !empty($target['h'])) {
        [$targetW, $targetH] = [(int) $target['w'], (int) $target['h']];
    } else {
        [$targetW, $targetH] = $prefix === 'category'
            ? [IMG_CAT_WIDTH, IMG_CAT_HEIGHT]
            : [IMG_MENU_WIDTH, IMG_MENU_HEIGHT];
    }

    $processed = savoria_center_crop_resize($source, $targetW, $targetH);

    // Resolve ../frontend/assets/uploads relative to this backend/lib dir
    // — works no matter where the project is deployed.
    $dir = dirname(__DIR__, 2) . '/frontend' . IMG_UPLOAD_DIR_REL;

    if (!is_dir($dir) && !mkdir($dir, 0775, true)) {
        imagedestroy($source);
        imagedestroy($processed);
        throw new RuntimeException('Could not create the uploads directory on the server.');
    }

    $filename = sprintf('%s_%s.%s', $prefix, bin2hex(random_bytes(6)), 'jpg');
    $fullPath = $dir . '/' . $filename;

    $saved = imagejpeg($processed, $fullPath, 82); // quality 82 ≈ crisp food photos, small files
    imagedestroy($source);
    imagedestroy($processed);

    if (!$saved) {
        throw new RuntimeException('Could not save the processed image to disk.');
    }

    return IMG_UPLOAD_DIR_REL . '/' . $filename;
}

/**
 * Center-crop + scale an image to an exact box without distortion:
 * 1. Crop the largest centered region matching the target ratio.
 * 2. Scale that crop down/up to the exact target pixels.
 * Produces the same visual behavior as CSS `object-fit: cover`, baked in.
 */
function savoria_center_crop_resize(GdImage $source, int $targetW, int $targetH): GdImage
{
    $srcW = imagesx($source);
    $srcH = imagesy($source);

    $srcRatio = $srcW / $srcH;
    $targetRatio = $targetW / $targetH;

    if ($srcRatio > $targetRatio) {
        // Source is wider — crop the sides
        $cropW = (int) round($srcH * $targetRatio);
        $cropH = $srcH;
        $cropX = (int) floor(($srcW - $cropW) / 2);
        $cropY = 0;
    } else {
        // Source is taller — crop the top/bottom, biased slightly upward
        // (plates/food sit above center in most restaurant photos).
        $cropW = $srcW;
        $cropH = (int) round($srcW / $targetRatio);
        $cropX = 0;
        $cropY = (int) max(0, floor(($srcH - $cropH) * 0.38));
    }

    $canvas = imagecreatetruecolor($targetW, $targetH);
    if ($canvas === false) {
        throw new RuntimeException('Could not allocate the image canvas.');
    }

    $paletteBg = imagecolorallocate($canvas, 245, 240, 233); // cream fallback
    imagefill($canvas, 0, 0, $paletteBg);
    imagecopyresampled($canvas, $source, 0, 0, $cropX, $cropY, $targetW, $targetH, $cropW, $cropH);

    return $canvas;
}

/** Validate an optional URL the admin may type manually. */
function savoria_validate_image_url(string $url): string
{
    $url = trim($url);
    if ($url === '' || $url === null) return '';
    if (str_starts_with($url, IMG_UPLOAD_DIR_REL . '/')) {
        return $url; // our own processed uploads
    }
    if (preg_match('#^https://[^\s]+\.(jpg|jpeg|png|webp)(\?.*)?$#i', $url)
        || preg_match('#^https://images\.unsplash\.com/#i', $url)
        || preg_match('#^/[A-Za-z0-9._\-/]+(\?.*)?$#', $url)) {
        return $url;
    }
    throw new RuntimeException('Image URL must be an https:// image link or an uploaded file URL.');
}
