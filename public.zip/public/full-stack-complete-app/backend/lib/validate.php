<?php
/**
 * Savoria — Full-Stack Complete App
 * backend/lib/validate.php — request payload validation
 */

declare(strict_types=1);

function validate_register_payload(array $payload): array
{
    $errors = [];

    if (empty($payload['full_name']) || strlen((string)$payload['full_name']) < 2) {
        $errors['full_name'] = 'Full name must be at least 2 characters.';
    }
    if (empty($payload['email']) || !filter_var($payload['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'A valid email address is required.';
    }
    $password = (string) ($payload['password'] ?? '');
    if (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors['password'] = 'Password must include at least one uppercase letter and one number.';
    }
    if (isset($payload['phone']) && !preg_match('/^\d{10,13}$/', preg_replace('/\D/', '', (string)$payload['phone']))) {
        $errors['phone'] = 'Phone number format is invalid.';
    }

    return [empty($errors), $errors];
}

function validate_login_payload(array $payload): array
{
    $errors = [];
    // Customers may sign in with either their email or their phone number.
    $identifier = trim((string) ($payload['email'] ?? $payload['identifier'] ?? $payload['phone'] ?? ''));
    if ($identifier === '') {
        $errors['email'] = 'Email or phone number is required.';
    } elseif (str_contains($identifier, '@')) {
        if (!filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'A valid email address is required.';
        }
    } else {
        $digits = preg_replace('/\D/', '', normalize_digits($identifier));
        if (strlen((string) $digits) < 7) {
            $errors['email'] = 'Enter a valid email address or phone number.';
        }
    }
    if (empty($payload['password'])) {
        $errors['password'] = 'Password is required.';
    }
    return [empty($errors), $errors];
}

/**
 * Public customer self-registration: name, phone and password are the
 * minimum. Email is optional (phone is the customer's identity in this
 * restaurant); when omitted, an internal login address is generated.
 */
function validate_customer_register_payload(array $payload): array
{
    $errors = [];

    $name = trim((string) ($payload['full_name'] ?? ''));
    if ($name === '' || mb_strlen($name) < 2) {
        $errors['full_name'] = 'Full name must be at least 2 characters.';
    }

    $phone = preg_replace('/\D/', '', normalize_digits((string) ($payload['phone'] ?? '')));
    if ($phone === '' || strlen((string) $phone) < 9 || strlen((string) $phone) > 15) {
        $errors['phone'] = 'A valid phone number is required (9-15 digits).';
    }

    $password = (string) ($payload['password'] ?? '');
    if (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors['password'] = 'Password must include at least one uppercase letter and one number.';
    }

    if (isset($payload['email']) && trim((string) $payload['email']) !== '') {
        if (!filter_var($payload['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'A valid email address is required.';
        }
    }

    return [empty($errors), $errors];
}

function validate_forgot_password_payload(array $payload): array
{
    $errors = [];
    if (empty($payload['email']) || !filter_var($payload['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'A valid email address is required.';
    }
    return [empty($errors), $errors];
}

function validate_reset_password_payload(array $payload): array
{
    $errors = [];
    if (empty($payload['token'])) {
        $errors['token'] = 'Reset token is required.';
    }
    $password = (string) ($payload['password'] ?? '');
    if (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters.';
    } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors['password'] = 'Password must include at least one uppercase letter and one number.';
    }
    return [empty($errors), $errors];
}

function validate_change_password_payload(array $payload): array
{
    $errors = [];
    if (empty($payload['current_password'])) {
        $errors['current_password'] = 'Current password is required.';
    }
    $password = (string) ($payload['new_password'] ?? '');
    if (strlen($password) < 8) {
        $errors['new_password'] = 'New password must be at least 8 characters.';
    } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors['new_password'] = 'New password must include at least one uppercase letter and one number.';
    }
    return [empty($errors), $errors];
}
function validate_menu_item_payload(array $payload, bool $isUpdate = false): array
{
    $errors = [];

    if (!$isUpdate || array_key_exists('name', $payload)) {
        if (empty($payload['name']) || strlen((string)$payload['name']) < 2) {
            $errors['name'] = 'Name must be at least 2 characters.';
        }
    }
    if (!$isUpdate || array_key_exists('category_id', $payload)) {
        if (empty($payload['category_id']) || !is_numeric($payload['category_id'])) {
            $errors['category_id'] = 'A valid category_id is required.';
        }
    }
    if (!$isUpdate || array_key_exists('price', $payload)) {
        if (!isset($payload['price']) || !is_numeric($payload['price']) || (float)$payload['price'] < 0) {
            $errors['price'] = 'Price must be a non-negative number.';
        }
    }
    // Calories are optional: an empty value simply means "not published".
    if (array_key_exists('calories', $payload) && $payload['calories'] !== null && $payload['calories'] !== '') {
        if (!is_numeric($payload['calories'])
            || (float)$payload['calories'] < 0
            || (float)$payload['calories'] > 5000) {
            $errors['calories'] = 'Calories must be a number between 0 and 5000.';
        }
    }
    if (array_key_exists('discount_percent', $payload) && $payload['discount_percent'] !== null && $payload['discount_percent'] !== '') {
        if (!is_numeric($payload['discount_percent'])
            || (float)$payload['discount_percent'] < 0
            || (float)$payload['discount_percent'] > 100) {
            $errors['discount_percent'] = 'Discount percent must be between 0 and 100.';
        }
    }

    return [empty($errors), $errors];
}

function validate_order_payload(array $payload): array
{
    $errors = [];

    if (empty($payload['customer_name'])) {
        $errors['customer_name'] = 'Customer name is required.';
    }
    $phoneDigits = preg_replace('/\D/', '', normalize_digits(($payload['phone'] ?? '')));
    if (empty($phoneDigits) || !preg_match('/^\d{9,14}$/', $phoneDigits)) {
        $errors['phone'] = 'A valid phone number is required (9-14 digits).';
    }

    $validTypes = ['dine_in', 'pickup', 'delivery'];
    $orderType = $payload['order_type'] ?? '';
    if (!in_array($orderType, $validTypes, true)) {
        $errors['order_type'] = 'order_type must be one of: ' . implode(', ', $validTypes) . '.';
    }
    if ($orderType === 'delivery' && empty($payload['delivery_address'])) {
        $errors['delivery_address'] = 'Delivery address is required for delivery orders.';
    }

    // A dine-in order knows its table in one of two ways: the guest typed a
    // number, or the guest scanned the table's QR code — which sends the
    // table's token instead. The token is only checked for its shape here;
    // the server resolves the real table from it when the order is stored,
    // so a number coming from the browser is never trusted on its own.
    $tableToken = trim((string) ($payload['table_token'] ?? ''));
    if ($tableToken !== '' && !preg_match('/^[a-f0-9]{32}$/i', $tableToken)) {
        $errors['table_token'] = 'The table QR code is not valid.';
    }
    if ($orderType === 'dine_in' && $tableToken === '') {
        $table = $payload['table_number'] ?? null;
        $table = trim(normalize_digits($table));
        if ($table === '' || !is_numeric($table) || (int)$table < 1 || (int)$table > 255) {
            $errors['table_number'] = 'A table number between 1 and 255 is required for dine-in orders.';
        }
    }
    if (isset($payload['order_notes']) && strlen(trim((string) $payload['order_notes'])) > 255) {
        $errors['order_notes'] = 'Order notes must be 255 characters or fewer.';
    }

    if (empty($payload['items']) || !is_array($payload['items'])) {
        $errors['items'] = 'At least one item is required.';
    } else {
        foreach ($payload['items'] as $index => $item) {
            if (!isset($item['menu_item_id']) || !is_numeric($item['menu_item_id'])) {
                $errors["items.$index.menu_item_id"] = 'Each item requires a valid menu_item_id.';
            }
            if (!isset($item['quantity']) || !is_numeric($item['quantity']) || (int)$item['quantity'] < 1) {
                $errors["items.$index.quantity"] = 'Each item requires a quantity of at least 1.';
            }
            if (isset($item['special_instructions']) && strlen(trim((string) $item['special_instructions'])) > 255) {
                $errors["items.$index.special_instructions"] = 'Item instructions must be 255 characters or fewer.';
            }
        }
    }

    return [empty($errors), $errors];
}

/**
 * A restaurant table, as the management panel sends it.
 * Returns [isValid, errors, clean] — the clean map only ever contains the
 * keys the payload actually carried, so an update never overwrites a field
 * the manager did not touch.
 */
function validate_table_payload(array $payload, bool $isUpdate = false): array
{
    $errors = [];
    $clean  = [];

    if (array_key_exists('table_number', $payload) || !$isUpdate) {
        $raw = trim(normalize_digits($payload['table_number'] ?? ''));
        if ($raw === '' || !is_numeric($raw) || (int) $raw < 1 || (int) $raw > 255) {
            $errors['table_number'] = 'A table number between 1 and 255 is required.';
        } else {
            $clean['table_number'] = (int) $raw;
        }
    }

    foreach (['label', 'label_ar'] as $field) {
        if (array_key_exists($field, $payload)) {
            $value = trim(strip_tags((string) $payload[$field]));
            if (mb_strlen($value) > 60) {
                $errors[$field] = 'The table name must be 60 characters or fewer.';
            } else {
                $clean[$field] = $value === '' ? null : $value;
            }
        }
    }

    if (array_key_exists('seats', $payload)) {
        $seats = trim((string) $payload['seats']);
        if ($seats === '' || !is_numeric($seats) || (int) $seats < 1 || (int) $seats > 99) {
            $errors['seats'] = 'Seats must be a number between 1 and 99.';
        } else {
            $clean['seats'] = (int) $seats;
        }
    }

    if (array_key_exists('status', $payload)) {
        $status = (string) $payload['status'];
        if (!in_array($status, TABLE_STATUSES, true)) {
            $errors['status'] = 'Status must be one of: ' . implode(', ', TABLE_STATUSES) . '.';
        } else {
            $clean['status'] = $status;
        }
    }

    return [empty($errors), $errors, $clean];
}

function validate_reservation_payload(array $payload): array
{
    $errors = [];

    if (empty($payload['full_name'])) $errors['full_name'] = 'Full name is required.';
    if (empty($payload['phone']) || !preg_match('/^\d{10,13}$/', preg_replace('/\D/', '', (string)($payload['phone'] ?? '')))) {
        $errors['phone'] = 'A valid phone number is required.';
    }
    $partySizeRaw = (string) ($payload['party_size'] ?? '');
    if ($partySizeRaw === '' || (!is_numeric($partySizeRaw) && !str_contains($partySizeRaw, '6+'))) {
        $errors['party_size'] = 'Party size must be at least 1.';
    } elseif (is_numeric($partySizeRaw) && (int)$partySizeRaw < 1) {
        $errors['party_size'] = 'Party size must be at least 1.';
    }
    if (empty($payload['reservation_date']) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $payload['reservation_date'])) {
        $errors['reservation_date'] = 'A valid date (YYYY-MM-DD) is required.';
    }
    if (empty($payload['reservation_time']) || normalize_reservation_time((string)$payload['reservation_time']) === null) {
        $errors['reservation_time'] = 'A valid reservation time is required.';
    }

    return [empty($errors), $errors];
}
