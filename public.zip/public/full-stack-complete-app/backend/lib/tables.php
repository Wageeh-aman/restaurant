<?php
/**
 * Savoria — Full-Stack Complete App
 * backend/lib/tables.php — restaurant tables & QR codes.
 *
 * A table is a physical table of the restaurant. Every table owns a
 * random, unguessable token; the printed QR code carries that token in
 * its URL, never the table number. When a guest scans it, the server
 * turns the token back into the real table, so the number written on the
 * order can never be forged by editing the link.
 *
 * The structure is created by the code itself on first use, so a database
 * that has not received the migration keeps working — the routes simply
 * create what they need (the same pattern the rest of the API uses for
 * the optional columns).
 */

declare(strict_types=1);

const TABLE_TOKEN_HEX_LENGTH = 32; // 16 random bytes → 32 hex characters

const RESTAURANT_TABLES_DDL = "
CREATE TABLE IF NOT EXISTS restaurant_tables (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    table_number TINYINT UNSIGNED NOT NULL,
    label        VARCHAR(60) DEFAULT NULL,
    label_ar     VARCHAR(60) DEFAULT NULL,
    seats        TINYINT UNSIGNED NOT NULL DEFAULT 4,
    status       ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
    qr_token     CHAR(32) NOT NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_restaurant_tables_number (table_number),
    UNIQUE KEY uq_restaurant_tables_token (qr_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

/** The status codes a table can carry (the only values the ENUM accepts). */
const TABLE_STATUSES = ['active', 'disabled'];

/** The statuses that mean "this order is still being served". */
const TABLE_OPEN_ORDER_STATUSES = ['pending', 'confirmed', 'preparing', 'out_for_delivery'];

/** Is the tables structure present? */
function tables_ready(PDO $pdo): bool
{
    return schema_table_exists($pdo, 'restaurant_tables');
}

/**
 * Create the tables structure and the orders.table_id column when they
 * are missing, and report whether the structure is usable afterwards.
 */
function tables_ensure_schema(PDO $pdo): bool
{
    if (!tables_ready($pdo)) {
        try {
            $pdo->exec(RESTAURANT_TABLES_DDL);
        } catch (Throwable $e) {
            // Another request may have created it first — the check below decides.
        }
        schema_cache_forget();
    }

    if (tables_ready($pdo) && !i18n_column_exists($pdo, 'restaurant_tables', 'label_ar')) {
        schema_ensure_column($pdo, 'restaurant_tables', 'label_ar',
            'ALTER TABLE restaurant_tables ADD COLUMN label_ar VARCHAR(60) DEFAULT NULL AFTER label');
    }

    // The order keeps a real reference to the table it was placed at.
    if (tables_ready($pdo)) {
        schema_ensure_column($pdo, 'orders', 'table_id',
            'ALTER TABLE orders ADD COLUMN table_id INT UNSIGNED DEFAULT NULL, ADD INDEX idx_orders_table (table_id)');
    }

    return tables_ready($pdo);
}

/** A fresh, unguessable token for a table's QR link. */
function table_new_token(PDO $pdo): string
{
    for ($attempt = 0; $attempt < 5; $attempt++) {
        $token = bin2hex(random_bytes(TABLE_TOKEN_HEX_LENGTH / 2));
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM restaurant_tables WHERE qr_token = :t');
        $stmt->execute([':t' => $token]);
        if ((int) $stmt->fetchColumn() === 0) {
            return $token;
        }
    }

    // A 128-bit collision five times in a row is not going to happen, but a
    // token that could not be proven unique is never handed out.
    throw new RuntimeException('Could not generate a unique table QR token.');
}

/** Is this a well-formed token (so we never query the database for junk)? */
function table_token_is_well_formed(string $token): bool
{
    return (bool) preg_match('/^[a-f0-9]{' . TABLE_TOKEN_HEX_LENGTH . '}$/', strtolower(trim($token)));
}

/**
 * The table a QR token belongs to, or null when the token is unknown or
 * (with $activeOnly) the table has been disabled.
 */
function table_by_token(PDO $pdo, string $token, bool $activeOnly = true): ?array
{
    $token = strtolower(trim($token));
    if (!table_token_is_well_formed($token)) return null;

    $sql = 'SELECT * FROM restaurant_tables WHERE qr_token = :t';
    if ($activeOnly) $sql .= " AND status = 'active'";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':t' => $token]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** The table row by its id, or null. */
function table_by_id(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM restaurant_tables WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Every table, ordered by number, each with the number of orders still
 * being served at it and the moment it was last active. The manager uses
 * that live status to see which tables are busy right now.
 */
function tables_list(PDO $pdo): array
{
    $openStatuses = "'" . implode("', '", TABLE_OPEN_ORDER_STATUSES) . "'";
    $sql = "SELECT t.*,
                   (SELECT COUNT(*) FROM orders o
                     WHERE o.table_id = t.id AND o.status IN ($openStatuses)) AS open_orders,
                   (SELECT MAX(o.updated_at) FROM orders o WHERE o.table_id = t.id) AS last_order_at
            FROM restaurant_tables t
            ORDER BY t.table_number ASC";
    $rows = $pdo->query($sql)->fetchAll();

    return array_map(fn (array $r) => table_serialize($r, true), $rows);
}

/**
 * Shape a table row for the API. The QR token is only ever sent to
 * management; the public resolve endpoint never includes it.
 */
function table_serialize(array $row, bool $withToken = false): array
{
    $out = [
        'id'           => (int) $row['id'],
        'table_number' => (int) $row['table_number'],
        'label'        => $row['label'] ?? null,
        'label_ar'     => $row['label_ar'] ?? null,
        'seats'        => (int) ($row['seats'] ?? 0),
        'status'       => (string) ($row['status'] ?? 'active'),
    ];
    if ($withToken) {
        $out['qr_token']    = (string) $row['qr_token'];
        $out['open_orders'] = (int) ($row['open_orders'] ?? 0);
        $out['last_order_at'] = $row['last_order_at'] ?? null;
        $out['created_at']  = $row['created_at'] ?? null;
    }
    return $out;
}

/** How many orders are still open at a given table (used by the panel). */
function table_open_order_count(PDO $pdo, int $tableId): int
{
    $openStatuses = "'" . implode("', '", TABLE_OPEN_ORDER_STATUSES) . "'";
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE table_id = :id AND status IN ($openStatuses)");
    $stmt->execute([':id' => $tableId]);
    return (int) $stmt->fetchColumn();
}