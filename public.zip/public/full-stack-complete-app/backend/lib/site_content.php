<?php
/**
 * Savoria — Full Stack Complete App
 * backend/lib/site_content.php — Website Content Management schema + helpers.
 *
 * The public website (frontend/index.html) used to hard-code its texts and
 * images. This module turns that content into database-backed data without
 * changing a single pixel of the existing design:
 *
 *   • site_settings — one row per editable text key (key/value, typed).
 *   • site_images   — one row per image slot (custom URL + shipped default).
 *   • reviews       — the homepage testimonials, now manageable in the panel.
 *
 * Every key in SITE_CONTENT_SCHEMA is bound to a real element in the
 * storefront through a `data-content` / `data-content-img` attribute, so the
 * panel can never show a field that the website does not use. The schema is
 * the single source of truth for: the admin form, the server-side
 * validation, and the public payload.
 *
 * ── Languages ────────────────────────────────────────────
 * Every field carries an English default and an Arabic default, and the
 * database may store a translated value next to the original one
 * (content_value_ar). The original English column is never touched, so:
 *
 *   • the current data stays valid and readable as it is;
 *   • a missing translation simply falls back to the shipped default;
 *   • a client that ignores the new column behaves exactly as before.
 *
 * Multi-tenant readiness: every table carries a `restaurant_id` column
 * (default 1) so a future per-restaurant split is a data migration, not a
 * rewrite. The current build stays single-restaurant and fully compatible.
 */

declare(strict_types=1);

const SITE_RESTAURANT_ID = 1; // current build: one restaurant (see report)

/**
 * Bumped whenever the shape of the public content payload changes.
 * It is part of the ETag, so a client that cached an older payload
 * receives the new one instead of a "not modified" answer.
 */
const SITE_CONTENT_PAYLOAD_VERSION = '2';

/* =========================================================
   Editable text fields — the contract with the storefront.
   type: text | multiline | url | email | phone | json

   Each field also carries:
     label_ar   — the Arabic name of the field in the admin panel
     default_ar — the Arabic text shipped with the site
     hint_ar    — the Arabic helper text (optional)
   ========================================================= */

function site_content_fields(): array
{
    return [
        /* ---------------- Restaurant information ---------------- */
        ['key' => 'restaurant_name', 'group' => 'restaurant', 'label' => 'Restaurant name', 'label_ar' => 'اسم المطعم', 'type' => 'text', 'default' => 'Tarmez', 'default_ar' => 'Tarmez', 'max' => 80, 'required' => true, 'hint' => 'Shown in the footer, the page title and the logo alt text.', 'hint_ar' => 'يظهر في التذييل وعنوان الصفحة ونص بديل الشعار.'],
        ['key' => 'site_title', 'group' => 'restaurant', 'label' => 'Browser tab title', 'label_ar' => 'عنوان تبويب المتصفح', 'type' => 'text', 'default' => 'Tarmez — Fine Dining & Food Ordering', 'default_ar' => 'تارمز — مطبخ راقٍ وطلب طعام', 'max' => 120, 'hint' => 'The title shown in the browser tab.', 'hint_ar' => 'العنوان الظاهر في تبويب المتصفح.'],
        ['key' => 'site_meta_description', 'group' => 'restaurant', 'label' => 'SEO description', 'label_ar' => 'وصف الصفحة لمحركات البحث', 'type' => 'multiline', 'default' => 'Tarmez is a modern fine-dining restaurant offering an elevated menu, table reservations, and doorstep delivery across the city.', 'default_ar' => 'تارمز مطعم راقٍ حديث يقدم قائمة مميزة وحجوزات طاولات وتوصيل إلى باب منزلك في أنحاء المدينة.', 'max' => 300],
        ['key' => 'restaurant_eyebrow', 'group' => 'restaurant', 'label' => 'Hero eyebrow', 'label_ar' => 'سطر وصفي فوق العنوان', 'type' => 'text', 'default' => 'Est. 2019 · Downtown Karachi', 'default_ar' => 'منذ 2019 · وسط كراتشي', 'max' => 120, 'hint' => 'Small line above the hero headline.', 'hint_ar' => 'سطر صغير فوق العنوان الرئيسي.'],
        ['key' => 'restaurant_intro', 'group' => 'restaurant', 'label' => 'Hero introduction', 'label_ar' => 'المقدمة الرئيسية', 'type' => 'multiline', 'default' => 'Tarmez brings together seasonal ingredients and refined technique — dine in our candlelit hall, reserve a table in seconds, or have chef-crafted dishes delivered to your door.', 'default_ar' => 'يجمع تارمز بين مكونات موسمية وتقنية متقنة — تعرّف في قاعتنا المضاءة بالشموع، أو احجز طاولة في ثوانٍ، أو اطلب أطباق الشيف إلى بابك.', 'max' => 400],
        ['key' => 'hero_headline_before', 'group' => 'restaurant', 'label' => 'Hero headline — before the highlight', 'label_ar' => 'العنوان الرئيسي — قبل الكلمة المميزة', 'type' => 'text', 'default' => 'Modern flavors,', 'default_ar' => 'نكهات عصرية،', 'max' => 80],
        ['key' => 'hero_headline_highlight', 'group' => 'restaurant', 'label' => 'Hero headline — highlighted word', 'label_ar' => 'العنوان الرئيسي — الكلمة المميزة', 'type' => 'text', 'default' => 'timeless', 'default_ar' => 'كرمٌ', 'max' => 40, 'hint' => 'This word is rendered in the accent italic style, exactly like the current design.', 'hint_ar' => 'تُعرض هذه الكلمة بالخط المائل المميّز تمامًا كما في التصميم الحالي.'],
        ['key' => 'hero_headline_after', 'group' => 'restaurant', 'label' => 'Hero headline — after the highlight', 'label_ar' => 'العنوان الرئيسي — بعد الكلمة المميزة', 'type' => 'text', 'default' => 'hospitality.', 'default_ar' => 'بلا حدود.', 'max' => 80],
        ['key' => 'hero_cta_primary', 'group' => 'restaurant', 'label' => 'Primary hero button', 'label_ar' => 'الزر الرئيسي', 'type' => 'text', 'default' => 'Reserve a Table', 'default_ar' => 'احجز طاولة', 'max' => 40],
        ['key' => 'hero_cta_secondary', 'group' => 'restaurant', 'label' => 'Secondary hero button', 'label_ar' => 'الزر الثانوي', 'type' => 'text', 'default' => 'Order Online', 'default_ar' => 'اطلب أونلاين', 'max' => 40],
        ['key' => 'hero_pill', 'group' => 'restaurant', 'label' => 'Hero image badge', 'label_ar' => 'شارة الصورة الرئيسية', 'type' => 'text', 'default' => "Chef's Table", 'default_ar' => 'مائدة الشيف', 'max' => 40],
        ['key' => 'hero_badge_value', 'group' => 'restaurant', 'label' => 'Rating badge — value', 'label_ar' => 'شارة التقييم — الرقم', 'type' => 'text', 'default' => '4.9', 'default_ar' => '4.9', 'max' => 10],
        ['key' => 'hero_badge_title', 'group' => 'restaurant', 'label' => 'Rating badge — title', 'label_ar' => 'شارة التقييم — العنوان', 'type' => 'text', 'default' => 'Excellent Rating', 'default_ar' => 'تقييم ممتاز', 'max' => 40],
        ['key' => 'hero_badge_text', 'group' => 'restaurant', 'label' => 'Rating badge — caption', 'label_ar' => 'شارة التقييم — السطر secondary', 'type' => 'text', 'default' => '2,300+ verified reviews', 'default_ar' => 'أكثر من 2,300 تقييم موثّق', 'max' => 60],
        ['key' => 'hero_stat1_value', 'group' => 'restaurant', 'label' => 'Stat 1 — value', 'label_ar' => 'الإحصاء 1 — الرقم', 'type' => 'text', 'default' => '4.9★', 'default_ar' => '4.9★', 'max' => 20],
        ['key' => 'hero_stat1_label', 'group' => 'restaurant', 'label' => 'Stat 1 — label', 'label_ar' => 'الإحصاء 1 — الوصف', 'type' => 'text', 'default' => 'Average rating', 'default_ar' => 'متوسط التقييم', 'max' => 40],
        ['key' => 'hero_stat2_value', 'group' => 'restaurant', 'label' => 'Stat 2 — value', 'label_ar' => 'الإحصاء 2 — الرقم', 'type' => 'text', 'default' => '12k+', 'default_ar' => '12k+', 'max' => 20],
        ['key' => 'hero_stat2_label', 'group' => 'restaurant', 'label' => 'Stat 2 — label', 'label_ar' => 'الإحصاء 2 — الوصف', 'type' => 'text', 'default' => 'Orders delivered', 'default_ar' => 'طلب تم توصيله', 'max' => 40],
        ['key' => 'hero_stat3_value', 'group' => 'restaurant', 'label' => 'Stat 3 — value', 'label_ar' => 'الإحصاء 3 — الرقم', 'type' => 'text', 'default' => '7', 'default_ar' => '7', 'max' => 20],
        ['key' => 'hero_stat3_label', 'group' => 'restaurant', 'label' => 'Stat 3 — label', 'label_ar' => 'الإحصاء 3 — الوصف', 'type' => 'text', 'default' => 'Years serving the city', 'default_ar' => 'سنوات في خدمة المدينة', 'max' => 40],

        /* ---------------- Our story ---------------- */
        ['key' => 'about_eyebrow', 'group' => 'story', 'label' => 'Story — eyebrow', 'label_ar' => 'القصة — السطر الوصفي', 'type' => 'text', 'default' => 'Our Story', 'default_ar' => 'قصتنا', 'max' => 60],
        ['key' => 'about_title', 'group' => 'story', 'label' => 'Story — headline', 'label_ar' => 'القصة — العنوان', 'type' => 'text', 'default' => 'A kitchen built on craft, not shortcuts.', 'default_ar' => 'مطبخ بُني على الحرفة، لا على الاختصارات.', 'max' => 120, 'required' => true],
        ['key' => 'about_text', 'group' => 'story', 'label' => 'Story — paragraph', 'label_ar' => 'القصة — الفقرة', 'type' => 'multiline', 'default' => 'Founded by a small team of chefs who trained across Karachi, Dubai, and Lyon, Tarmez was built to prove that thoughtful ingredients and unhurried technique still matter.', 'default_ar' => 'أسّس تارمز فريق صغير من الطهاة الذين تدربوا في كراتشي ودبي وليون، ليُثبت أن المكوّنات المدروسة والتقنية المتأنية ما زالت مهمّة.', 'max' => 600],
        ['key' => 'about_point1_icon', 'group' => 'story', 'label' => 'Point 1 — badge', 'label_ar' => 'النقطة 1 — الشارة', 'type' => 'text', 'default' => '1', 'default_ar' => '1', 'max' => 4],
        ['key' => 'about_point1_title', 'group' => 'story', 'label' => 'Point 1 — title', 'label_ar' => 'النقطة 1 — العنوان', 'type' => 'text', 'default' => 'Locally sourced', 'default_ar' => 'مكونات محلية', 'max' => 60],
        ['key' => 'about_point1_text', 'group' => 'story', 'label' => 'Point 1 — text', 'label_ar' => 'النقطة 1 — النص', 'type' => 'text', 'default' => 'Produce delivered daily from trusted regional farms.', 'default_ar' => 'خضروات تصل يوميًا من مزارع إقليمية موثوقة.', 'max' => 160],
        ['key' => 'about_point2_icon', 'group' => 'story', 'label' => 'Point 2 — badge', 'label_ar' => 'النقطة 2 — الشارة', 'type' => 'text', 'default' => '2', 'default_ar' => '2', 'max' => 4],
        ['key' => 'about_point2_title', 'group' => 'story', 'label' => 'Point 2 — title', 'label_ar' => 'النقطة 2 — العنوان', 'type' => 'text', 'default' => 'Chef-led menu', 'default_ar' => 'قائمة يقودها الشيف', 'max' => 60],
        ['key' => 'about_point2_text', 'group' => 'story', 'label' => 'Point 2 — text', 'label_ar' => 'النقطة 2 — النص', 'type' => 'text', 'default' => 'Seasonal dishes designed and tested in-house every quarter.', 'default_ar' => 'أطباق موسمية تُصمَّم وتُختبر داخل المطبخ كل ثلاثة أشهر.', 'max' => 160],
        ['key' => 'about_point3_icon', 'group' => 'story', 'label' => 'Point 3 — badge', 'label_ar' => 'النقطة 3 — الشارة', 'type' => 'text', 'default' => '3', 'default_ar' => '3', 'max' => 4],
        ['key' => 'about_point3_title', 'group' => 'story', 'label' => 'Point 3 — title', 'label_ar' => 'النقطة 3 — العنوان', 'type' => 'text', 'default' => 'Order online in seconds', 'default_ar' => 'اطلب أونلاين في ثوانٍ', 'max' => 60],
        ['key' => 'about_point3_text', 'group' => 'story', 'label' => 'Point 3 — text', 'label_ar' => 'النقطة 3 — النص', 'type' => 'text', 'default' => 'Real-time menu availability, secure checkout, live status updates.', 'default_ar' => 'توفّر القائمة الفوري، ودفع آمن، وتحديثات لحظية للحالة.', 'max' => 160],

        /* ---------------- Contact & hours ---------------- */
        ['key' => 'contact_title', 'group' => 'contact', 'label' => 'Contact card — heading', 'label_ar' => 'بطاقة التواصل — العنوان', 'type' => 'text', 'default' => 'Visit or reach us', 'default_ar' => 'زرنا أو تواصل معنا', 'max' => 60],
        ['key' => 'contact_address_label', 'group' => 'contact', 'label' => 'Contact — address label', 'label_ar' => 'التواصل — عنوان العنوان', 'type' => 'text', 'default' => 'Address', 'default_ar' => 'العنوان', 'max' => 30],
        ['key' => 'contact_address', 'group' => 'contact', 'label' => 'Contact — address', 'label_ar' => 'التواصل — العنوان', 'type' => 'text', 'default' => '12-C Zamzama Boulevard, Clifton, Karachi', 'default_ar' => '12-C Zamzama Boulevard, Clifton, Karachi', 'max' => 180],
        ['key' => 'contact_phone_label', 'group' => 'contact', 'label' => 'Contact — phone label', 'label_ar' => 'التواصل — عنوان الهاتف', 'type' => 'text', 'default' => 'Phone', 'default_ar' => 'الهاتف', 'max' => 30],
        ['key' => 'contact_phone', 'group' => 'contact', 'label' => 'Contact — main phone', 'label_ar' => 'التواصل — الهاتف الرئيسي', 'type' => 'phone', 'default' => '+92 21 111 728 674', 'default_ar' => '+92 21 111 728 674', 'max' => 30, 'required' => true],
        ['key' => 'contact_phone_secondary', 'group' => 'contact', 'label' => 'Contact — extra phone / WhatsApp', 'label_ar' => 'التواصل — هاتف إضافي / واتساب', 'type' => 'phone', 'default' => '', 'default_ar' => '', 'max' => 30, 'hint' => 'Optional. Shown as a second line under the main phone number.', 'hint_ar' => 'اختياري. يظهر كسطر ثانٍ أسفل رقم الهاتف الرئيسي.'],
        ['key' => 'contact_email_label', 'group' => 'contact', 'label' => 'Contact — email label', 'label_ar' => 'التواصل — عنوان البريد', 'type' => 'text', 'default' => 'Email', 'default_ar' => 'البريد الإلكتروني', 'max' => 30],
        ['key' => 'contact_email', 'group' => 'contact', 'label' => 'Contact — email', 'label_ar' => 'التواصل — البريد الإلكتروني', 'type' => 'email', 'default' => 'hello@tarmez.example', 'default_ar' => 'hello@tarmez.example', 'max' => 120, 'required' => true],
        ['key' => 'contact_map_url', 'group' => 'contact', 'label' => 'Google Maps link', 'label_ar' => 'رابط خرائط جوجل', 'type' => 'url', 'default' => '', 'default_ar' => '', 'max' => 500, 'hint' => 'Optional. Clicking the address in the contact card opens this link.', 'hint_ar' => 'اختياري. الضغط على العنوان في بطاقة التواصل يفتح هذا الرابط.'],
        ['key' => 'contact_hours', 'group' => 'contact', 'label' => 'Opening hours', 'label_ar' => 'ساعات العمل', 'type' => 'json', 'default' => '[{"label":"Mon – Thu","value":"5:00 PM – 11:00 PM"},{"label":"Fri – Sun","value":"1:00 PM – 12:00 AM"}]', 'default_ar' => '[{"label":"الإثنين – الخميس","value":"5:00 مساءً – 11:00 مساءً"},{"label":"الجمعة – الأحد","value":"1:00 ظهرًا – 12:00 منتصف الليل"}]', 'max' => 2000, 'hint' => 'One row per line: "Mon – Thu | 5:00 PM – 11:00 PM". Add one row per day if you prefer.', 'hint_ar' => 'صف واحد لكل سطر: "الإثنين – الخميس | 5:00 مساءً – 11:00 مساءً".'],
        ['key' => 'contact_card_title', 'group' => 'contact', 'label' => 'Contact card — message heading', 'label_ar' => 'بطاقة التواصل — عنوان الرسالة', 'type' => 'text', 'default' => 'Send us a message', 'default_ar' => 'أرسل لنا رسالة', 'max' => 60],
        ['key' => 'contact_card_text', 'group' => 'contact', 'label' => 'Contact card — message text', 'label_ar' => 'بطاقة التواصل — نص الرسالة', 'type' => 'multiline', 'default' => 'For order or reservation questions, call us directly for the fastest response. General inquiries:', 'default_ar' => 'لأي استفسار عن الطلبات أو الحجوزات، اتصل بنا مباشرة للحصول على أسرع رد. وللاستفسارات العامة:', 'max' => 300],
        ['key' => 'social_instagram', 'group' => 'contact', 'label' => 'Instagram link', 'label_ar' => 'رابط إنستغرام', 'type' => 'url', 'default' => '#', 'default_ar' => '#', 'max' => 300],
        ['key' => 'social_facebook', 'group' => 'contact', 'label' => 'Facebook link', 'label_ar' => 'رابط فيسبوك', 'type' => 'url', 'default' => '#', 'default_ar' => '#', 'max' => 300],
        ['key' => 'social_tiktok', 'group' => 'contact', 'label' => 'TikTok link', 'label_ar' => 'رابط تيك توك', 'type' => 'url', 'default' => '#', 'default_ar' => '#', 'max' => 300],

        /* ---------------- Section texts ---------------- */
        ['key' => 'menu_eyebrow', 'group' => 'texts', 'label' => 'Menu — eyebrow', 'label_ar' => 'القائمة — السطر الوصفي', 'type' => 'text', 'default' => 'The Menu', 'default_ar' => 'قائمة الطعام', 'max' => 60],
        ['key' => 'menu_title', 'group' => 'texts', 'label' => 'Menu — headline', 'label_ar' => 'القائمة — العنوان', 'type' => 'text', 'default' => 'Order straight from the kitchen', 'default_ar' => 'اطلب مباشرة من المطبخ', 'max' => 120],
        ['key' => 'menu_text', 'group' => 'texts', 'label' => 'Menu — paragraph', 'label_ar' => 'القائمة — الفقرة', 'type' => 'multiline', 'default' => 'This menu is loaded live from the Tarmez database — add dishes to your cart and check out below.', 'default_ar' => 'تُحمَّل هذه القائمة مباشرةً من قاعدة بيانات تارمز — أضف الأطباق إلى سلتك وأكمل الطلب بالأسفل.', 'max' => 400],
        ['key' => 'reservation_eyebrow', 'group' => 'texts', 'label' => 'Reservation — eyebrow', 'label_ar' => 'الحجز — السطر الوصفي', 'type' => 'text', 'default' => 'Book Ahead', 'default_ar' => 'احجز مسبقًا', 'max' => 60],
        ['key' => 'reservation_title', 'group' => 'texts', 'label' => 'Reservation — headline', 'label_ar' => 'الحجز — العنوان', 'type' => 'text', 'default' => 'Reserve your table', 'default_ar' => 'احجز طاولتك', 'max' => 120],
        ['key' => 'reservation_text', 'group' => 'texts', 'label' => 'Reservation — paragraph', 'label_ar' => 'الحجز — الفقرة', 'type' => 'text', 'default' => 'Tables fill quickly on weekends. Secure yours in under a minute.', 'default_ar' => 'تمتلئ الطاولات سريعًا في عطلة نهاية الأسبوع. ثبّت طاولتك في أقل من دقيقة.', 'max' => 300],
        ['key' => 'reservation_perk1', 'group' => 'texts', 'label' => 'Reservation perk 1', 'label_ar' => 'ميزة الحجز 1', 'type' => 'text', 'default' => 'Instant confirmation by email', 'default_ar' => 'تأكيد فوري عبر البريد الإلكتروني', 'max' => 120],
        ['key' => 'reservation_perk2', 'group' => 'texts', 'label' => 'Reservation perk 2', 'label_ar' => 'ميزة الحجز 2', 'type' => 'text', 'default' => 'Free cancellation up to 2 hours before', 'default_ar' => 'إلغاء مجاني حتى ساعتين قبل الموعد', 'max' => 120],
        ['key' => 'reservation_perk3', 'group' => 'texts', 'label' => 'Reservation perk 3', 'label_ar' => 'ميزة الحجز 3', 'type' => 'text', 'default' => 'Special requests welcome (allergies, occasions)', 'default_ar' => 'نرحّب بالطلبات الخاصة (الحساسية، المناسبات)', 'max' => 120],
        ['key' => 'reservation_perk4', 'group' => 'texts', 'label' => 'Reservation perk 4', 'label_ar' => 'ميزة الحجز 4', 'type' => 'text', 'default' => 'Priority seating for parties of 6+', 'default_ar' => 'أولوية في الجلوس للمجموعات من 6 أشخاص فأكثر', 'max' => 120],
        ['key' => 'reviews_eyebrow', 'group' => 'texts', 'label' => 'Reviews — eyebrow', 'label_ar' => 'الآراء — السطر الوصفي', 'type' => 'text', 'default' => 'Guest Reviews', 'default_ar' => 'آراء الضيوف', 'max' => 60],
        ['key' => 'reviews_title', 'group' => 'texts', 'label' => 'Reviews — headline', 'label_ar' => 'الآراء — العنوان', 'type' => 'text', 'default' => 'What diners are saying', 'default_ar' => 'ماذا يقول ضيوفنا', 'max' => 120],
        ['key' => 'footer_about', 'group' => 'texts', 'label' => 'Footer — about text', 'label_ar' => 'التذييل — نبذة', 'type' => 'multiline', 'default' => 'A modern fine-dining kitchen serving Karachi since 2019 — dine in, pick up, or have it delivered.', 'default_ar' => 'مطبخ راقٍ حديث يخدم كراتشي منذ 2019 — تعرّف في المطعم، أو استلم طلبك، أو اطلب للتوصيل.', 'max' => 400],
        ['key' => 'footer_explore_title', 'group' => 'texts', 'label' => 'Footer — "Explore" heading', 'label_ar' => 'التذييل — عنوان "تصفّح"', 'type' => 'text', 'default' => 'Explore', 'default_ar' => 'تصفّح', 'max' => 40],
        ['key' => 'footer_account_title', 'group' => 'texts', 'label' => 'Footer — "Account" heading', 'label_ar' => 'التذييل — عنوان "الحساب"', 'type' => 'text', 'default' => 'Account', 'default_ar' => 'الحساب', 'max' => 40],
        ['key' => 'footer_support_title', 'group' => 'texts', 'label' => 'Footer — "Support" heading', 'label_ar' => 'التذييل — عنوان "الدعم"', 'type' => 'text', 'default' => 'Support', 'default_ar' => 'الدعم', 'max' => 40],
    ];
}

/* =========================================================
   Image slots — each one maps to a real <img> in the storefront.
   width/height = the crop the server applies (matches the CSS
   aspect ratio of the container, so images never get stretched).
   ========================================================= */

function site_content_image_slots(): array
{
    return [
        ['key' => 'logo', 'label' => 'Logo', 'label_ar' => 'الشعار', 'default_url' => 'assets/logo.svg', 'width' => 400, 'height' => 400, 'alt' => 'Tarmez', 'hint' => 'Used in the navbar and the footer.'],
        ['key' => 'hero_main', 'label' => 'Hero — main photo', 'label_ar' => 'الواجهة — الصورة الرئيسية', 'default_url' => 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=900&q=80', 'width' => 1000, 'height' => 1250, 'alt' => 'Tarmez candlelit dining hall with plated dishes'],
        ['key' => 'hero_accent', 'label' => 'Hero — accent photo', 'label_ar' => 'الواجهة — الصورة الفرعية', 'default_url' => 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&q=80', 'width' => 700, 'height' => 700, 'alt' => 'Slow-braised lamb shank plated dish'],
        ['key' => 'about_main', 'label' => 'Story — main photo', 'label_ar' => 'القصة — الصورة الرئيسية', 'default_url' => 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80', 'width' => 900, 'height' => 1125, 'alt' => 'Chef plating a dish in the Tarmez kitchen'],
        ['key' => 'about_accent', 'label' => 'Story — accent photo', 'label_ar' => 'القصة — الصورة الفرعية', 'default_url' => 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=500&q=80', 'width' => 700, 'height' => 700, 'alt' => 'Tarmez dining hall interior'],
        ['key' => 'gallery_1', 'label' => 'Gallery — image 1', 'label_ar' => 'المعرض — صورة 1', 'default_url' => 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&q=80', 'width' => 800, 'height' => 600, 'alt' => 'Restaurant interior'],
        ['key' => 'gallery_2', 'label' => 'Gallery — image 2', 'label_ar' => 'المعرض — صورة 2', 'default_url' => 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&q=80', 'width' => 800, 'height' => 600, 'alt' => 'Plated dish'],
        ['key' => 'gallery_3', 'label' => 'Gallery — image 3', 'label_ar' => 'المعرض — صورة 3', 'default_url' => 'https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?w=400&q=80', 'width' => 800, 'height' => 600, 'alt' => 'Dessert plating'],
        ['key' => 'gallery_4', 'label' => 'Gallery — image 4', 'label_ar' => 'المعرض — صورة 4', 'default_url' => 'https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?w=400&q=80', 'width' => 800, 'height' => 600, 'alt' => 'Chef at work'],
        ['key' => 'gallery_5', 'label' => 'Gallery — image 5', 'label_ar' => 'المعرض — صورة 5', 'default_url' => 'https://images.unsplash.com/photo-1552566626-52f8b828add9?w=400&q=80', 'width' => 800, 'height' => 600, 'alt' => 'Table setting'],
    ];
}

/* =========================================================
   Helpers
   ========================================================= */

/** Default value map: key => default string. */
function site_content_defaults(): array
{
    $map = [];
    foreach (site_content_fields() as $field) {
        $map[$field['key']] = $field['default'];
    }
    return $map;
}

/** Arabic default value map: key => Arabic default string. */
function site_content_defaults_ar(): array
{
    $map = [];
    foreach (site_content_fields() as $field) {
        $map[$field['key']] = $field['default_ar'] ?? $field['default'];
    }
    return $map;
}

/** Image default map: key => ['url' => ..., 'alt' => ...]. */
function site_content_image_defaults(): array
{
    $map = [];
    foreach (site_content_image_slots() as $slot) {
        $map[$slot['key']] = ['url' => $slot['default_url'], 'alt' => $slot['alt']];
    }
    return $map;
}

/** Custom settings merged over the shipped defaults (English). */
function site_content_get_settings(PDO $pdo): array
{
    $values = site_content_defaults();
    foreach (site_content_get_overrides($pdo, 'en') as $key => $value) {
        if (trim($value) === '') continue;               // empty = "use the default"
        $values[$key] = $value;
    }
    return $values;
}

/**
 * The Arabic view of the website texts.
 * Chain: stored Arabic value → shipped Arabic default → English value.
 * The English value is only used when a field has no Arabic default at all.
 */
function site_content_get_settings_ar(PDO $pdo): array
{
    $values = site_content_defaults_ar();
    $english = site_content_get_settings($pdo);
    foreach ($values as $key => $value) {
        if (trim((string) $value) === '') {
            $values[$key] = $english[$key] ?? '';
        }
    }
    foreach (site_content_get_overrides($pdo, 'ar') as $key => $value) {
        if (trim($value) === '') continue;               // empty = "use the default"
        if (!array_key_exists($key, $values)) continue;  // unknown/legacy key
        $values[$key] = $value;
    }
    return $values;
}

/**
 * Only the keys that were actually customised (for the admin panel).
 * $lang: 'en' reads content_value, 'ar' reads content_value_ar.
 */
function site_content_get_overrides(PDO $pdo, string $lang = 'en'): array
{
    $column = ($lang === 'ar') ? 'content_value_ar' : 'content_value';
    if (!i18n_column_exists($pdo, 'site_settings', $column)) {
        return [];
    }
    $stmt = $pdo->prepare(
        "SELECT content_key, $column AS content_value FROM site_settings WHERE restaurant_id = :rid"
    );
    $stmt->execute([':rid' => SITE_RESTAURANT_ID]);
    $out = [];
    foreach ($stmt->fetchAll() as $row) {
        $out[(string) $row['content_key']] = (string) ($row['content_value'] ?? '');
    }
    return $out;
}

/** Custom images merged over the shipped defaults. */
function site_content_get_images(PDO $pdo): array
{
    $images = site_content_image_defaults();
    $stmt = $pdo->prepare('SELECT image_key, image_url, alt_text FROM site_images WHERE restaurant_id = :rid');
    $stmt->execute([':rid' => SITE_RESTAURANT_ID]);
    foreach ($stmt->fetchAll() as $row) {
        $key = (string) $row['image_key'];
        if (!array_key_exists($key, $images)) continue;
        $url = trim((string) ($row['image_url'] ?? ''));
        if ($url === '') continue;
        $images[$key]['url'] = $url;
        if (!empty($row['alt_text'])) $images[$key]['alt'] = (string) $row['alt_text'];
    }
    return $images;
}

/**
 * Validate a batch of incoming values against the schema.
 * Returns [isValid, errors, cleanedValues].
 */
function site_content_validate(array $values): array
{
    $schema = [];
    foreach (site_content_fields() as $field) $schema[$field['key']] = $field;

    $errors = [];
    $clean = [];

    foreach ($values as $key => $value) {
        $key = (string) $key;
        if (!isset($schema[$key])) {
            $errors[$key] = 'Unknown content field.';
            continue;
        }
        $field = $schema[$key];
        $value = is_scalar($value) ? (string) $value : '';

        // No HTML / script content is ever stored.
        if (preg_match('/<[^>]*>/', $value) || stripos($value, '<script') !== false) {
            $errors[$key] = 'HTML is not allowed in this field.';
            continue;
        }
        if (str_contains($value, 'javascript:')) {
            $errors[$key] = 'javascript: links are not allowed.';
            continue;
        }

        $max = (int) ($field['max'] ?? 1000);
        if (mb_strlen($value) > $max) {
            $errors[$key] = 'This text is too long (max ' . $max . ' characters).';
            continue;
        }

        switch (true) {
            case $field['type'] === 'email':
                if ($value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$key] = 'Enter a valid email address.';
                    continue 2;
                }
                break;
            case $field['type'] === 'url':
                if ($value !== '' && $value !== '#' && !filter_var($value, FILTER_VALIDATE_URL)) {
                    $errors[$key] = 'Enter a valid link starting with https://';
                    continue 2;
                }
                if (str_starts_with(strtolower($value), 'http://') && $value !== '#') {
                    $errors[$key] = 'Links must use https://';
                    continue 2;
                }
                break;
            case $field['type'] === 'phone':
                if ($value !== '' && !preg_match('/^[0-9+()\-.\s]{6,30}$/', $value)) {
                    $errors[$key] = 'Enter a valid phone number.';
                    continue 2;
                }
                break;
            case $field['type'] === 'json':
                $decoded = json_decode($value, true);
                if (!is_array($decoded)) {
                    $errors[$key] = 'This field must be a list of rows.';
                    continue 2;
                }
                $rows = [];
                foreach ($decoded as $row) {
                    if (!is_array($row)) continue;
                    $label = trim(strip_tags((string) ($row['label'] ?? '')));
                    $val   = trim(strip_tags((string) ($row['value'] ?? '')));
                    if ($label === '' && $val === '') continue;
                    if (mb_strlen($label) > 60 || mb_strlen($val) > 60) {
                        $errors[$key] = 'Each row is limited to 60 characters per column.';
                        continue 3;
                    }
                    $rows[] = ['label' => $label, 'value' => $val];
                }
                if (count($rows) > 14) {
                    $errors[$key] = 'Too many rows (max 14).';
                    continue 2;
                }
                $value = json_encode($rows, JSON_UNESCAPED_UNICODE);
                break;
            case $field['type'] === 'multiline':
                $value = trim($value);
                break;
            default:
                $value = trim($value);
        }

        if (!empty($field['required']) && $value === '') {
            $errors[$key] = $field['label'] . ' is required.';
            continue;
        }

        $clean[$key] = $value;
    }

    return [empty($errors), $errors, $clean];
}

/**
 * Persist a batch of values. A value that is empty OR identical to the
 * shipped default is not stored — the default is then used, and the
 * "customised" markers in the panel stay truthful.
 *
 * $lang: 'en' writes content_value, 'ar' writes content_value_ar.
 */
function site_content_save_settings(PDO $pdo, array $clean, ?array $actor, string $lang = 'en'): void
{
    $schema = [];
    $defaults = [];
    foreach (site_content_fields() as $field) {
        $schema[$field['key']] = $field['group'] ?? 'general';
        $defaults[$field['key']] = (string) ($lang === 'ar'
            ? ($field['default_ar'] ?? $field['default'])
            : $field['default']);
    }

    $column = ($lang === 'ar') ? 'content_value_ar' : 'content_value';
    if (!i18n_column_exists($pdo, 'site_settings', $column)) {
        // The database has not received the multi-language migration yet —
        // the English texts still work, the Arabic ones are simply not stored.
        return;
    }

    $upsert = $pdo->prepare('
        INSERT INTO site_settings (restaurant_id, content_key, ' . $column . ', content_group, updated_by)
        VALUES (:rid, :k, :v, :g, :by)
        ON DUPLICATE KEY UPDATE
            ' . $column . ' = VALUES(' . $column . '),
            content_group = VALUES(content_group),
            updated_by    = VALUES(updated_by),
            updated_at   = CURRENT_TIMESTAMP
    ');
    $delete = $pdo->prepare('DELETE FROM site_settings WHERE restaurant_id = :rid AND content_key = :k');

    foreach ($clean as $key => $value) {
        $value = (string) $value;
        if (trim($value) === '' || (isset($defaults[$key]) && $value === $defaults[$key])) {
            $delete->execute([':rid' => SITE_RESTAURANT_ID, ':k' => $key]);
            continue;
        }
        $upsert->execute([
            ':rid' => SITE_RESTAURANT_ID,
            ':k'   => $key,
            ':v'   => $value,
            ':g'   => $schema[$key] ?? 'general',
            ':by'  => $actor['sub'] ?? null,
        ]);
    }
}

/** Remove every override of a group (or all groups) → back to defaults. */
function site_content_reset_group(PDO $pdo, ?string $group): int
{
    if ($group === null) {
        $stmt = $pdo->prepare('DELETE FROM site_settings WHERE restaurant_id = :rid');
        $stmt->execute([':rid' => SITE_RESTAURANT_ID]);
        return $stmt->rowCount();
    }

    $keys = [];
    foreach (site_content_fields() as $field) {
        if (($field['group'] ?? '') === $group) $keys[] = $field['key'];
    }
    if (!$keys) return 0;

    $stmt = $pdo->prepare('DELETE FROM site_settings WHERE restaurant_id = :rid AND content_key = :k');
    $deleted = 0;
    foreach ($keys as $key) {
        $stmt->execute([':rid' => SITE_RESTAURANT_ID, ':k' => $key]);
        $deleted += $stmt->rowCount();
    }
    return $deleted;
}

/**
 * A cheap fingerprint of the current content state (optimistic locking).
 *
 * The payload shape is part of the fingerprint: when the API starts
 * shipping additional data (for example the Arabic texts), the version
 * changes so every client re-fetches instead of receiving a 304 for a
 * payload it never saw before.
 */
function site_content_version(PDO $pdo): string
{
    $stmt = $pdo->prepare('
        SELECT COALESCE(MAX(updated_at), "1970-01-01 00:00:00") FROM (
            SELECT updated_at FROM site_settings WHERE restaurant_id = :rid1
            UNION ALL
            SELECT updated_at FROM site_images  WHERE restaurant_id = :rid2
            UNION ALL
            SELECT updated_at FROM reviews      WHERE restaurant_id = :rid3
        ) AS stamps
    ');
    $stmt->execute([
        ':rid1' => SITE_RESTAURANT_ID,
        ':rid2' => SITE_RESTAURANT_ID,
        ':rid3' => SITE_RESTAURANT_ID,
    ]);
    return md5(SITE_CONTENT_PAYLOAD_VERSION . '|' . (string) $stmt->fetchColumn());
}

/** Published reviews for the public website, ordered for display. */
function site_content_public_reviews(PDO $pdo): array
{
    $columns = i18n_select_list($pdo, 'reviews', ['id', 'author_name', 'author_meta', 'author_avatar', 'rating', 'content', 'source', 'is_featured', 'display_order']);
    $stmt = $pdo->prepare("
        SELECT $columns
        FROM reviews
        WHERE restaurant_id = :rid AND status = 'published'
        ORDER BY is_featured DESC, display_order ASC, id ASC
    ");
    $stmt->execute([':rid' => SITE_RESTAURANT_ID]);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['id'] = (int) $row['id'];
        $row['rating'] = (int) $row['rating'];
        $row['is_featured'] = (bool) $row['is_featured'];
        $row['display_order'] = (int) $row['display_order'];
    }
    return $rows;
}
