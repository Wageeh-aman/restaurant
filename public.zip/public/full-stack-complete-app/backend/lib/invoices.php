<?php
/**
 * Savoria — Full Stack Complete App
 * backend/lib/invoices.php — the invoice number and the order number.
 *
 * Two numbers, two different jobs:
 *
 *   • The INVOICE NUMBER is the permanent number of the order. It is
 *     the order's own id: it never changes, never repeats and is
 *     never reset, so it can be printed on a receipt and quoted to
 *     the customer for years.
 *
 *   • The ORDER NUMBER is the operational number the kitchen works
 *     with. It is a sequence of its own that the manager can reset
 *     from the admin panel — after a reset the next order is order #1
 *     and the counter counts up again from there.
 *
 * The order number is handed out inside the order transaction, so a
 * failed or rolled-back order never burns a number and two orders can
 * never share one.
 *
 * Every helper degrades gracefully: if the migration has not been run
 * yet, the counter simply reports 0 and the orders are stored without
 * an order number, so the API keeps working.
 */

declare(strict_types=1);

const ORDER_COUNTER_ID = 1;

/** Is the numbering installed? */
function savoria_order_numbering_ready(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;

    return $ready = schema_table_exists($pdo, 'order_counters')
        && i18n_column_exists($pdo, 'orders', 'order_number');
}

/** The number that was handed out last (0 when nothing was issued yet). */
function savoria_order_counter(PDO $pdo): int
{
    if (!savoria_order_numbering_ready($pdo)) return 0;
    try {
        $stmt = $pdo->prepare('SELECT current_value FROM order_counters WHERE id = ?');
        $stmt->execute([ORDER_COUNTER_ID]);
        return (int) $stmt->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Hand out the next order number.
 *
 * Call this inside the order transaction: the counter row is locked
 * (FOR UPDATE) so two concurrent orders can never receive the same
 * number, and a rollback restores the previous value.
 */
function savoria_next_order_number(PDO $pdo): int
{
    if (!savoria_order_numbering_ready($pdo)) return 0;

    $stmt = $pdo->prepare('SELECT current_value FROM order_counters WHERE id = ? FOR UPDATE');
    $stmt->execute([ORDER_COUNTER_ID]);
    $current = (int) $stmt->fetchColumn();
    $next = $current + 1;

    $upd = $pdo->prepare('UPDATE order_counters SET current_value = ? WHERE id = ?');
    $upd->execute([$next, ORDER_COUNTER_ID]);

    return $next;
}

/**
 * Reset the order counter, so the next order is order #1 again.
 * The invoice numbers are not touched.
 * Returns the new value.
 */
function savoria_reset_order_counter(PDO $pdo): int
{
    if (!savoria_order_numbering_ready($pdo)) return 0;
    $upd = $pdo->prepare('UPDATE order_counters SET current_value = 0 WHERE id = ?');
    $upd->execute([ORDER_COUNTER_ID]);
    return 0;
}
