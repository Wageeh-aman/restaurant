<?php
/**
 * Savoria — Full-Stack Complete App
 * backend/lib/helpers.php — shared response and request helpers
 */

declare(strict_types=1);

function json_response(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function json_success($data = null, string $message = 'OK', int $statusCode = 200): void
{
    json_response(['success' => true, 'message' => $message, 'data' => $data], $statusCode);
}

function json_error(string $message, int $statusCode = 400, array $errors = []): void
{
    json_response(['success' => false, 'message' => $message, 'errors' => $errors], $statusCode);
}

function get_request_body(): array
{
    $raw = file_get_contents('php://input');
    if (empty($raw)) return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

/**
 * Convert Arabic-Indic digits (٠-٩ / ۰-۹) to ASCII 0-9 so customers
 * typing on an Arabic keyboard do not fail phone/table validation.
 */
function normalize_digits(mixed $value): string
{
    $s = (string) $value;
    $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return str_replace($persian, $arabic, str_replace($arabic, ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $s));
}

function get_route_path(): string
{
    $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    if ($scriptDir !== '/' && str_starts_with($uri, $scriptDir)) {
        $uri = substr($uri, strlen($scriptDir));
    }
    $uri = '/' . trim($uri, '/');
    return $uri === '//' ? '/' : $uri;
}

function sanitize_string($value): string
{
    return trim(strip_tags((string) $value));
}

/**
 * The last 10 digits of a phone number — the part every format shares
 * (05xxxxxxxx, +9665xxxxxxxx, 966-5x-xxx-xxxx). Used for identity checks
 * so the same person is recognised whatever way the number was typed.
 */
function phone_last10(string $raw): string
{
    $digits = preg_replace('/\D/', '', normalize_digits($raw));
    return $digits !== '' ? substr($digits, -10) : '';
}

/** SQL expression that yields the comparable form of a phone column. */
function phone_sql_expr(string $column): string
{
    return "RIGHT(REGEXP_REPLACE(COALESCE({$column}, ''), '[^0-9]', ''), 10)";
}

/**
 * Find the (customer) login that owns a phone number.
 * Registration refuses duplicate numbers, but legacy data may contain
 * several accounts for one number — the most recent customer wins.
 */
function user_id_for_phone(PDO $pdo, string $phone, bool $customersOnly = true): ?int
{
    $last10 = phone_last10($phone);
    if (strlen($last10) < 7) return null;

    $sql = 'SELECT id FROM users WHERE is_active = 1 AND ' . phone_sql_expr('phone') . ' = :phone';
    if ($customersOnly) $sql .= " AND role = 'customer'";
    $sql .= ' ORDER BY id DESC LIMIT 1';

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':phone' => $last10]);
    $id = $stmt->fetchColumn();
    return $id ? (int) $id : null;
}

/** Does a phone number already belong to any login (any role)? */
function user_exists_for_phone(PDO $pdo, string $phone, ?int $exceptUserId = null): bool
{
    $last10 = phone_last10($phone);
    if (strlen($last10) < 7) return false;

    $sql = 'SELECT id FROM users WHERE ' . phone_sql_expr('phone') . ' = :phone';
    if ($exceptUserId !== null) $sql .= ' AND id <> :except';
    $sql .= ' LIMIT 1';

    $stmt = $pdo->prepare($sql);
    $params = [':phone' => $last10];
    if ($exceptUserId !== null) $params[':except'] = $exceptUserId;
    $stmt->execute($params);
    return (bool) $stmt->fetchColumn();
}

/**
 * Normalize a reservation time string into MySQL TIME format (HH:MM:SS).
 * Accepts both 24-hour ("19:30") and 12-hour with AM/PM ("7:30 PM") input,
 * since the frontend's <select> sends the latter. Returns null if the
 * string cannot be parsed into a valid time.
 */
function normalize_reservation_time(string $raw): ?string
{
    $raw = trim($raw);
    if ($raw === '') return null;

    // 24-hour "HH:MM" or "HH:MM:SS"
    if (preg_match('/^([01]?\d|2[0-3]):([0-5]\d)(:([0-5]\d))?$/', $raw, $m)) {
        return sprintf('%02d:%02d:%02d', (int)$m[1], (int)$m[2], (int)($m[4] ?? 0));
    }

    // 12-hour "H:MM AM/PM"
    if (preg_match('/^(0?[1-9]|1[0-2]):([0-5]\d)\s*(AM|PM)$/i', $raw, $m)) {
        $hour = (int) $m[1];
        $minute = (int) $m[2];
        $meridiem = strtoupper($m[3]);
        if ($meridiem === 'PM' && $hour !== 12) $hour += 12;
        if ($meridiem === 'AM' && $hour === 12) $hour = 0;
        return sprintf('%02d:%02d:00', $hour, $minute);
    }

    return null;
}

/**
 * Attempt to resolve the current user from an Authorization header
 * without forcing authentication — used on routes like POST /orders
 * that work for both guests and logged-in customers.
 */
function get_optional_user(): ?array
{
    $token = get_bearer_token();
    if (!$token) return null;
    return jwt_decode($token, env_required_secret('JWT_SECRET'));
}
