<?php
/**
 * Savoria — Full-Stack Complete App
 * lib/order_visibility.php — customer-controlled order visibility
 *
 * The customer can dismiss an order card (and the notifications that point
 * at it) from their account without deleting anything from management's
 * side. The dismissal is per account, so two customers sharing a phone or
 * a legacy order never hide each other's history.
 */

declare(strict_types=1);

/**
 * Create the per-account hidden-orders table on first use. Idempotent and
 * safe to call on every request that filters the customer's order list.
 */
function customer_hidden_orders_ensure_schema(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;

    try {
        $pdo->exec('
            CREATE TABLE IF NOT EXISTS customer_hidden_orders (
                user_id    INT UNSIGNED NOT NULL,
                order_id   INT UNSIGNED NOT NULL,
                hidden_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, order_id),
                KEY idx_customer_hidden_order (order_id),
                CONSTRAINT fk_customer_hidden_user
                    FOREIGN KEY (user_id) REFERENCES users(id)
                    ON DELETE CASCADE ON UPDATE CASCADE,
                CONSTRAINT fk_customer_hidden_order
                    FOREIGN KEY (order_id) REFERENCES orders(id)
                    ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB
        ');
    } catch (Throwable $e) {
        // A concurrent request may have created it first; verify below.
    }

    schema_cache_forget();
    $ready = schema_table_exists($pdo, 'customer_hidden_orders');
    return $ready;
}

/**
 * Hide one order for one customer. INSERT IGNORE makes the action
 * idempotent: tapping the close button twice is harmless.
 */
function customer_hide_order(PDO $pdo, int $userId, int $orderId): bool
{
    if ($userId <= 0 || $orderId <= 0) return false;
    if (!customer_hidden_orders_ensure_schema($pdo)) return false;

    $stmt = $pdo->prepare('
        INSERT IGNORE INTO customer_hidden_orders (user_id, order_id)
        VALUES (:uid, :oid)
    ');
    $stmt->execute([':uid' => $userId, ':oid' => $orderId]);
    return true;
}
