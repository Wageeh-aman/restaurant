<?php
/**
 * Savoria — Full-Stack Complete App
 * lib/notifications.php — customer notification centre
 *
 * Every row belongs to one login (user_id) and is written from a real
 * event: an order changing status, a coupon being issued, or a reward
 * being granted. Nothing here is generated demo data.
 *
 * Deduplication: a UNIQUE dedupe_key plus INSERT IGNORE means a retried
 * request (or the same status applied twice) can never create a second
 * notification for the same event.
 *
 * Both languages are stored on the row, so the interface can switch
 * between Arabic and English without another request.
 */

declare(strict_types=1);

require_once __DIR__ . '/order_visibility.php';

const NOTIFICATION_TYPES = ['order', 'coupon', 'loyalty', 'account', 'reward', 'reservation'];
const NOTIFICATION_LINK_TYPES = ['order', 'coupon', 'coupons', 'account', 'reservation'];

/**
 * Create the notifications table on first use. Idempotent and safe to
 * call on every request that may write a notification — the result is
 * cached for the rest of the request.
 */
function notifications_ensure_schema(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;

    try {
        $pdo->exec('
            CREATE TABLE IF NOT EXISTS notifications (
                id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id     INT UNSIGNED NOT NULL,
                type        ENUM("order","coupon","loyalty","account","reward","reservation") NOT NULL DEFAULT "account",
                event_key   VARCHAR(64) NOT NULL,
                title       VARCHAR(160) NOT NULL,
                title_ar    VARCHAR(160) DEFAULT NULL,
                body        VARCHAR(500) DEFAULT NULL,
                body_ar     VARCHAR(500) DEFAULT NULL,
                link_type   VARCHAR(24) DEFAULT NULL,
                link_id     INT UNSIGNED DEFAULT NULL,
                dedupe_key  VARCHAR(190) DEFAULT NULL,
                is_read     TINYINT(1) NOT NULL DEFAULT 0,
                read_at     DATETIME DEFAULT NULL,
                created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_notification_dedupe (dedupe_key),
                KEY idx_notification_user (user_id, is_read, created_at),
                CONSTRAINT fk_notification_user
                    FOREIGN KEY (user_id) REFERENCES users(id)
                    ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB
        ');
    } catch (Throwable $e) {
        // A concurrent request may have created it first; verify below.
    }

    // Reservations were added to the notification centre later than the
    // table itself. Widen the fixed ENUM on databases that predate them.
    try {
        $typeColumn = $pdo->query("SHOW COLUMNS FROM notifications LIKE 'type'")->fetch(PDO::FETCH_ASSOC);
        if ($typeColumn && stripos((string) ($typeColumn['Type'] ?? ''), 'reservation') === false) {
            $pdo->exec('ALTER TABLE notifications MODIFY COLUMN type
                ENUM("order","coupon","loyalty","account","reward","reservation") NOT NULL DEFAULT "account"');
        }
    } catch (Throwable $e) {
        // A concurrent request may have altered it first; inserts below
        // still work when the column already matches.
    }

    // The schema list is cached per request; refresh it so the new table
    // is visible to every later check in this same request.
    schema_cache_forget();
    $ready = schema_table_exists($pdo, 'notifications');
    return $ready;
}

/**
 * Resolve the login a notification belongs to, from an explicit user id
 * or from the phone number on the order/coupon.
 */
function notification_user_id(PDO $pdo, ?int $userId, ?string $phone = null): ?int
{
    if ($userId !== null && $userId > 0) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE id = :id AND is_active = 1');
        $stmt->execute([':id' => $userId]);
        $found = $stmt->fetchColumn();
        if ($found) return (int) $found;
    }
    if ($phone !== null && $phone !== '') {
        return user_id_for_phone($pdo, $phone, true);
    }
    return null;
}

/**
 * Insert one notification. Returns its id, or null when there is no
 * customer login to deliver it to (guest order) or the event was
 * already recorded (dedupe_key exists).
 */
function notification_create(PDO $pdo, array $data): ?int
{
    if (!notifications_ensure_schema($pdo)) return null;

    $userId = notification_user_id(
        $pdo,
        isset($data['user_id']) ? (int) $data['user_id'] : null,
        isset($data['phone']) ? (string) $data['phone'] : null
    );
    if ($userId === null) return null;

    $type = in_array($data['type'] ?? '', NOTIFICATION_TYPES, true) ? (string) $data['type'] : 'account';
    $linkType = in_array($data['link_type'] ?? '', NOTIFICATION_LINK_TYPES, true)
        ? (string) $data['link_type'] : null;
    $dedupe = isset($data['dedupe_key']) && $data['dedupe_key'] !== null
        ? substr((string) $data['dedupe_key'], 0, 190) : null;

    $stmt = $pdo->prepare('
        INSERT IGNORE INTO notifications
            (user_id, type, event_key, title, title_ar, body, body_ar,
             link_type, link_id, dedupe_key)
        VALUES
            (:user_id, :type, :event_key, :title, :title_ar, :body, :body_ar,
             :link_type, :link_id, :dedupe_key)
    ');
    $stmt->execute([
        ':user_id'   => $userId,
        ':type'      => $type,
        ':event_key' => substr((string) ($data['event_key'] ?? 'event'), 0, 64),
        ':title'     => substr(sanitize_string($data['title'] ?? 'Notification'), 0, 160),
        ':title_ar'  => isset($data['title_ar']) && $data['title_ar'] !== ''
            ? substr(sanitize_string($data['title_ar']), 0, 160) : null,
        ':body'      => isset($data['body']) && $data['body'] !== ''
            ? substr(sanitize_string($data['body']), 0, 500) : null,
        ':body_ar'   => isset($data['body_ar']) && $data['body_ar'] !== ''
            ? substr(sanitize_string($data['body_ar']), 0, 500) : null,
        ':link_type' => $linkType,
        ':link_id'   => isset($data['link_id']) && $data['link_id'] !== null ? (int) $data['link_id'] : null,
        ':dedupe_key'=> $dedupe,
    ]);

    $id = (int) $pdo->lastInsertId();
    if ($id > 0) return $id;

    // INSERT IGNORE swallowed a duplicate — return the existing row.
    if ($dedupe !== null) {
        $existing = $pdo->prepare('SELECT id FROM notifications WHERE dedupe_key = :key');
        $existing->execute([':key' => $dedupe]);
        $found = $existing->fetchColumn();
        if ($found) return (int) $found;
    }
    return null;
}

/**
 * Real order status change. Titles mirror exactly what happened to the
 * order; the same status never notifies twice (dedupe_key).
 */
function notification_order_status(PDO $pdo, array $order, string $status): ?int
{
    $orderId = (int) ($order['id'] ?? 0);
    if ($orderId <= 0) return null;

    $label = $order['order_number'] ?? $orderId;
    $tableNo = isset($order['table_number']) && $order['table_number'] !== null
        ? (int) $order['table_number'] : null;

    $copy = [
        'pending' => [
            'event' => 'order.created', 'type' => 'order',
            'title' => 'Order received', 'title_ar' => 'تم استلام طلبك',
            'body' => "We received order #{$label} and will confirm it shortly.",
            'body_ar' => "استلمنا طلبك رقم {$label} وسيتم تأكيده قريبًا.",
        ],
        'confirmed' => [
            'event' => 'order.status.confirmed', 'type' => 'order',
            'title' => 'Order confirmed', 'title_ar' => 'تم تأكيد طلبك',
            'body' => "Order #{$label} is confirmed and will be prepared soon.",
            'body_ar' => "تم تأكيد طلبك رقم {$label} وسيبدأ تحضيره قريبًا.",
        ],
        'preparing' => [
            'event' => 'order.status.preparing', 'type' => 'order',
            'title' => 'Your order is being prepared', 'title_ar' => 'طلبك قيد التحضير',
            'body' => "Order #{$label} is in the kitchen now.",
            'body_ar' => "طلبك رقم {$label} قيد التحضير في المطبخ الآن.",
        ],
        'out_for_delivery' => [
            'event' => 'order.status.out_for_delivery', 'type' => 'order',
            'title' => 'Out for delivery', 'title_ar' => 'طلبك في الطريق إليك',
            'body' => "Order #{$label} is on its way.",
            'body_ar' => "طلبك رقم {$label} في الطريق إليك الآن.",
        ],
        'delivered' => [
            'event' => 'order.status.delivered', 'type' => 'order',
            'title' => 'Order delivered', 'title_ar' => 'تم توصيل طلبك',
            'body' => "Order #{$label} was delivered. Enjoy your meal!",
            'body_ar' => "تم توصيل طلبك رقم {$label}. نتمنى لك وجبة شهية!",
        ],
        'completed' => [
            'event' => 'order.status.completed', 'type' => 'order',
            'title' => 'Order completed', 'title_ar' => 'تم إكمال طلبك',
            'body' => "Order #{$label} is complete. Thank you for dining with us.",
            'body_ar' => "اكتمل طلبك رقم {$label}. شكرًا لتناولك الطعام معنا.",
        ],
        'cancelled' => [
            'event' => 'order.status.cancelled', 'type' => 'order',
            'title' => 'Order cancelled', 'title_ar' => 'تم إلغاء طلبك',
            'body' => "Order #{$label} was cancelled. Contact us if you need help.",
            'body_ar' => "تم إلغاء طلبك رقم {$label}. تواصل معنا إذا كنت بحاجة للمساعدة.",
        ],
    ];

    if (!isset($copy[$status])) return null;
    $c = $copy[$status];

    if ($tableNo !== null && $status !== 'cancelled') {
        $c['body'] .= " (Table {$tableNo})";
        $c['body_ar'] .= " (طاولة {$tableNo})";
    }

    return notification_create($pdo, [
        'user_id'    => isset($order['user_id']) ? (int) $order['user_id'] : null,
        'phone'      => (string) ($order['phone'] ?? ''),
        'type'       => $c['type'],
        'event_key'  => $c['event'],
        'title'      => $c['title'],
        'title_ar'   => $c['title_ar'],
        'body'       => $c['body'],
        'body_ar'    => $c['body_ar'],
        'link_type'  => 'order',
        'link_id'    => $orderId,
        'dedupe_key' => $status === 'pending'
            ? "order:{$orderId}:created"
            : "order:{$orderId}:status:{$status}",
    ]);
}

/**
 * Real reservation status change: request received, confirmed, cancelled
 * or completed. The customer sees it in the notification centre and in
 * the reservations section of their account page.
 */
function notification_reservation_status(PDO $pdo, array $reservation, string $status): ?int
{
    $reservationId = (int) ($reservation['id'] ?? 0);
    if ($reservationId <= 0) return null;

    $party = (int) ($reservation['party_size'] ?? 0);
    $date = trim((string) ($reservation['reservation_date'] ?? ''));
    $time = substr(trim((string) ($reservation['reservation_time'] ?? '')), 0, 5);
    $when = trim($date . ($time !== '' ? ' ' . $time : ''));
    $partyEn = $party > 0 ? " for {$party}" : '';
    $partyAr = $party > 0 ? " لعدد {$party}" : '';

    $copy = [
        'pending' => [
            'event'    => 'reservation.created',
            'title'    => 'Reservation received',
            'title_ar' => 'تم استلام حجزك',
            'body'     => "We received your table request{$partyEn} on {$when}. We will confirm it shortly.",
            'body_ar'  => "استلمنا طلب حجز طاولتك{$partyAr} يوم {$when}. سيتم تأكيده قريبًا.",
        ],
        'confirmed' => [
            'event'    => 'reservation.status.confirmed',
            'title'    => 'Reservation confirmed',
            'title_ar' => 'تم تأكيد حجزك',
            'body'     => "Your table{$partyEn} on {$when} is confirmed.",
            'body_ar'  => "تم تأكيد طاولتك{$partyAr} يوم {$when}.",
        ],
        'cancelled' => [
            'event'    => 'reservation.status.cancelled',
            'title'    => 'Reservation cancelled',
            'title_ar' => 'تم إلغاء حجزك',
            'body'     => "Your table reservation on {$when} was cancelled. Contact us if you need help.",
            'body_ar'  => "تم إلغاء حجز الطاولة يوم {$when}. تواصل معنا إذا كنت بحاجة للمساعدة.",
        ],
        'completed' => [
            'event'    => 'reservation.status.completed',
            'title'    => 'Reservation completed',
            'title_ar' => 'اكتمل حجزك',
            'body'     => "Thank you for dining with us on {$when}.",
            'body_ar'  => "شكرًا لتناولك الطعام معنا يوم {$when}.",
        ],
    ];

    if (!isset($copy[$status])) return null;
    $c = $copy[$status];

    return notification_create($pdo, [
        'user_id'    => isset($reservation['user_id']) ? (int) $reservation['user_id'] : null,
        'phone'      => (string) ($reservation['phone'] ?? ''),
        'type'       => 'reservation',
        'event_key'  => $c['event'],
        'title'      => $c['title'],
        'title_ar'   => $c['title_ar'],
        'body'       => $c['body'],
        'body_ar'    => $c['body_ar'],
        'link_type'  => 'reservation',
        'link_id'    => $reservationId,
        'dedupe_key' => $status === 'pending'
            ? "reservation:{$reservationId}:created"
            : "reservation:{$reservationId}:status:{$status}",
    ]);
}

/** Notify the owner that a coupon was created / issued to them. */
function notification_coupon_created(PDO $pdo, array $coupon, ?int $userId = null): ?int{
    $couponId = (int) ($coupon['id'] ?? 0);
    if ($couponId <= 0) return null;

    $code = (string) ($coupon['code'] ?? '');
    $value = round((float) ($coupon['value'] ?? 0), 2);
    $isPercent = (($coupon['discount_type'] ?? 'fixed') === 'percent');
    $valueEn = $isPercent ? $value . '%' : 'SAR ' . number_format($value, 2, '.', '');
    $valueAr = $isPercent ? $value . '%' : number_format($value, 2, '.', '') . ' ر.س';

    return notification_create($pdo, [
        'user_id'    => $userId ?? (isset($coupon['user_id']) ? (int) $coupon['user_id'] : null),
        'phone'      => (string) ($coupon['phone'] ?? ''),
        'type'       => 'coupon',
        'event_key'  => 'coupon.created',
        'title'      => "New coupon: {$code}",
        'title_ar'   => "كوبون جديد: {$code}",
        'body'       => "Worth {$valueEn} — it is waiting in My Coupons for your next order.",
        'body_ar'    => "بقيمة {$valueAr} — جاهز في كوبوناتي لطلبك القادم.",
        'link_type'  => 'coupon',
        'link_id'    => $couponId,
        'dedupe_key' => "coupon:{$couponId}:created",
    ]);
}

/** Notify the owner that a coupon they held was cancelled/revoked. */
function notification_coupon_cancelled(PDO $pdo, array $coupon, string $reason = ''): ?int
{
    $couponId = (int) ($coupon['id'] ?? 0);
    if ($couponId <= 0) return null;
    $code = (string) ($coupon['code'] ?? '');

    return notification_create($pdo, [
        'user_id'    => isset($coupon['user_id']) ? (int) $coupon['user_id'] : null,
        'phone'      => (string) ($coupon['phone'] ?? ''),
        'type'       => 'coupon',
        'event_key'  => 'coupon.cancelled',
        'title'      => "Coupon {$code} cancelled",
        'title_ar'   => "تم إلغاء الكوبون {$code}",
        'body'       => $reason !== '' ? $reason : 'This coupon is no longer available.',
        'body_ar'    => $reason !== '' ? $reason : 'هذا الكوبون لم يعد متاحًا.',
        'link_type'  => 'coupon',
        'link_id'    => $couponId,
        'dedupe_key' => "coupon:{$couponId}:cancelled",
    ]);
}

/**
 * A notification that points at an order is only visible while that order
 * is visible to the customer. This hides:
 *   - notifications for a pending order that was never confirmed within
 *     one hour (the automatic stale-order rule), and
 *   - notifications for an order the customer explicitly dismissed with
 *     the × button on the order card.
 * The order row itself is kept for management.
 */
function notification_visibility_sql(bool $includeHiddenOrders = true): string
{
    $hiddenOrder = '';
    if ($includeHiddenOrders) {
        $hiddenOrder = '
            OR EXISTS (
                SELECT 1 FROM customer_hidden_orders customer_hidden
                WHERE customer_hidden.order_id = hidden_order.id
                  AND customer_hidden.user_id = notifications.user_id
            )';
    }

    return "NOT (notifications.link_type = 'order' AND EXISTS (
        SELECT 1 FROM orders hidden_order
        WHERE hidden_order.id = notifications.link_id
          AND (
            (hidden_order.status = 'pending' AND hidden_order.created_at < (NOW() - INTERVAL 1 HOUR)){$hiddenOrder}
          )
    ))";
}

/** One page of the signed-in customer's notifications, newest first. */
function notification_list(PDO $pdo, int $userId, int $limit = 50, bool $unreadOnly = false): array
{
    if (!notifications_ensure_schema($pdo) || $userId <= 0) return [];
    $limit = max(1, min(200, $limit));
    $includeHiddenOrders = customer_hidden_orders_ensure_schema($pdo);

    $sql = 'SELECT * FROM notifications WHERE user_id = :uid AND '
        . notification_visibility_sql($includeHiddenOrders);
    if ($unreadOnly) $sql .= ' AND is_read = 0';
    $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':uid' => $userId]);

    return array_map('notification_present', $stmt->fetchAll());
}

function notification_unread_count(PDO $pdo, int $userId): int
{
    if (!notifications_ensure_schema($pdo) || $userId <= 0) return 0;
    $includeHiddenOrders = customer_hidden_orders_ensure_schema($pdo);
    $stmt = $pdo->prepare('
        SELECT COUNT(*) FROM notifications
        WHERE user_id = :uid AND is_read = 0 AND '
        . notification_visibility_sql($includeHiddenOrders)
    );
    $stmt->execute([':uid' => $userId]);
    return (int) $stmt->fetchColumn();
}

/** Mark one notification read — only when it belongs to this customer. */
function notification_mark_read(PDO $pdo, int $userId, int $notificationId): bool
{
    if (!notifications_ensure_schema($pdo) || $userId <= 0) return false;

    $find = $pdo->prepare('SELECT id FROM notifications WHERE id = :id AND user_id = :uid');
    $find->execute([':id' => $notificationId, ':uid' => $userId]);
    if (!$find->fetchColumn()) return false;

    $pdo->prepare('
        UPDATE notifications SET is_read = 1, read_at = NOW()
        WHERE id = :id AND user_id = :uid AND is_read = 0
    ')->execute([':id' => $notificationId, ':uid' => $userId]);
    return true;
}

function notification_mark_all_read(PDO $pdo, int $userId): int
{
    if (!notifications_ensure_schema($pdo) || $userId <= 0) return 0;
    $stmt = $pdo->prepare('
        UPDATE notifications SET is_read = 1, read_at = NOW()
        WHERE user_id = :uid AND is_read = 0
    ');
    $stmt->execute([':uid' => $userId]);
    return $stmt->rowCount();
}

function notification_present(array $row): array
{
    return [
        'id'         => (int) $row['id'],
        'type'       => (string) $row['type'],
        'event_key'  => (string) $row['event_key'],
        'title'      => (string) $row['title'],
        'title_ar'   => $row['title_ar'] !== null ? (string) $row['title_ar'] : null,
        'body'       => $row['body'] !== null ? (string) $row['body'] : null,
        'body_ar'    => $row['body_ar'] !== null ? (string) $row['body_ar'] : null,
        'link_type'  => $row['link_type'] !== null ? (string) $row['link_type'] : null,
        'link_id'    => $row['link_id'] !== null ? (int) $row['link_id'] : null,
        'is_read'    => (bool) $row['is_read'],
        'created_at' => $row['created_at'],
        'read_at'    => $row['read_at'],
    ];
}
