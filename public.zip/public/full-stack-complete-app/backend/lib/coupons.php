<?php
/**
 * Savoria — Full-Stack Complete App
 * lib/coupons.php — loyalty coupons (points → coupon) and stacked redemption
 *
 * Guarantees:
 *   • One owner per coupon. A coupon is bound to the customer's loyalty
 *     account (and phone). The server re-checks ownership on every use —
 *     hiding a coupon in the UI is never treated as protection.
 *   • Single use. consumption locks the coupon row (SELECT … FOR UPDATE)
 *     and flips it to 'reserved' inside the order transaction; a second,
 *     racing order blocks on that lock, then sees a non-available status
 *     and fails. The UPDATE … WHERE status = 'available' with its rowCount
 *     check is the atomic guard; order_coupons keeps the full history.
 *   • Atomic points. Creating a coupon and spending the points happen in
 *     ONE transaction: either both land or neither does.
 *   • Never negative. The combined discount can never push a bill below
 *     zero; coupons exceeding the bill are rejected, points are trimmed
 *     to the amount that still fits.
 *   • Reversible. Cancelling an order returns its coupons to 'available'
 *     and refunds the points that were redeemed on it.
 */

declare(strict_types=1);

const COUPON_STATUSES = ['available', 'reserved', 'used', 'cancelled', 'expired'];

/* =========================================================
   Rules / settings
   ========================================================= */

/**
 * Coupon rules layered on top of the settings row. The manager sets a
 * percentage and a minimum invoice: every qualifying invoice earns ONE
 * coupon worth that percentage of the invoice (before VAT).
 */
function coupon_settings(PDO $pdo): array
{
    $settings = loyalty_get_settings($pdo);

    return [
        'enabled'       => (bool) $settings['enabled'],
        'percent'       => round(max(0.0, min(100.0, (float) ($settings['coupon_percent'] ?? 10.0))), 2),
        'min_invoice'   => round(max(0.0, (float) ($settings['earn_min_order_amount'] ?? 0.0)), 2),
        'max_per_order' => max(0, (int) ($settings['max_coupons_per_order'] ?? 0)),
        'vat_rate'      => round((float) ($settings['vat_rate'] ?? 15.0), 2),
    ];
}

/** Coupon value earned by an invoice: percent of the bill, rounded to halalas. */
function coupon_value_for_bill(array $rules, float $billAmount): float
{
    if (!$rules['enabled'] || $rules['percent'] <= 0) return 0.0;
    $bill = max(0.0, round($billAmount, 2));
    if ($bill < $rules['min_invoice']) return 0.0;
    return round($bill * ($rules['percent'] / 100), 2);
}

/* =========================================================
   Codes
   ========================================================= */

function coupon_normalize_code(string $code): string
{
    $code = strtoupper(trim($code));
    $code = (string) preg_replace('/\s+/', '', $code);
    return substr($code, 0, 24);
}

/**
 * Accepts an array of codes or a comma/space separated string and
 * returns a de-duplicated, normalised list.
 */
function coupon_normalize_codes($raw): array
{
    if (is_string($raw)) {
        $raw = preg_split('/[\s,;]+/', $raw) ?: [];
    }
    if (!is_array($raw)) return [];

    $out = [];
    foreach ($raw as $code) {
        if (!is_string($code) && !is_numeric($code)) continue;
        $code = coupon_normalize_code((string) $code);
        if ($code !== '') $out[$code] = $code;
    }
    return array_values($out);
}

/**
 * Cryptographically secure, human-friendly code: TRZ-XXXXXXXX.
 * Uses random_int() (CSPRNG) and an alphabet without look-alikes
 * (no I, O, 0, 1). The UNIQUE index is the real duplicate guard.
 */
function coupon_generate_code(PDO $pdo, int $length = 8): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $max = strlen($alphabet) - 1;
    $exists = $pdo->prepare('SELECT 1 FROM coupons WHERE code = :code');

    for ($attempt = 0; $attempt < 25; $attempt++) {
        $code = 'TRZ-';
        for ($i = 0; $i < $length; $i++) {
            $code .= $alphabet[random_int(0, $max)];
        }
        $exists->execute([':code' => $code]);
        if (!$exists->fetchColumn()) return $code;
    }

    throw new RuntimeException('Could not allocate a unique coupon code — please retry.');
}

/* =========================================================
   Lookups
   ========================================================= */

function coupon_find(PDO $pdo, int $id, bool $lock = false): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM coupons WHERE id = :id' . ($lock ? ' FOR UPDATE' : ''));
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function coupon_find_by_code(PDO $pdo, string $code, bool $lock = false): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM coupons WHERE code = :code' . ($lock ? ' FOR UPDATE' : ''));
    $stmt->execute([':code' => coupon_normalize_code($code)]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Stable JSON shape for the storefront + admin panel. */
function coupon_present(array $row): array
{
    return [
        'id'             => (int) $row['id'],
        'code'           => (string) $row['code'],
        'title'          => $row['title'] !== null ? (string) $row['title'] : null,
        'value'          => round((float) $row['value'], 2),
        'discount_type'  => (string) ($row['discount_type'] ?? 'fixed'),
        'min_order_amount' => round((float) ($row['min_order_amount'] ?? 0), 2),
        'max_uses'       => (int) ($row['max_uses'] ?? 1),
        'used_count'     => (int) ($row['used_count'] ?? 0),
        'is_active'      => (bool) ($row['is_active'] ?? 1),
        'status'         => (string) $row['status'],
        'source'         => (string) $row['source'],
        'points_spent'   => (int) $row['points_spent'],
        'phone'          => $row['phone'] !== null ? (string) $row['phone'] : null,
        'customer_name'  => $row['customer_name'] !== null ? (string) $row['customer_name'] : null,
        'order_id'       => $row['order_id'] !== null ? (int) $row['order_id'] : null,
        'issued_for_order_id' => isset($row['issued_for_order_id']) && $row['issued_for_order_id'] !== null
            ? (int) $row['issued_for_order_id'] : null,
        'created_at'     => $row['created_at'],
        'reserved_at'    => $row['reserved_at'],
        'used_at'        => $row['used_at'],
        'cancelled_at'   => $row['cancelled_at'],
        'cancel_reason'  => $row['cancel_reason'],
        'expires_at'     => $row['expires_at'],
    ];
}

/* =========================================================
   Lifecycle log
   ========================================================= */

function coupon_event(
    PDO $pdo,
    int $couponId,
    string $event,
    ?int $orderId = null,
    ?array $actor = null,
    ?string $notes = null
): void {
    if (!in_array($event, ['created', 'reserved', 'used', 'released', 'cancelled', 'expired'], true)) {
        throw new RuntimeException("Unknown coupon event: $event");
    }

    $actorId = isset($actor['sub']) ? (int) $actor['sub'] : null;
    $actorName = null;
    if ($actorId) {
        $stmt = $pdo->prepare('SELECT full_name FROM users WHERE id = :id');
        $stmt->execute([':id' => $actorId]);
        $actorName = $stmt->fetchColumn() ?: ($actor['email'] ?? null);
    }

    $pdo->prepare('
        INSERT INTO coupon_events (coupon_id, event, order_id, actor_user_id, actor_name, notes)
        VALUES (:coupon_id, :event, :order_id, :actor_id, :actor_name, :notes)
    ')->execute([
        ':coupon_id'  => $couponId,
        ':event'      => $event,
        ':order_id'   => $orderId,
        ':actor_id'   => $actorId,
        ':actor_name' => $actorName,
        ':notes'      => $notes !== null ? substr($notes, 0, 255) : null,
    ]);
}

/* =========================================================
   Customer / ownership
   ========================================================= */

/** Resolve (and link) the loyalty account that belongs to a user login. */
function coupon_account_for_user(PDO $pdo, array $currentUser): ?array
{
    $userId = (int) ($currentUser['sub'] ?? 0);
    if ($userId <= 0) return null;

    $stmt = $pdo->prepare('SELECT id, full_name, phone FROM users WHERE id = :id');
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();
    if (!$user) return null;

    $phone = loyalty_normalize_phone((string) ($user['phone'] ?? ''));
    if ($phone === '') return null;

    $account = loyalty_get_or_create_account($pdo, $phone, $user['full_name'] ?? null);
    coupon_link_user_coupons($pdo, $userId, $phone);
    return $account;
}

/**
 * Backfill the owning login on every coupon issued to this phone before
 * the customer registered. Additive: only rows with no user_id yet are
 * touched, so a coupon is never moved between accounts.
 */
function coupon_link_user_coupons(PDO $pdo, int $userId, string $phone): int
{
    if ($userId <= 0) return 0;
    if (!schema_ensure_column($pdo, 'coupons', 'user_id',
        'ALTER TABLE coupons ADD COLUMN user_id INT UNSIGNED DEFAULT NULL AFTER loyalty_account_id')) {
        return 0;
    }

    $last10 = phone_last10($phone);
    if ($last10 === '') return 0;

    $stmt = $pdo->prepare('
        UPDATE coupons
        SET user_id = :uid
        WHERE user_id IS NULL
          AND ' . phone_sql_expr('phone') . ' = :phone
    ');
    $stmt->execute([':uid' => $userId, ':phone' => $last10]);
    return $stmt->rowCount();
}

/**
 * True when the coupon belongs to the given account / login / order phone.
 * A coupon with no owner at all (no account, no user, no phone) is a
 * public promotion and may be used by anyone. An owned coupon NEVER
 * matches a different customer — hiding it in the UI is not the guard.
 */
function coupon_owned_by(
    array $coupon,
    ?array $account,
    ?string $orderPhone = null,
    ?int $userId = null
): bool {
    $couponUserId    = isset($coupon['user_id']) ? (int) $coupon['user_id'] : 0;
    $couponAccountId = isset($coupon['loyalty_account_id']) ? (int) $coupon['loyalty_account_id'] : 0;
    $couponPhone     = phone_last10((string) ($coupon['phone'] ?? ''));

    $isPublic = $couponUserId <= 0 && $couponAccountId <= 0 && $couponPhone === '';
    if ($isPublic) return true;

    if ($userId !== null && $userId > 0 && $couponUserId > 0 && $couponUserId === $userId) {
        return true;
    }
    if ($account && $couponAccountId > 0 && (int) ($account['id'] ?? 0) === $couponAccountId) {
        return true;
    }
    if ($account && $couponPhone !== '') {
        $accountPhone = phone_last10((string) ($account['phone'] ?? ''));
        if ($accountPhone !== '' && $accountPhone === $couponPhone) return true;
    }
    if ($orderPhone !== null && $orderPhone !== '' && $couponPhone !== '') {
        $orderLast10 = phone_last10($orderPhone);
        if ($orderLast10 !== '' && $orderLast10 === $couponPhone) return true;
    }

    return false;
}

/* =========================================================
   Validate a set of codes for one order
   ========================================================= */

/**
 * Verify every code: exists, available, owned by this customer, unexpired,
 * active, meets min order, and (when configured) within the per-order cap.
 * Returns the coupon rows with `calculated_discount` ready to sum. Runs inside the order transaction.
 */
function coupon_validate_for_order(
    PDO $pdo,
    array $codes,
    ?array $account = null,
    float $bill = 0.0,
    bool $lock = false,
    ?string $orderPhone = null,
    ?int $userId = null
): array {
    $codes = coupon_normalize_codes($codes);
    if (!$codes) return [];

    // Deterministic lock order — two concurrent checkouts holding the same
    // set can never deadlock against each other.
    sort($codes);

    $rules = coupon_settings($pdo);
    if (!$rules['enabled']) {
        throw new RuntimeException('The loyalty programme is currently disabled — coupons cannot be used.');
    }
    if ($rules['max_per_order'] > 0 && count($codes) > $rules['max_per_order']) {
        throw new RuntimeException(sprintf(
            'You can use at most %d coupon(s) on one order.', $rules['max_per_order']
        ));
    }

    $coupons = [];

    foreach ($codes as $code) {
        $coupon = coupon_find_by_code($pdo, $code, $lock);
        if (!$coupon) {
            throw new RuntimeException("Coupon $code does not exist.");
        }
        if (isset($coupon['is_active']) && !(bool) $coupon['is_active']) {
            throw new RuntimeException("Coupon $code is currently inactive.");
        }
        if (!coupon_owned_by($coupon, $account, $orderPhone, $userId)) {
            throw new RuntimeException("Coupon $code does not belong to your account or phone number.");
        }
        if ($coupon['expires_at'] !== null && strtotime((string) $coupon['expires_at']) < time()) {
            $pdo->prepare('UPDATE coupons SET status = "expired" WHERE id = :id AND status = "available"')
                ->execute([':id' => (int) $coupon['id']]);
            coupon_event($pdo, (int) $coupon['id'], 'expired', null, null, 'Expired before use');
            throw new RuntimeException("Coupon $code has expired.");
        }
        if ($coupon['status'] !== 'available') {
            throw new RuntimeException("Coupon $code is not available ({$coupon['status']}).");
        }
        $minOrder = (float) ($coupon['min_order_amount'] ?? 0);
        if ($minOrder > 0 && $bill < $minOrder) {
            throw new RuntimeException(sprintf(
                'Coupon %s requires a minimum order amount of SAR %.2f (current subtotal: SAR %.2f).',
                $code, $minOrder, $bill
            ));
        }
        $maxUses = (int) ($coupon['max_uses'] ?? 1);
        $usedCount = (int) ($coupon['used_count'] ?? 0);
        if ($maxUses > 0 && $usedCount >= $maxUses) {
            throw new RuntimeException("Coupon $code has reached its maximum usage limit.");
        }

        $discType = (string) ($coupon['discount_type'] ?? 'fixed');
        // A coupon is always worth its recorded value. If the stack is worth
        // more than the bill the caller rejects the order (see
        // coupon_stack_total) instead of silently shrinking the coupon.
        $disc = $discType === 'percent'
            ? round($bill * ((float) $coupon['value'] / 100), 2)
            : round((float) $coupon['value'], 2);
        if ($disc < 0) $disc = 0.0;

        $coupon['calculated_discount'] = $disc;
        $coupons[] = $coupon;
    }

    return $coupons;
}

/** Total discount of a validated coupon stack. */
function coupon_stack_total(array $coupons): float
{
    $total = 0.0;
    foreach ($coupons as $coupon) {
        $total += isset($coupon['calculated_discount'])
            ? (float) $coupon['calculated_discount']
            : (float) $coupon['value'];
    }
    return round($total, 2);
}

/* =========================================================
   Consume inside the order transaction
   ========================================================= */

/**
 * Lock every coupon for the new order.
 *
 * The coupon is only RESERVED here. It is consumed later, when management
 * confirms the order (coupon_commit_order), so a pending order never burns
 * a customer's coupon by itself.
 */
function coupon_attach_to_order(PDO $pdo, array $coupons, int $orderId, ?array $actor = null): float
{
    $total = 0.0;
    $reserve = $pdo->prepare('
        UPDATE coupons
        SET status = "reserved", order_id = :order_id, reserved_at = NOW()
        WHERE id = :id AND status = "available"
    ');
    $link = $pdo->prepare('
        INSERT INTO order_coupons (order_id, coupon_id, code, value)
        VALUES (:order_id, :coupon_id, :code, :value)
    ');

    foreach ($coupons as $coupon) {
        $reserve->execute([':order_id' => $orderId, ':id' => (int) $coupon['id']]);
        if ($reserve->rowCount() !== 1) {
            // Someone else consumed it between validation and here.
            throw new RuntimeException("Coupon {$coupon['code']} is no longer available.");
        }
        coupon_event($pdo, (int) $coupon['id'], 'reserved', $orderId, $actor, 'Locked for order — waiting for confirmation');

        $discountVal = isset($coupon['calculated_discount']) ? (float) $coupon['calculated_discount'] : (float) $coupon['value'];

        $link->execute([
            ':order_id'  => $orderId,
            ':coupon_id' => (int) $coupon['id'],
            ':code'      => (string) $coupon['code'],
            ':value'     => $discountVal,
        ]);

        $total = round($total + $discountVal, 2);
    }

    return $total;
}

/**
 * Turn the coupons reserved by an order into consumed ones.
 *
 * Called when management confirms the order. Idempotent: only rows still
 * in 'reserved' are touched, so confirming twice or moving the order along
 * the status chain never double-counts a use.
 */
function coupon_commit_order(PDO $pdo, int $orderId, ?array $actor = null): array
{
    $owns = !$pdo->inTransaction();
    if ($owns) $pdo->beginTransaction();

    try {
        $stmt = $pdo->prepare('
            SELECT * FROM coupons
            WHERE order_id = :order_id AND status = "reserved"
            FOR UPDATE
        ');
        $stmt->execute([':order_id' => $orderId]);
        $coupons = $stmt->fetchAll();

        $commitMulti = $pdo->prepare('
            UPDATE coupons
            SET status = CASE WHEN used_count + 1 >= max_uses AND max_uses > 0 THEN "used" ELSE "available" END,
                used_at = NOW(),
                used_count = used_count + 1,
                reserved_at = NULL
            WHERE id = :id AND status = "reserved" AND order_id = :order_id
        ');

        $committed = [];
        foreach ($coupons as $coupon) {
            $commitMulti->execute([':order_id' => $orderId, ':id' => (int) $coupon['id']]);
            if ($commitMulti->rowCount() !== 1) continue;

            coupon_event($pdo, (int) $coupon['id'], 'used', $orderId, $actor, 'Consumed after management confirmation');
            $committed[] = coupon_present($coupon);
        }

        if ($owns) $pdo->commit();

        return $committed;
    } catch (Throwable $e) {
        if ($owns && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/* =========================================================
   Order cancelled → release coupons + refund points
   ========================================================= */

/**
 * Return every coupon of a cancelled order to 'available' and credit the
 * points that were redeemed on it. Idempotent: re-running finds no
 * coupons and no un-refunded redemption, so nothing is duplicated.
 */
function coupon_release_order(PDO $pdo, int $orderId, string $reason, ?array $actor = null): array
{
    $owns = !$pdo->inTransaction();
    if ($owns) $pdo->beginTransaction();

    try {
        $orderStmt = $pdo->prepare('SELECT * FROM orders WHERE id = :id FOR UPDATE');
        $orderStmt->execute([':id' => $orderId]);
        $order = $orderStmt->fetch();
        if (!$order) throw new RuntimeException('Order not found.');

        $released = [];

        $stmt = $pdo->prepare('
            SELECT * FROM coupons
            WHERE order_id = :order_id AND status IN ("reserved", "used")
            FOR UPDATE
        ');
        $stmt->execute([':order_id' => $orderId]);
        $coupons = $stmt->fetchAll();

        $restoreUsed = $pdo->prepare('
            UPDATE coupons
            SET status = "available", order_id = NULL,
                reserved_at = NULL, used_at = NULL,
                used_count = CASE WHEN used_count > 0 THEN used_count - 1 ELSE 0 END
            WHERE id = :id AND status = "used"
        ');
        $restoreReserved = $pdo->prepare('
            UPDATE coupons
            SET status = "available", order_id = NULL, reserved_at = NULL
            WHERE id = :id AND status = "reserved"
        ');

        foreach ($coupons as $coupon) {
            // Keep the order_coupons row: it is the history of "which order
            // used this coupon". Re-use is blocked by the status guard, not
            // by a uniqueness constraint. The usage counter is rolled back
            // too, otherwise a cancelled order would permanently exhaust a
            // single-use coupon.
            if ($coupon['status'] === 'used') {
                $restoreUsed->execute([':id' => (int) $coupon['id']]);
            } else {
                $restoreReserved->execute([':id' => (int) $coupon['id']]);
            }
            coupon_event($pdo, (int) $coupon['id'], 'released', $orderId, $actor, $reason);
            $released[] = coupon_present($coupon);
        }

        // The coupon earned BY this invoice dies with it. If the customer
        // already spent it on another order it stays used there.
        $earnedStmt = $pdo->prepare('
            SELECT * FROM coupons
            WHERE issued_for_order_id = :order_id AND status = "available"
            FOR UPDATE
        ');
        $earnedStmt->execute([':order_id' => $orderId]);
        $revoked = [];
        $revoke = $pdo->prepare('
            UPDATE coupons
            SET status = "cancelled", cancelled_at = NOW(), cancel_reason = :reason
            WHERE id = :id AND status = "available"
        ');
        foreach ($earnedStmt->fetchAll() as $earned) {
            $revoke->execute([':reason' => substr($reason, 0, 255), ':id' => (int) $earned['id']]);
            if ($revoke->rowCount() === 1) {
                coupon_event($pdo, (int) $earned['id'], 'cancelled', $orderId, $actor, $reason);
                $revoked[] = coupon_present($earned);
            }
        }

        // Refund points redeemed on this order (once).
        $points = (int) $order['redeemed_points'];
        if ($points > 0) {
            $dupe = $pdo->prepare('SELECT id FROM loyalty_transactions WHERE order_id = :oid AND type = "refund"');
            $dupe->execute([':oid' => $orderId]);
            if (!$dupe->fetch()) {
                $accountStmt = $pdo->prepare('SELECT * FROM loyalty_accounts WHERE phone = :phone');
                $accountStmt->execute([':phone' => loyalty_normalize_phone((string) $order['phone'])]);
                $account = $accountStmt->fetch();
                if ($account) {
                    [, $balanceAfter] = loyalty_apply_delta($pdo, (int) $account['id'], $points, 'refund');
                    loyalty_insert_tx(
                        $pdo,
                        (int) $account['id'],
                        'refund',
                        $points,
                        (int) $balanceAfter,
                        $orderId,
                        null,
                        (float) $order['redeemed_discount'],
                        'Points returned — order cancelled',
                        $actor
                    );
                }
            }
        }

        if ($owns) $pdo->commit();

        return [
            'released_coupons' => $released,
            'revoked_coupons'  => $revoked,
            'refunded_points'  => $points,
        ];
    } catch (Throwable $e) {
        if ($owns && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/* =========================================================
   Admin: cancel a coupon
   ========================================================= */

function coupon_cancel(PDO $pdo, array $coupon, string $reason, array $actor): array
{
    $reason = trim($reason);
    if ($reason === '') {
        throw new RuntimeException('A cancellation reason is required.');
    }

    $owns = !$pdo->inTransaction();
    if ($owns) $pdo->beginTransaction();

    try {
        $locked = coupon_find($pdo, (int) $coupon['id'], true);
        if (!$locked) throw new RuntimeException('Coupon not found.');
        if ($locked['status'] !== 'available') {
            throw new RuntimeException("Only an available coupon can be cancelled (this one is {$locked['status']}).");
        }

        $pdo->prepare('
            UPDATE coupons
            SET status = "cancelled", cancelled_at = NOW(), cancel_reason = :reason
            WHERE id = :id
        ')->execute([':reason' => substr($reason, 0, 255), ':id' => (int) $locked['id']]);

        coupon_event($pdo, (int) $locked['id'], 'cancelled', null, $actor, $reason);

        if ($owns) $pdo->commit();

        return coupon_present(coupon_find($pdo, (int) $locked['id']));
    } catch (Throwable $e) {
        if ($owns && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/* =========================================================
   Lists
   ========================================================= */

function coupon_list_for_account(PDO $pdo, int $accountId): array
{
    $stmt = $pdo->prepare('
        SELECT * FROM coupons
        WHERE loyalty_account_id = :account_id
        ORDER BY FIELD(status, "available", "reserved", "used", "expired", "cancelled"),
                 created_at DESC
    ');
    $stmt->execute([':account_id' => $accountId]);

    return array_map('coupon_present', $stmt->fetchAll());
}

function coupon_admin_list(PDO $pdo, string $search = '', string $status = ''): array
{
    $where = [];
    $params = [];

    if ($search !== '') {
        $digits = loyalty_normalize_phone($search);
        $where[] = '(c.code LIKE :q_code OR c.phone LIKE :q_digits OR c.customer_name LIKE :q_name)';
        $params[':q_code']   = '%' . $search . '%';
        $params[':q_digits'] = '%' . ($digits !== '' ? $digits : $search) . '%';
        $params[':q_name']   = '%' . $search . '%';
    }
    if (in_array($status, COUPON_STATUSES, true)) {
        $where[] = 'c.status = :status';
        $params[':status'] = $status;
    }

    $sql = '
        SELECT c.*,
               o.order_number AS used_order_number,
               o.invoice_number AS used_invoice_number,
               io.order_number AS issued_order_number,
               io.invoice_number AS issued_invoice_number
        FROM coupons c
        LEFT JOIN orders o ON o.id = c.order_id
        LEFT JOIN orders io ON io.id = c.issued_for_order_id
    ';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY c.created_at DESC, c.id DESC LIMIT 500';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $rows = [];
    foreach ($stmt->fetchAll() as $row) {
        $row['value'] = (float) $row['value'];
        $row['discount_type'] = (string) ($row['discount_type'] ?? 'fixed');
        $row['min_order_amount'] = (float) ($row['min_order_amount'] ?? 0);
        $row['max_uses'] = (int) ($row['max_uses'] ?? 1);
        $row['used_count'] = (int) ($row['used_count'] ?? 0);
        $row['is_active'] = (bool) ($row['is_active'] ?? 1);
        $row['title'] = $row['title'] !== null ? (string) $row['title'] : null;
        $row['points_spent'] = (int) $row['points_spent'];
        $row['order_id'] = $row['order_id'] !== null ? (int) $row['order_id'] : null;
        $row['used_order_number'] = $row['used_order_number'] !== null ? (int) $row['used_order_number'] : null;
        $row['used_invoice_number'] = $row['used_invoice_number'] !== null ? (int) $row['used_invoice_number'] : null;
        $row['issued_for_order_id'] = $row['issued_for_order_id'] !== null ? (int) $row['issued_for_order_id'] : null;
        $row['issued_order_number'] = $row['issued_order_number'] !== null ? (int) $row['issued_order_number'] : null;
        $row['issued_invoice_number'] = $row['issued_invoice_number'] !== null ? (int) $row['issued_invoice_number'] : null;
        $row['loyalty_account_id'] = $row['loyalty_account_id'] !== null ? (int) $row['loyalty_account_id'] : null;
        $rows[] = $row;
    }
    return $rows;
}

function coupon_admin_stats(PDO $pdo): array
{
    $stmt = $pdo->query('
        SELECT
            COUNT(*) AS total,
            SUM(status = "available") AS available,
            SUM(status = "reserved") AS reserved,
            SUM(status = "used")     AS used,
            SUM(status = "cancelled") AS cancelled,
            SUM(status = "expired")  AS expired
        FROM coupons
    ');
    $row = $stmt->fetch() ?: [];

    $discountStmt = $pdo->query('
        SELECT COALESCE(SUM(value), 0) AS granted,
               COALESCE(SUM(CASE WHEN status = "used" THEN value ELSE 0 END), 0) AS consumed
        FROM coupons
    ');
    $money = $discountStmt->fetch() ?: [];

    return [
        'total'      => (int) ($row['total'] ?? 0),
        'available'  => (int) ($row['available'] ?? 0),
        'reserved'   => (int) ($row['reserved'] ?? 0),
        'used'       => (int) ($row['used'] ?? 0),
        'cancelled'  => (int) ($row['cancelled'] ?? 0),
        'expired'    => (int) ($row['expired'] ?? 0),
        'granted_value' => round((float) ($money['granted'] ?? 0), 2),
        'used_value'    => round((float) ($money['consumed'] ?? 0), 2),
    ];
}

/** Lifecycle log for one coupon (admin drawer). */
function coupon_log(PDO $pdo, int $couponId): array
{
    $stmt = $pdo->prepare('
        SELECT * FROM coupon_events
        WHERE coupon_id = :id
        ORDER BY created_at ASC, id ASC
    ');
    $stmt->execute([':id' => $couponId]);
    return $stmt->fetchAll();
}

/** Housekeeping: flip overdue available coupons to expired. */
function coupon_expire_stale(PDO $pdo): int
{
    $stmt = $pdo->prepare('
        SELECT id FROM coupons
        WHERE status = "available" AND expires_at IS NOT NULL AND expires_at < NOW()
    ');
    $stmt->execute();
    $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if (!$ids) return 0;

    $up = $pdo->prepare('UPDATE coupons SET status = "expired" WHERE id = :id');
    foreach ($ids as $id) {
        $up->execute([':id' => (int) $id]);
        coupon_event($pdo, (int) $id, 'expired', null, null, 'Expired automatically');
    }
    return count($ids);
}

/* =========================================================
   Admin Management: Create, Toggle Active, Delete
   ========================================================= */

function coupon_create(PDO $pdo, array $payload, ?array $actor = null): array
{
    $rawCode = trim((string) ($payload['code'] ?? ''));
    if ($rawCode !== '' && $rawCode !== 'auto') {
        $code = coupon_normalize_code($rawCode);
        $exists = coupon_find_by_code($pdo, $code);
        if ($exists) {
            throw new RuntimeException("A coupon with code \"$code\" already exists.");
        }
    } else {
        $code = coupon_generate_code($pdo);
    }

    $title = isset($payload['title']) && trim((string) $payload['title']) !== ''
        ? trim((string) $payload['title']) : null;
    $discType = in_array($payload['discount_type'] ?? '', ['fixed', 'percent'], true)
        ? (string) $payload['discount_type'] : 'fixed';
    $value = round((float) ($payload['value'] ?? 0), 2);
    if ($value <= 0) {
        throw new RuntimeException('Discount value must be greater than zero.');
    }
    if ($discType === 'percent' && $value > 100) {
        throw new RuntimeException('Percentage discount cannot exceed 100%.');
    }

    $minOrder = max(0.0, round((float) ($payload['min_order_amount'] ?? 0), 2));
    $maxUses = max(1, (int) ($payload['max_uses'] ?? 1));
    $isActive = isset($payload['is_active']) ? (int) (bool) $payload['is_active'] : 1;

    $expiresAt = null;
    if (!empty($payload['expires_at'])) {
        $ts = strtotime((string) $payload['expires_at']);
        if ($ts && $ts > time()) {
            $expiresAt = date('Y-m-d H:i:s', $ts);
        }
    }

    $phone = null;
    $accountId = null;
    $ownerUserId = null;
    $customerName = isset($payload['customer_name']) && trim((string) $payload['customer_name']) !== ''
        ? trim((string) $payload['customer_name']) : null;

    if (!empty($payload['phone'])) {
        $normPhone = loyalty_normalize_phone((string) $payload['phone']);
        if ($normPhone !== '') {
            $phone = $normPhone;
            $account = loyalty_get_or_create_account($pdo, $phone, $customerName);
            $accountId = (int) $account['id'];
            $ownerUserId = user_id_for_phone($pdo, $phone, true);
        }
    }

    $creatorId = isset($actor['sub']) ? (int) $actor['sub'] : null;

    // Owner login (when known) travels with the coupon so it appears in
    // the customer's account and notification centre immediately.
    $hasUserColumn = schema_ensure_column($pdo, 'coupons', 'user_id',
        'ALTER TABLE coupons ADD COLUMN user_id INT UNSIGNED DEFAULT NULL AFTER loyalty_account_id');

    $columns = 'code, loyalty_account_id, phone, customer_name, title, value, discount_type,
             min_order_amount, max_uses, used_count, status, is_active, source, expires_at, created_by';
    $values = ':code, :account_id, :phone, :customer_name, :title, :value, :discount_type,
             :min_order, :max_uses, 0, "available", :is_active, "admin", :expires_at, :created_by';
    $params = [
        ':code'          => $code,
        ':account_id'    => $accountId,
        ':phone'         => $phone,
        ':customer_name' => $customerName,
        ':title'         => $title,
        ':value'         => $value,
        ':discount_type' => $discType,
        ':min_order'     => $minOrder,
        ':max_uses'      => $maxUses,
        ':is_active'     => $isActive,
        ':expires_at'    => $expiresAt,
        ':created_by'    => $creatorId,
    ];
    if ($hasUserColumn) {
        $columns = 'code, loyalty_account_id, user_id, phone, customer_name, title, value, discount_type,
             min_order_amount, max_uses, used_count, status, is_active, source, expires_at, created_by';
        $values = ':code, :account_id, :user_id, :phone, :customer_name, :title, :value, :discount_type,
             :min_order, :max_uses, 0, "available", :is_active, "admin", :expires_at, :created_by';
        $params[':user_id'] = $ownerUserId;
    }

    $stmt = $pdo->prepare("INSERT INTO coupons ({$columns}) VALUES ({$values})");
    $stmt->execute($params);

    $id = (int) $pdo->lastInsertId();
    coupon_event($pdo, $id, 'created', null, $actor, 'Created by administrator');

    return coupon_present(coupon_find($pdo, $id));
}

function coupon_toggle_active(PDO $pdo, int $id, bool $isActive, ?array $actor = null): array
{
    $coupon = coupon_find($pdo, $id);
    if (!$coupon) throw new RuntimeException('Coupon not found.');

    $stmt = $pdo->prepare('UPDATE coupons SET is_active = :act WHERE id = :id');
    $stmt->execute([':act' => $isActive ? 1 : 0, ':id' => $id]);

    coupon_event($pdo, $id, $isActive ? 'released' : 'cancelled', null, $actor, $isActive ? 'Activated' : 'Deactivated');
    return coupon_present(coupon_find($pdo, $id));
}

function coupon_delete(PDO $pdo, int $id, ?array $actor = null): bool
{
    $coupon = coupon_find($pdo, $id);
    if (!$coupon) throw new RuntimeException('Coupon not found.');

    // If it has order history, soft-cancel it; if not used, hard delete is allowed
    $hasOrders = (int) $pdo->query('SELECT COUNT(*) FROM order_coupons WHERE coupon_id = ' . $id)->fetchColumn();
    if ($hasOrders > 0) {
        $stmt = $pdo->prepare('UPDATE coupons SET status = "cancelled", cancel_reason = "Deleted by admin", cancelled_at = NOW() WHERE id = :id');
        $stmt->execute([':id' => $id]);
        coupon_event($pdo, $id, 'cancelled', null, $actor, 'Cancelled via admin deletion request');
        return true;
    }

    $pdo->prepare('DELETE FROM coupon_events WHERE coupon_id = :id')->execute([':id' => $id]);
    $stmt = $pdo->prepare('DELETE FROM coupons WHERE id = :id');
    $stmt->execute([':id' => $id]);
    return $stmt->rowCount() > 0;
}

/* =========================================================
   Storefront helpers: issue coupon on order, phone lookup, validate
   ========================================================= */

/**
 * The promised earned-coupon amount lives on the order, so the columns
 * must exist before the order transaction opens (ALTER commits implicitly).
 */
function coupon_earned_columns_ready(PDO $pdo): bool
{
    static $ready = null;
    if ($ready !== null) return $ready;

    return $ready = schema_ensure_column($pdo, 'orders', 'earned_coupon_value', '
        ALTER TABLE orders
            ADD COLUMN earned_coupon_value DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            ADD COLUMN earned_coupon_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00
    ');
}

/**
 * Issues the ONE coupon an invoice earns, worth `coupon_percent` of the
 * bill (after coupons, before VAT). Idempotent: the UNIQUE
 * issued_for_order_id index means a repeated call returns the coupon that
 * already exists instead of issuing a second one.
 *
 * Management confirms the order before this runs. The amount and the
 * percentage promised at checkout are passed in, so a rule change while
 * the order waited cannot alter what the customer was told.
 */
function coupon_issue_for_order(
    PDO $pdo,
    int $orderId,
    string $phone,
    ?string $customerName,
    float $billAmount,
    ?float $promisedValue = null,
    ?float $promisedPercent = null
): ?array {
    $rules = coupon_settings($pdo);
    $value = $promisedValue !== null && $promisedValue > 0
        ? round($promisedValue, 2)
        : coupon_value_for_bill($rules, $billAmount);
    if ($orderId <= 0 || $value <= 0) return null;
    $percent = $promisedPercent !== null && $promisedPercent > 0
        ? round($promisedPercent, 2)
        : $rules['percent'];

    $normPhone = loyalty_normalize_phone($phone);
    if ($normPhone === '') return null;

    $existing = $pdo->prepare('SELECT * FROM coupons WHERE issued_for_order_id = :oid');
    $existing->execute([':oid' => $orderId]);
    $row = $existing->fetch();
    if ($row) return coupon_present($row);

    $account = loyalty_get_or_create_account($pdo, $normPhone, $customerName);
    $title = sprintf('Invoice reward — %s%%', rtrim(rtrim(number_format($percent, 2, '.', ''), '0'), '.'));

    for ($attempt = 0; $attempt < 5; $attempt++) {
        $code = coupon_generate_code($pdo);
        try {
            $pdo->prepare('
                INSERT INTO coupons
                    (code, loyalty_account_id, phone, customer_name, title, value, discount_type,
                     min_order_amount, max_uses, used_count, points_spent, status, is_active, source,
                     issued_for_order_id)
                VALUES
                    (:code, :account_id, :phone, :name, :title, :value, "fixed",
                     0, 1, 0, 0, "available", 1, "order", :order_id)
            ')->execute([
                ':code'       => $code,
                ':account_id' => (int) $account['id'],
                ':phone'      => $normPhone,
                ':name'       => $customerName !== null && $customerName !== '' ? $customerName : null,
                ':title'      => $title,
                ':value'      => $value,
                ':order_id'   => $orderId,
            ]);

            $couponId = (int) $pdo->lastInsertId();

            // Bind the coupon to the customer's login when one exists, so
            // it shows up in the account and can be notified immediately.
            $ownerUserId = user_id_for_phone($pdo, $normPhone, true);
            if ($ownerUserId !== null && schema_ensure_column($pdo, 'coupons', 'user_id',
                'ALTER TABLE coupons ADD COLUMN user_id INT UNSIGNED DEFAULT NULL AFTER loyalty_account_id')) {
                $pdo->prepare('UPDATE coupons SET user_id = :uid WHERE id = :id')
                    ->execute([':uid' => $ownerUserId, ':id' => $couponId]);
            }

            coupon_event($pdo, $couponId, 'created', $orderId, null, sprintf(
                'Earned from invoice #%d — %s%% of SAR %.2f = SAR %.2f (issued on confirmation)',
                $orderId,
                rtrim(rtrim(number_format($percent, 2, '.', ''), '0'), '.'),
                $billAmount,
                $value
            ));

            return coupon_present(coupon_find($pdo, $couponId));
        } catch (PDOException $e) {
            // One coupon per invoice: a racing duplicate returns the winner.
            if (str_contains($e->getMessage(), 'uq_coupons_issued_order')
                || str_contains($e->getMessage(), '1062')) {
                $again = $pdo->prepare('SELECT * FROM coupons WHERE issued_for_order_id = :oid');
                $again->execute([':oid' => $orderId]);
                $row = $again->fetch();
                if ($row) return coupon_present($row);
            }
            if ($attempt === 4) throw $e;
        }
    }

    return null;
}

/**
 * Public lookup by phone number without requiring a password.
 * Returns the coupons this phone can spend (its own + public ones).
 */
function coupon_lookup_by_phone(PDO $pdo, string $phone): array
{
    $normPhone = loyalty_normalize_phone($phone);
    coupon_expire_stale($pdo);
    $rules = coupon_settings($pdo);

    if ($normPhone === '' || !$rules['enabled']) {
        return [
            'found'           => false,
            'enabled'         => $rules['enabled'],
            'phone'           => $normPhone,
            'max_per_order'   => $rules['max_per_order'],
            'available_count' => 0,
            'coupons'         => [],
        ];
    }

    $accountStmt = $pdo->prepare('SELECT * FROM loyalty_accounts WHERE phone = :phone');
    $accountStmt->execute([':phone' => $normPhone]);
    $account = $accountStmt->fetch();

    // Fetch coupons belonging to this phone OR general coupons with no phone
    $stmt = $pdo->prepare('
        SELECT * FROM coupons
        WHERE status = "available"
          AND is_active = 1
          AND (phone = :phone OR phone IS NULL OR phone = "")
          AND (expires_at IS NULL OR expires_at > NOW())
        ORDER BY created_at DESC
        LIMIT 50
    ');
    $stmt->execute([':phone' => $normPhone]);
    $coupons = array_map('coupon_present', $stmt->fetchAll());

    return [
        'found'           => (bool) $account,
        'enabled'         => true,
        'customer_name'   => $account['customer_name'] ?? null,
        'phone'           => $normPhone,
        'max_per_order'   => $rules['max_per_order'],
        'available_count' => count($coupons),
        'coupons'         => $coupons,
    ];
}

/**
 * Validates a single coupon code for interactive storefront entry.
 */
function coupon_validate_single(
    PDO $pdo,
    string $code,
    ?string $phone = null,
    float $subtotal = 0.0,
    ?int $userId = null
): array {
    $settings = loyalty_get_settings($pdo);
    if (empty($settings['enabled'])) {
        return ['valid' => false, 'message' => 'The coupon and loyalty system is currently disabled.'];
    }

    $cleanCode = coupon_normalize_code($code);
    if ($cleanCode === '') {
        return ['valid' => false, 'message' => 'Please enter a coupon code.'];
    }

    $coupon = coupon_find_by_code($pdo, $cleanCode);
    if (!$coupon) {
        return ['valid' => false, 'message' => "Coupon code \"$cleanCode\" does not exist."];
    }
    if (isset($coupon['is_active']) && !(bool) $coupon['is_active']) {
        return ['valid' => false, 'message' => "Coupon \"$cleanCode\" is currently disabled."];
    }

    // Ownership is enforced here too — previewing a code must not reveal
    // or accept a coupon that belongs to another customer.
    $account = null;
    $lookupPhone = $phone;
    if ($userId !== null && $userId > 0) {
        $u = $pdo->prepare('SELECT phone FROM users WHERE id = :id');
        $u->execute([':id' => $userId]);
        $userPhone = (string) ($u->fetchColumn() ?: '');
        if ($userPhone !== '') $lookupPhone = $userPhone;
    }
    if ($lookupPhone !== null && trim($lookupPhone) !== '') {
        $account = loyalty_get_account($pdo, $lookupPhone);
    }
    if (!coupon_owned_by($coupon, $account, $lookupPhone, $userId)) {
        return ['valid' => false, 'message' => "Coupon \"$cleanCode\" does not belong to your account."];
    }

    if ($coupon['status'] !== 'available') {
        return ['valid' => false, 'message' => "Coupon \"$cleanCode\" is not available ({$coupon['status']})."];
    }
    if ($coupon['expires_at'] !== null && strtotime((string) $coupon['expires_at']) < time()) {
        return ['valid' => false, 'message' => "Coupon \"$cleanCode\" has expired."];
    }

    $minOrder = (float) ($coupon['min_order_amount'] ?? 0);
    if ($minOrder > 0 && $subtotal > 0 && $subtotal < $minOrder) {
        return [
            'valid' => false,
            'message' => sprintf('Coupon requires a minimum order amount of SAR %.2f (current: SAR %.2f).', $minOrder, $subtotal)
        ];
    }

    $maxUses = (int) ($coupon['max_uses'] ?? 1);
    $usedCount = (int) ($coupon['used_count'] ?? 0);
    if ($maxUses > 0 && $usedCount >= $maxUses) {
        return ['valid' => false, 'message' => "Coupon \"$cleanCode\" has reached its maximum usage limit."];
    }

    $discType = (string) ($coupon['discount_type'] ?? 'fixed');
    $val = (float) $coupon['value'];
    $calculated = $discType === 'percent'
        ? round($subtotal * ($val / 100), 2)
        : round($val, 2);

    // A coupon keeps its face value — never silently shrink it to the bill.
    if ($discType === 'fixed' && $subtotal > 0 && $calculated > $subtotal) {
        return [
            'valid' => false,
            'message' => sprintf(
                'Coupon value SAR %.2f is more than the current bill (SAR %.2f). Add more items before using it.',
                $calculated,
                $subtotal
            ),
        ];
    }

    return [
        'valid'             => true,
        'message'           => 'Coupon applied successfully.',
        'coupon'            => coupon_present($coupon),
        'calculated_amount' => $calculated,
    ];
}
