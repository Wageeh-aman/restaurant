# =========================================================
# Savoria - Site Management & Loyalty test suite
# Real API calls against the running backend; PASS/FAIL per
# required scenario. Windows PowerShell 5.1+ / ASCII only.
# =========================================================

$ErrorActionPreference = 'Continue'
$API = 'http://localhost:8000'
$RunId = [Guid]::NewGuid().ToString('N').Substring(0, 10)
$CashierPhone = '03' + (Get-Random -Minimum 10000000 -Maximum 99999999)
$LoyalPhone = '03' + (Get-Random -Minimum 10000000 -Maximum 99999999)
$ManualGrantPhone = '03' + (Get-Random -Minimum 10000000 -Maximum 99999999)
$SCRIPT:pass = 0
$SCRIPT:fail = 0

function Result($name, $ok, $detail = '') {
    if ($ok) { $SCRIPT:pass++; Write-Output ("PASS  {0}   {1}" -f $name, $detail) }
    else     { $SCRIPT:fail++; Write-Output ("FAIL  {0}   {1}" -f $name, $detail) }
}

function Json($method, $uri, $body = $null, $token = $null) {
    try {
        $headers = @{}
        if ($token) { $headers.Authorization = "Bearer $token" }
        $params = @{ Uri = $uri; Method = $method; Headers = $headers; UseBasicParsing = $true; TimeoutSec = 30; ContentType = 'application/json' }
        if ($null -ne $body) { $params.Body = ($body | ConvertTo-Json -Depth 8 -Compress) }
        $r = Invoke-WebRequest @params
        return @{ status = [int]$r.StatusCode; body = ($r.Content | ConvertFrom-Json) }
    } catch {
        $raw = $null
        try { if ($_.Exception.Response) {
            $stream = $_.Exception.Response.GetResponseStream()
            if ($stream) { $raw = (New-Object System.IO.StreamReader($stream)).ReadToEnd() }
        } } catch { }
        if (-not $raw -and $_.ErrorDetails) { $raw = $_.ErrorDetails.Message }
        $status = -1
        try { $status = [int]$_.Exception.Response.StatusCode } catch { $status = -1 }
        $parsed = $null
        try { $parsed = $raw | ConvertFrom-Json } catch { $parsed = @{ message = "$raw" } }
        return @{ status = $status; body = $parsed }
    }
}

function Upload($uri, $token, $filePath, $prefix) {
    Add-Type -AssemblyName System.Net.Http
    $client = New-Object System.Net.Http.HttpClient
    if ($token) { $client.DefaultRequestHeaders.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue('Bearer', $token) }
    $content = New-Object System.Net.Http.MultipartFormDataContent
    $bytes = [System.IO.File]::ReadAllBytes($filePath)
    $bytesContent = New-Object System.Net.Http.ByteArrayContent(,$bytes)
    $content.Add($bytesContent, 'file', (Split-Path $filePath -Leaf))
    $content.Add((New-Object System.Net.Http.StringContent($prefix)), 'prefix')
    try {
        $resp = $client.PostAsync($uri, $content).Result
        $raw = $resp.Content.ReadAsStringAsync().Result
        return @{ status = [int]$resp.StatusCode; body = ($raw | ConvertFrom-Json) }
    } finally { $client.Dispose(); $content.Dispose() }
}

Write-Output "============================================================="
Write-Output " 1) LOGIN & RBAC"
Write-Output "============================================================="
$super = Json 'POST' "$API/auth/login" @{ email = 'admin@savoria.example'; password = 'Password123!' }
$superT = $super.body.data.token
$superId = $super.body.data.user.id
Result 'super admin login' ($super.status -eq 200) "role=$($super.body.data.user.role)"

$staff = Json 'POST' "$API/auth/login" @{ email = 'staff@savoria.example'; password = 'Password123!' }
$staffT = $staff.body.data.token
Result 'staff login (pre-seeded)' ($staff.status -eq 200) ''

$reg1 = Json 'POST' "$API/auth/register" @{ full_name = 'Self Signup'; email = "self$RunId@example.com"; password = 'Password123!' }
Result 'public self-registration rejected (401)' ($reg1.status -eq 401) "got $($reg1.status)"

$reg2 = Json 'POST' "$API/auth/register" @{ full_name = 'Staff Signup'; email = "sr$RunId@example.com"; password = 'Password123!' } $staffT
Result 'staff cannot create accounts (403)' ($reg2.status -eq 403) "got $($reg2.status)"

$cust = Json 'POST' "$API/auth/login" @{ email = 'ayesha@savoria.example'; password = 'Password123!' }
$custT = $null
Result 'customer login rejected (management-only, 403)' ($cust.status -eq 403) "got $($cust.status)"

$sum = Json 'GET' "$API/admin/summary" $null $staffT
Result 'admin summary (staff OK)' ($sum.status -eq 200) "orders=$($sum.body.data.orders_today)"

Write-Output ""
Write-Output "============================================================="
Write-Output " 2) SUPER ADMIN CREATES ACCOUNTS (cashier) + guards"
Write-Output "============================================================="
$email = "casha$RunId@staff.savoria.example"
$created = Json 'POST' "$API/admin/users" @{ full_name = 'Test Cashier'; email = $email; password = 'TempPass123'; role = 'cashier'; phone = $CashierPhone } $superT
$cashierId = $created.body.data.id
Result 'super admin creates cashier (forced change)' ($created.status -eq 201 -and $created.body.data.force_password_change) "id=$cashierId"

$dup = Json 'POST' "$API/admin/users" @{ full_name = 'Dup'; email = $email; password = 'TempPass123'; role = 'cashier' } $superT
Result 'duplicate username (email) rejected 409' ($dup.status -eq 409) "got $($dup.status)"

$asStaff = Json 'POST' "$API/admin/users" @{ full_name = 'X'; email = "x$PID@x.com"; password = 'TempPass123'; role = 'admin' } $staffT
Result 'staff cannot create accounts via panel (403)' ($asStaff.status -eq 403) "got $($asStaff.status)"

$cashier = Json 'POST' "$API/auth/login" @{ email = $email; password = 'TempPass123' }
$cashierT = $cashier.body.data.token
Result 'new cashier logs in; temp password flagged' ($cashier.status -eq 200 -and $cashier.body.data.user.force_password_change -eq $true) ''

$cashierSelf = Json 'POST' "$API/admin/users/$cashierId/password" @{ current_password = 'TempPass123'; password = 'Cashier123' } $cashierT
Result 'cashier forced self password change' ($cashierSelf.status -eq 200) "status $($cashierSelf.status)"

$cashier2 = Json 'POST' "$API/auth/login" @{ email = $email; password = 'Cashier123' }
$cashierT = $cashier2.body.data.token
Result 'cashier re-login; flag cleared' ($cashier2.status -eq 200 -and $cashier2.body.data.user.force_password_change -eq $false) ''

Write-Output ""
Write-Output "============================================================="
Write-Output " 3) LOYALTY SETTINGS - editable + strict RBAC"
Write-Output "============================================================="
$ls1 = Json 'GET' "$API/admin/loyalty/settings" $null $cashierT
Result 'cashier blocked from settings (403)' ($ls1.status -eq 403) "got $($ls1.status)"

$ls2 = Json 'GET' "$API/admin/loyalty/settings" $null $superT
Result 'super admin reads settings' ($ls2.status -eq 200) "rate=$($ls2.body.data.earn_amount_per_point)"

$put = Json 'PUT' "$API/admin/loyalty/settings" @{ earn_amount_per_point = 10; earn_min_order_amount = 500; redeem_min_points = 100; redeem_point_value = 1; enabled = $true } $superT
Result 'super admin saves settings' ($put.status -eq 200 -and [double]$put.body.data.earn_min_order_amount -eq 500.0) ''

$ls3 = Json 'GET' "$API/admin/loyalty/settings" $null $superT
Result 'settings persisted' ([double]$ls3.body.data.earn_min_order_amount -eq 500.0) ''

Write-Output ""
Write-Output "============================================================="
Write-Output " 4) REAL ORDER -> AUTO POINTS (once, delivered-only)"
Write-Output "============================================================="
$todayBefore = Json 'GET' "$API/admin/orders-today" $null $staffT
$baseline = $todayBefore.body.data.summary.total_orders

# order1: Lamb Shank x2 = 4900 -> floor(4900/10) = 490 pts
$mk = Json 'POST' "$API/orders" @{ customer_name = 'Test Customer Loyal'; phone = $LoyalPhone; order_type = 'delivery'; delivery_address = '12 Test St'; order_notes = 'Please call on arrival'; items = @(@{ menu_item_id = 4; quantity = 2 }) } $null
$orderId1 = $mk.body.data.id
Result 'guest order placed (pending, NO points yet)' ($mk.status -eq 201 -and $mk.body.data.status -eq 'pending') "#$orderId1"

$delivered = Json 'PATCH' "$API/orders/$orderId1" @{ status = 'delivered' } $staffT
Result 'staff marks delivered -> points earned' ($delivered.status -eq 200 -and $delivered.body.message -match 'earned') "#$orderId1"

[void](Json 'PATCH' "$API/orders/$orderId1" @{ status = 'delivered' } $cashierT)
$v1 = Json 'GET' "$API/orders/${orderId1}?phone=$LoyalPhone" $null $staffT
$earnRows = @($v1.body.data.loyalty | Where-Object { $_.type -eq 'earn' })
$earned1 = $earnRows[0].points_delta
Result 're-delivery does NOT double-earn' ($earnRows.Count -eq 1) "earn rows=$($earnRows.Count)"
Result 'earned floor(total/10)' ($earned1 -eq 490 -and [double]$v1.body.data.loyalty[0].qualified_amount -eq 4900.0) "total=$($v1.body.data.total_amount) earned=$earned1"
Result 'order notes are retained with the order' ($v1.body.data.order_notes -eq 'Please call on arrival') "notes=$($v1.body.data.order_notes)"

# min-order threshold test: temporarily raise min to 1000; a 780 order earns 0
[void](Json 'PUT' "$API/admin/loyalty/settings" @{ earn_min_order_amount = 1000 } $superT)
$mk2 = Json 'POST' "$API/orders" @{ customer_name = 'Small Order'; phone = '03212223344'; order_type = 'pickup'; items = @(@{ menu_item_id = 8; quantity = 1 }) } $null
$orderId2 = $mk2.body.data.id
$patch2 = Json 'PATCH' "$API/orders/$orderId2" @{ status = 'delivered' } $staffT
Result 'patch OK (no points message expected)' ($patch2.status -eq 200 -and $patch2.body.message -notmatch 'earned') "'$($patch2.body.message)'"
$custView = Json 'GET' "$API/admin/loyalty/customer?phone=03212223344" $null $staffT
$smallEarn = @($custView.body.data.transactions | Where-Object { $_.order_id -eq $orderId2 })
Result 'sub-minimum order earns NOTHING' ($smallEarn.Count -eq 0) "tx=$($smallEarn.Count)"
[void](Json 'PUT' "$API/admin/loyalty/settings" @{ earn_min_order_amount = 500 } $superT)

Write-Output ""
Write-Output "============================================================="
Write-Output " 5) CUSTOMER SEARCH BY PHONE"
Write-Output "============================================================="
$cs = Json 'GET' "$API/admin/loyalty/customer?phone=$LoyalPhone" $null $cashierT
Result 'cashier finds customer by phone' ($cs.status -eq 200 -and $cs.body.data.found) "name=$($cs.body.data.account.customer_name)"
Result 'balance = 490 (ledger-consistent)' ($cs.body.data.account.points_balance -eq 490) "balance=$($cs.body.data.account.points_balance)"
Result 'orders count + paid spend' ($cs.body.data.order_count -eq 1 -and [double]$cs.body.data.total_spend -eq 4900.0) "spend=$($cs.body.data.total_spend)"

$nf = Json 'GET' "$API/admin/loyalty/customer?phone=$ManualGrantPhone" $null $cashierT
Result 'unknown phone -> clear not-found (no fake data)' ($nf.status -eq 200 -and $nf.body.data.found -eq $false) ''

$firstGrant = Json 'POST' "$API/admin/loyalty/adjust" @{ phone = $ManualGrantPhone; points = 25; reason = 'new customer welcome points' } $cashierT
$searchAfterGrant = Json 'GET' "$API/admin/loyalty/customer?phone=$ManualGrantPhone" $null $cashierT
Result 'manual grant creates account that is immediately searchable' ($firstGrant.status -eq 200 -and $searchAfterGrant.body.data.found -eq $true -and $searchAfterGrant.body.data.account.points_balance -eq 25) "balance=$($searchAfterGrant.body.data.account.points_balance)"

Write-Output ""
Write-Output "============================================================="
Write-Output " 6) MANUAL ADJUST: grant/deduct + guards"
Write-Output "============================================================="
$adj1 = Json 'POST' "$API/admin/loyalty/adjust" @{ phone = $LoyalPhone; points = 50; reason = 'goodwill gesture' } $cashierT
Result 'cashier grants +50 with reason' ($adj1.status -eq 200 -and $adj1.body.data.balance -eq 540) "balance=$($adj1.body.data.balance)"

$adj2 = Json 'POST' "$API/admin/loyalty/adjust" @{ phone = $LoyalPhone; points = 1; reason = '' } $cashierT
Result 'adjust without reason rejected' ($adj2.status -eq 422) "got $($adj2.status)"

$adj3 = Json 'POST' "$API/admin/loyalty/adjust" @{ phone = $LoyalPhone; points = -100000; reason = 'over deduction' } $cashierT
Result 'balance can never go negative' ($adj3.status -eq 422) "got $($adj3.status)"

Write-Output ""
Write-Output "============================================================="
Write-Output " 7) REDEEM: minimum, balance guard, one-time spend"
Write-Output "============================================================="
$less = Json 'POST' "$API/admin/loyalty/redeem" @{ phone = $LoyalPhone; points = 20 } $cashierT
Result 'below redeem_min rejected' ($less.status -eq 422) "'$($less.body.message)'"

$over = Json 'POST' "$API/admin/loyalty/redeem" @{ phone = $LoyalPhone; points = 9999 } $cashierT
Result 'over-balance redemption rejected' ($over.status -eq 422) "'$($over.body.message)'"

$vend = Json 'POST' "$API/admin/loyalty/redeem" @{ phone = $LoyalPhone; points = 100; reason = 'gift voucher' } $cashierT
Result 'valid redemption succeeds' ($vend.status -eq 200) "cash=$($vend.body.data.cash_value)"

$aft = Json 'GET' "$API/admin/loyalty/customer?phone=$LoyalPhone" $null $cashierT
Result 'balance updated immediately (440)' ($aft.body.data.account.points_balance -eq 440) "balance=$($aft.body.data.account.points_balance)"

# invoice-linked redemption on a live order
$mk3 = Json 'POST' "$API/orders" @{ customer_name = 'Discount Test'; phone = '03215556677'; order_type = 'dine_in'; table_number = 3; order_notes = 'No cutlery needed'; items = @(@{ menu_item_id = 5; quantity = 1 }) } $null
$orderId3 = $mk3.body.data.id
$ord3a = Json 'GET' "$API/orders/${orderId3}?phone=03215556677" $null $staffT
$totalBefore = [double]$ord3a.body.data.total_amount
Result 'dine-in table and order notes are returned' ($ord3a.body.data.table_number -eq 3 -and $ord3a.body.data.order_notes -eq 'No cutlery needed') "table=$($ord3a.body.data.table_number)"
$inv = Json 'POST' "$API/admin/loyalty/redeem" @{ phone = $LoyalPhone; points = 100; order_id = $orderId3; reason = 'bill discount' } $staffT
Result 'invoice-linked redemption OK' ($inv.status -eq 200) "cash=$($inv.body.data.cash_value)"
$ord3b = Json 'GET' "$API/orders/${orderId3}?phone=03215556677" $null $staffT
$expectedTotal = $totalBefore - 100.0
Result 'order total reduced by redemption' ([double]$ord3b.body.data.total_amount -eq $expectedTotal) "before=$totalBefore after=$($ord3b.body.data.total_amount)"
[void](Json 'PATCH' "$API/orders/$orderId3" @{ status = 'delivered' } $staffT)
$ord3c = Json 'GET' "$API/orders/${orderId3}?phone=03215556677" $null $staffT
$earn3 = @($ord3c.body.data.loyalty | Where-Object { $_.type -eq 'earn' })[0]
$expPts3 = [math]::Floor($ord3c.body.data.total_amount / 10)
Result 'earn uses reduced (post-discount) total' ([double]$earn3.qualified_amount -eq [double]$ord3c.body.data.total_amount -and $earn3.points_delta -eq $expPts3) "qualified=$($earn3.qualified_amount) pts=$($earn3.points_delta)"
$inv2 = Json 'POST' "$API/admin/loyalty/redeem" @{ phone = $LoyalPhone; points = 100; order_id = $orderId3 } $staffT
Result 'redeem on delivered order rejected' ($inv2.status -eq 422) "'$($inv2.body.message)'"

Write-Output ""
Write-Output "============================================================="
Write-Output " 8) CANCEL AFTER DELIVERY -> REVERSAL (idempotent)"
Write-Output "============================================================="
$mk4 = Json 'POST' "$API/orders" @{ customer_name = 'Cancel Test'; phone = '03217776655'; order_type = 'delivery'; delivery_address = '9 Rev Rd'; items = @(@{ menu_item_id = 4; quantity = 1 }) } $null
$orderId4 = $mk4.body.data.id
[void](Json 'PATCH' "$API/orders/$orderId4" @{ status = 'delivered' } $staffT)
$beforeC = Json 'GET' "$API/admin/loyalty/customer?phone=03217776655" $null $staffT
$balBefore = $beforeC.body.data.account.points_balance
$cancel = Json 'PATCH' "$API/orders/$orderId4" @{ status = 'cancelled' } $staffT
Result 'cancellation reverses earned points' ($cancel.status -eq 200 -and $cancel.body.message -match 'reversed') "#$orderId4"
$afterC = Json 'GET' "$API/admin/loyalty/customer?phone=03217776655" $null $staffT
$revRow = @($afterC.body.data.transactions | Where-Object { $_.type -eq 'reverse' -and $_.order_id -eq $orderId4 })[0]
Result 'reversal row recorded in ledger' ($null -ne $revRow) "delta=$($revRow.points_delta)"
Result 'fully reversed balance' ($afterC.body.data.account.points_balance -eq ($balBefore + $revRow.points_delta)) "before=$balBefore after=$($afterC.body.data.account.points_balance)"
[void](Json 'PATCH' "$API/orders/$orderId4" @{ status = 'cancelled' } $staffT)
$double = Json 'GET' "$API/admin/loyalty/customer?phone=03217776655" $null $staffT
$revCount = @($double.body.data.transactions | Where-Object { $_.type -eq 'reverse' -and $_.order_id -eq $orderId4 }).Count
Result 'double-reversal impossible' ($revCount -eq 1) "reverse rows=$revCount"

Write-Output ""
Write-Output "============================================================="
Write-Output " 9) ZERO BALANCE via audited settlement"
Write-Output "============================================================="
$zero1 = Json 'POST' "$API/admin/loyalty/zero" @{ phone = $LoyalPhone; reason = 'nope' } $cashierT
Result 'cashier blocked from zeroing (403)' ($zero1.status -eq 403) "got $($zero1.status)"
$zero2 = Json 'POST' "$API/admin/loyalty/zero" @{ phone = $LoyalPhone; reason = 'program reset' } $superT
Result 'super admin zeros balance' ($zero2.status -eq 200 -and $zero2.body.data.balance -eq 0) "cleared=$($zero2.body.data.cleared)"
$zf = Json 'GET' "$API/admin/loyalty/customer?phone=$LoyalPhone" $null $superT
$zeroRow = @($zf.body.data.transactions | Where-Object { $_.reason -match 'ZERO BALANCE' })[0]
Result 'zero settlement recorded (ledger kept)' ($null -ne $zeroRow -and $zeroRow.points_balance_after -eq 0) "row id=$($zeroRow.id)"

Write-Output ""
Write-Output "============================================================="
Write-Output "10) MENU & CATEGORIES CRUD + IMAGE PROCESSING"
Write-Output "============================================================="
$catNo = Json 'POST' "$API/categories" @{ name = 'Side Plates X' } $staffT
Result 'staff blocked from category create (403)' ($catNo.status -eq 403) "got $($catNo.status)"

$cat = Json 'POST' "$API/categories" @{ name = "Side Plates $RunId"; description = 'test category' } $superT
$catId = $cat.body.data.id
Result 'category created' ($cat.status -eq 201) "id=$catId"

$pubCats = Json 'GET' "$API/categories" $null $null
Result 'visible category appears in public list' (@($pubCats.body.data | Where-Object { $_.id -eq $catId }).Count -eq 1) ''

[void](Json 'PUT' "$API/categories/$catId" @{ is_visible = $false } $superT)
$pubCats2 = Json 'GET' "$API/categories" $null $null
Result 'hidden category hidden from customers' (@($pubCats2.body.data | Where-Object { $_.id -eq $catId }).Count -eq 0) ''
[void](Json 'PUT' "$API/categories/$catId" @{ is_visible = $true } $superT)

# image upload -> server-side GD crop/resize to 800x600
$bmpPath = Join-Path $env:TEMP 'savoria_test.png'
Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap(640, 420)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.Clear([System.Drawing.Color]::Tomato)
$g.FillEllipse([System.Drawing.Brushes]::Chocolate, 90, 60, 420, 290)
$g.Dispose(); $bmp.Save($bmpPath, [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()

$up = Upload "$API/admin/upload" $superT $bmpPath 'menu'
$upOk = ($up.status -eq 200 -and $up.body.data.url)
$upFile = ''
if ($upOk) { $upFile = Join-Path 'E:\DecodeLabs-Tasks-main\full-stack-complete-app\frontend' ($up.body.data.url -replace '/', '\') }
Result 'image upload processed server-side' ($upOk) "url=$($up.body.data.url)"
if ($upOk -and (Test-Path $upFile)) {
    $img = [System.Drawing.Image]::FromFile($upFile)
    Result 'uploaded image auto-cropped to 800x600 (4:3)' ($img.Width -eq 800 -and $img.Height -eq 600) "$($img.Width)x$($img.Height)"
    $img.Dispose()
}

$itemNo = Json 'POST' "$API/menu-items" @{ name = 'Forbidden Fries'; category_id = $catId; price = 100 } $custT
Result 'unauthenticated guest cannot create items (401)' ($itemNo.status -eq 401) "got $($itemNo.status)"

$newItem = Json 'POST' "$API/menu-items" @{ name = "Test fries $RunId"; category_id = $catId; price = 321.5; description = 'Test dish'; image_url = $up.body.data.url; spice_level = 1; prep_time_minutes = 9 } $superT
$itemId = $newItem.body.data.id
Result 'menu item created' ($newItem.status -eq 201) "id=$itemId"

$pub = Json 'GET' "$API/menu-items?category_id=$catId" $null $null
Result 'new item visible to customers immediately' (@($pub.body.data | Where-Object { $_.id -eq $itemId }).Count -eq 1) ''

[void](Json 'PUT' "$API/menu-items/$itemId" @{ price = 555.25 } $superT)
$pub2 = Json 'GET' "$API/menu-items" $null $null
$pubItem = @($pub2.body.data | Where-Object { $_.id -eq $itemId })[0]
Result 'price edit shows in storefront' ([double]$pubItem.price -eq 555.25) "price=$($pubItem.price)"

[void](Json 'PUT' "$API/menu-items/$itemId" @{ is_available = $false } $superT)
$avOnly = Json 'GET' "$API/menu-items?available_only=true" $null $null
Result 'unavailable item excluded from orderable list' (@($avOnly.body.data | Where-Object { $_.id -eq $itemId }).Count -eq 0) ''
[void](Json 'PUT' "$API/menu-items/$itemId" @{ is_available = $true } $superT)

# items referenced by old orders get ARCHIVED, not deleted (data preservation)
$mk5 = Json 'POST' "$API/orders" @{ customer_name = 'Archive Test'; phone = '03215554433'; order_type = 'pickup'; items = @(@{ menu_item_id = 1; quantity = 1 }) } $null
$orderId5 = $mk5.body.data.id
[void](Json 'PATCH' "$API/orders/$orderId5" @{ status = 'confirmed' } $staffT)
$delOld = Json 'DELETE' "$API/menu-items/1" $null $superT
$stillThere = Json 'GET' "$API/menu-items/1" $null $staffT
Result 'order-linked item archived, not deleted' ($delOld.status -eq 409 -and $stillThere.status -eq 200) "'$($delOld.body.message)'"
[void](Json 'PUT' "$API/menu-items/1" @{ is_available = $true } $superT)

$adminCats = Json 'GET' "$API/admin/categories" $null $superT
$otherCat = ($adminCats.body.data | Where-Object { $_.id -ne $catId } | Select-Object -First 1)
$del1 = Json 'DELETE' "$API/categories/$catId" $null $superT
Result 'category with items needs reassignment' ($del1.status -eq 409) "'$($del1.body.message)'"
$del2 = Json 'DELETE' "$API/categories/$catId" @{ move_items_to = $otherCat.id } $superT
Result 'category deleted via guarded reassignment' ($del2.status -eq 200) "moved to $($otherCat.name)"

Write-Output ""
Write-Output "============================================================="
Write-Output "11) TODAY'S ORDERS DASHBOARD (real data)"
Write-Output "============================================================="
$today = Json 'GET' "$API/admin/orders-today" $null $staffT
$expectedTotal = $baseline + 5
Result "orders-today count = baseline+5" ($today.body.data.summary.total_orders -eq $expectedTotal) "baseline=$baseline now=$($today.body.data.summary.total_orders)"
$rev = [double]$today.body.data.summary.revenue
Result 'revenue excludes cancelled orders' ($rev -gt 0) "revenue=$rev"
$withLoyalty = @($today.body.data.orders | Where-Object { $_.loyalty -and $_.loyalty.Count -gt 0 })
Result 'per-order loyalty rows present' ($withLoyalty.Count -ge 2) "orders with points=$($withLoyalty.Count)"
$filtered = Json 'GET' "$API/admin/orders-today?status=delivered&search=$orderId1" $null $cashierT
Result 'status filter + order search work' ($filtered.status -eq 200 -and @($filtered.body.data.orders).Count -eq 1) ''

Write-Output ""
Write-Output "============================================================="
Write-Output "12) ACCOUNT EDITS - role/lock protections"
Write-Output "============================================================="
$roleByCashier = Json 'PATCH' "$API/admin/users/$cashierId" @{ role = 'admin' } $cashierT
Result 'cashier cannot promote itself (403)' ($roleByCashier.status -eq 403) "got $($roleByCashier.status)"

$selfDemote = Json 'PATCH' "$API/admin/users/$superId" @{ role = 'cashier' } $superT
Result 'super admin cannot demote itself' ($selfDemote.status -eq 400) "got $($selfDemote.status)"
$deactSelf = Json 'PATCH' "$API/admin/users/$superId" @{ is_active = $false } $superT
Result 'super admin cannot deactivate itself' ($deactSelf.status -eq 400) "got $($deactSelf.status)"

$deactCashier = Json 'PATCH' "$API/admin/users/$cashierId" @{ is_active = $false } $superT
Result 'deactivation works' ($deactCashier.status -eq 200 -and $deactCashier.body.data.is_active -eq $false) ''
$blocked = Json 'POST' "$API/auth/login" @{ email = $email; password = 'Cashier123' }
Result 'deactivated account cannot log in' ($blocked.status -eq 401) "got $($blocked.status)"
[void](Json 'PATCH' "$API/admin/users/$cashierId" @{ is_active = $true } $superT)
$relog = Json 'POST' "$API/auth/login" @{ email = $email; password = 'Cashier123' }
Result 'reactivated account logs back in' ($relog.status -eq 200) ''

Write-Output ""
Write-Output "============================================================="
Write-Output "13) AUDIT LOG"
Write-Output "============================================================="
$audit = Json 'GET' "$API/admin/audit-log?limit=60" $null $superT
$actions = @($audit.body.data | ForEach-Object { $_.action } | Sort-Object -Unique)
$auditNo = Json 'GET' "$API/admin/audit-log" $null $cashierT
Result 'audit log records sensitive actions' ($audit.status -eq 200 -and $actions.Count -ge 10) "distinct actions=$($actions.Count)"
Result 'cashier blocked from audit log (403)' ($auditNo.status -eq 403) "got $($auditNo.status)"
foreach ($want in @('auth.login','user.create','order.status_update','loyalty.earn','loyalty.redeem','loyalty.zero','menu_item.create','category.create')) {
    if ($actions -contains $want) { Result "audit contains $want" $true '' }
    else { Result "audit contains $want" $false '' }
}

Write-Output ""
Write-Output "============================================================="
Write-Output "14) DATABASE INTEGRITY - ledger vs stored balances"
Write-Output "============================================================="
$mysql = 'C:\xampp\mysql\bin\mysql.exe'
$rows = & $mysql -u root -padmin123 -B -N -e "USE savoria_app;
SELECT a.phone, a.points_balance, COALESCE(SUM(t.points_delta),0),
       a.total_earned, COALESCE(SUM(CASE WHEN t.type='earn' AND t.points_delta>0 THEN t.points_delta END),0),
       a.total_redeemed, COALESCE(SUM(CASE WHEN t.type='redeem' THEN -t.points_delta END),0),
       a.total_adjusted, COALESCE(SUM(CASE WHEN t.type='adjust' THEN t.points_delta END),0),
       a.total_reversed, COALESCE(SUM(CASE WHEN t.type='reverse' THEN -t.points_delta END),0)
FROM loyalty_accounts a LEFT JOIN loyalty_transactions t ON t.loyalty_account_id = a.id
GROUP BY a.id;" 2>$null
$allOk = $rows.Count -gt 0
foreach ($row in $rows) {
    $f = "$row" -split "`t"
    if ([int]$f[1] -ne [int]$f[2]) { $allOk = $false; Write-Output "  MISMATCH balance $($f[0]): stored=$($f[1]) ledger=$($f[2])" }
    if ([int]$f[3] -ne [int]$f[4]) { $allOk = $false; Write-Output "  MISMATCH earned $($f[0]): stored=$($f[3]) ledger=$($f[4])" }
    if ([int]$f[5] -ne [int]$f[6]) { $allOk = $false; Write-Output "  MISMATCH redeemed $($f[0]): stored=$($f[5]) ledger=$($f[6])" }
    if ([int]$f[7] -ne [int]$f[8]) { $allOk = $false; Write-Output "  MISMATCH adjusted $($f[0]): stored=$($f[7]) ledger=$($f[8])" }
    if ([int]$f[9] -ne [int]$f[10]) { $allOk = $false; Write-Output "  MISMATCH reversed $($f[0]): stored=$($f[9]) ledger=$($f[10])" }
}
Result 'every account balance == ledger sum (no drift)' ($allOk) "accounts=$($rows.Count)"

$neg = & $mysql -u root -padmin123 -B -N -e "USE savoria_app; SELECT COUNT(*) FROM loyalty_accounts WHERE points_balance < 0;" 2>$null
Result 'no negative balances in database' ("$neg" -eq '0') ''

Write-Output ""
Write-Output "============================================================="
Write-Output " RESULTS: $SCRIPT:pass passed, $SCRIPT:fail failed"
Write-Output "============================================================="
