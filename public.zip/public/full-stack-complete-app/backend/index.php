<?php
/**
 * Tarmez — Full-Stack Complete App
 * backend/index.php — front controller / router
 *
 * Combines menu browsing, ordering, table reservations, and JWT
 * authentication with role-based access control into one API.
 *
 * ── Public ──────────────────────────────────────────────
 *   GET    /categories                 (visible only — customer view)
 *   GET    /menu-items                 (?category_id=, ?available_only=true)
 *   GET    /menu-items/{id}
 *   POST   /auth/login                 (any valid account; self-registration removed)
 *   POST   /auth/forgot-password
 *   POST   /auth/reset-password
 *   POST   /reservations               (rejected with 409 if the time slot is full)
 *   GET    /tables/resolve?token=      (public: turn a table QR token into the table)
 *   GET    /orders/{id}                (guest: requires ?phone= matching the order)
 *   GET    /orders/track?phone=        (guest: all orders for that phone)
 *   GET    /reservations/track?phone=  (guest: all reservations for that phone)
 *
 * ── Customer / guest (orders work for both) ────────────
 *   POST   /orders                     (attaches user_id if a valid token is sent)
 *   GET    /auth/me                    (auth required)
 *   POST   /auth/change-password       (auth required; clears force flag)
 *   GET    /my/orders                  (auth required — current user's orders)
 *   POST   /my/orders/{id}/hide        (auth required — hide an order + its notifications)
 *   POST   /auth/logout                (auth required)
 *
 * ── Management (super_admin, admin, staff, cashier) ────
 *   GET    /orders                     (list all)
 *   PATCH  /orders/{id}                (status / payment method; triggers loyalty accrual)
 *   GET    /reservations               (staff +)
 *   PATCH  /reservations/{id}          (staff +)
 *   GET    /admin/summary              (today's orders/revenue, pending counts)
 *   GET    /admin/orders-today         (today's orders + per-order items + loyalty)
 *   POST   /auth/forgot-password       (public)
 *
 * ── Admin & Super Admin ────────────────────────────────
 *   GET    /admin/users                (super_admin — customer + management lists)
 *   GET/POST/PUT/DELETE /admin/tables[/{id}]  (tables + their QR codes)
 *   POST/PUT/DELETE /menu-items[/{id}] (menu management)
 *   GET/POST/PUT/DELETE /categories[/{id}]  (category management)
 *   PATCH  /categories/order           (single-batch reorder)
 *   POST   /admin/upload               (image processing: crop/resize/validate)
 *
 * ── Loyalty (staff+ to operate) ────────────────────────
 *   GET    /admin/loyalty/settings                       (admin+ read)
 *   PUT    /admin/loyalty/settings                       (super_admin write)
 *   GET    /admin/loyalty/accounts?search=               (staff+)
 *   GET    /admin/loyalty/customer?phone=                (staff+ — summary + ledger)
 *   POST   /admin/loyalty/adjust                         (staff+ — grant/deduct)
 *   POST   /admin/loyalty/redeem                         (staff+ — redeem/reward)
 *   POST   /admin/loyalty/zero                           (admin+ — audited zeroing)
 *
 * ── Super Admin only ───────────────────────────────────
 *   POST   /admin/users                (create MANAGEMENT accounts only)
 *   PATCH  /admin/users/{id}           (edit management roles; customer role is fixed)
 *   POST   /admin/users/{id}/password  (reset an account password)
 */

declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/validate.php';
require_once __DIR__ . '/lib/jwt.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/loyalty.php';
require_once __DIR__ . '/lib/coupons.php';
require_once __DIR__ . '/lib/order_visibility.php';
require_once __DIR__ . '/lib/notifications.php';
require_once __DIR__ . '/lib/images.php';
require_once __DIR__ . '/lib/i18n.php';
require_once __DIR__ . '/lib/invoices.php';
require_once __DIR__ . '/lib/site_content.php';
require_once __DIR__ . '/lib/tables.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, If-None-Match');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$pdo = get_db_connection();
$method = $_SERVER['REQUEST_METHOD'];
$path = get_route_path();
$segments = array_values(array_filter(explode('/', $path)));

/* ════════════════════════════════════════════════════════
   Role hierarchy (enforced server-side on every endpoint)
   ════════════════════════════════════════════════════════ */
const ROLE_SUPER_ADMIN = 'super_admin';
const ROLES_ADMIN      = ['super_admin', 'admin'];
const ROLES_MANAGEMENT = ['super_admin', 'admin', 'staff', 'cashier'];
// Site Management only creates management accounts. Customer accounts are
// created by the customers themselves from the public registration page, and
// a customer can never be promoted into management from this panel.
const ROLES_CREATABLE  = ['staff', 'cashier', 'admin', 'super_admin'];
const ROLE_CUSTOMER    = 'customer';

/** Active promo codes: code => [type, value, label] */
const PROMO_CODES = [
    'SAVORIA10'  => ['type' => 'percent', 'value' => 10, 'label' => '10% off'],
    'WELCOME100' => ['type' => 'flat',    'value' => 100, 'label' => 'SAR 100 off'],
];

function resolve_promo_discount(?string $code, float $subtotal): array
{
    if (!$code) return [null, 0.0];
    $code = strtoupper(trim($code));
    if (!isset(PROMO_CODES[$code])) {
        throw new RuntimeException("Promo code \"$code\" is not valid.");
    }
    $promo = PROMO_CODES[$code];
    $discount = $promo['type'] === 'percent'
        ? round($subtotal * ($promo['value'] / 100), 2)
        : (float) $promo['value'];
    $discount = min($discount, $subtotal); // never discount below zero
    return [$code, $discount];
}

/** Fetch the DB row for the JWT-authenticated actor (used for guards that need live data). */
function actor_db_row(array $currentUser): ?array
{
    static $row = null, $loaded = false;
    if (!$loaded) {
        $stmt = get_db_connection()->prepare('SELECT id, full_name, email, phone, role, is_active FROM users WHERE id = :id');
        $stmt->execute([':id' => (int) $currentUser['sub']]);
        $row = $stmt->fetch() ?: null;
        $loaded = true;
    }
    return $row;
}

if ($path === '/' && $method === 'GET') {
    json_success(['name' => 'Tarmez Full-Stack API', 'version' => '2.0.0'], 'API is running.');
}

/* =========================================================
   AUTH
   ========================================================= */

/**
 * Public customer self-registration.
 *
 * Re-enabled for customers only: the route always creates the
 * 'customer' role, no matter what the request body says, so it can never
 * be used to mint an administrative account. Management accounts are
 * still created from the dashboard (POST /admin/users, super admin).
 *
 * Identity is the phone number (the restaurant's customer key): a second
 * account for the same number is refused. Email is optional; when it is
 * omitted an internal address is generated so the existing email login
 * keeps working, and the customer signs in with their phone instead.
 */
if ($path === '/auth/register' && $method === 'POST') {
    $payload = get_request_body();
    [$isValid, $errors] = validate_customer_register_payload($payload);
    if (!$isValid) json_error('Validation failed.', 422, $errors);

    $phone = loyalty_normalize_phone((string) $payload['phone']);
    $fullName = sanitize_string((string) $payload['full_name']);
    $emailInput = strtolower(trim((string) ($payload['email'] ?? '')));
    $email = $emailInput !== '' ? $emailInput : ($phone . '@customer.tarmez.local');

    if (user_exists_for_phone($pdo, $phone)) {
        json_error('An account with this phone number already exists. Please log in instead.', 409, [
            'phone' => 'This phone number is already registered.',
        ]);
    }

    $check = $pdo->prepare('SELECT id FROM users WHERE email = :email');
    $check->execute([':email' => $email]);
    if ($check->fetch()) {
        json_error('An account with this email already exists. Please log in instead.', 409, [
            'email' => 'This email is already registered.',
        ]);
    }

    try {
        // DDL must stay outside the transaction (MySQL commits implicitly).
        schema_ensure_column($pdo, 'coupons', 'user_id',
            'ALTER TABLE coupons ADD COLUMN user_id INT UNSIGNED DEFAULT NULL AFTER loyalty_account_id');

        $stmt = $pdo->prepare('
            INSERT INTO users (full_name, email, phone, password_hash, role, is_active, force_password_change)
            VALUES (:full_name, :email, :phone, :password_hash, "customer", TRUE, FALSE)
        ');

        $pdo->beginTransaction();
        $stmt->execute([
            ':full_name'     => $fullName,
            ':email'         => $email,
            ':phone'         => $phone,
            ':password_hash' => password_hash((string) $payload['password'], PASSWORD_BCRYPT),
        ]);
        $newId = (int) $pdo->lastInsertId();

        // Any coupons already issued to this phone now belong to the login.
        loyalty_get_or_create_account($pdo, $phone, $fullName);
        coupon_link_user_coupons($pdo, $newId, $phone);

        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        if (str_contains($e->getMessage(), '1062')) {
            json_error('An account with these details already exists. Please log in instead.', 409);
        }
        json_error('Could not create the account right now. Please try again.', 500);
    }

    loyalty_log_action($pdo, ['sub' => $newId, 'email' => $email], 'auth.register', 'user', $newId, [
        'phone' => $phone,
        'role'  => 'customer',
    ]);

    notifications_ensure_schema($pdo);
    notification_create($pdo, [
        'user_id'    => $newId,
        'type'       => 'account',
        'event_key'  => 'account.welcome',
        'title'      => 'Welcome to Tarmez',
        'title_ar'   => 'أهلًا بك في طارمز',
        'body'       => 'Your account is ready. Your coupons and order updates will appear here.',
        'body_ar'    => 'حسابك جاهز الآن. ستظهر كوبوناتك وتحديثات طلباتك هنا.',
        'link_type'  => 'account',
        'dedupe_key' => "user:{$newId}:welcome",
    ]);

    $token = jwt_encode(
        ['sub' => $newId, 'email' => $email, 'role' => 'customer', 'iss' => env('JWT_ISSUER', 'savoria-api')],
        env_required_secret('JWT_SECRET'),
        (int) env('JWT_EXPIRY_SECONDS', 3600)
    );

    json_success([
        'token'      => $token,
        'token_type' => 'Bearer',
        'expires_in' => (int) env('JWT_EXPIRY_SECONDS', 3600),
        'user'       => [
            'id'                    => $newId,
            'full_name'             => $fullName,
            'email'                 => $email,
            'phone'                 => $phone,
            'role'                  => 'customer',
            'force_password_change' => false,
        ],
    ], 'Your account is ready.', 201);
}

if ($path === '/auth/login' && $method === 'POST') {
    $payload = get_request_body();
    [$isValid, $errors] = validate_login_payload($payload);
    if (!$isValid) json_error('Validation failed.', 422, $errors);

    // The same form accepts an email or a phone number. Phone lookup uses
    // the last 10 digits so "+966 5x…" and "05x…" are the same person.
    $identifier = trim((string) ($payload['email'] ?? $payload['identifier'] ?? $payload['phone'] ?? ''));

    if (str_contains($identifier, '@')) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email AND is_active = 1');
        $stmt->execute([':email' => strtolower($identifier)]);
    } else {
        $last10 = phone_last10($identifier);
        $stmt = $pdo->prepare("
            SELECT * FROM users
            WHERE is_active = 1 AND " . phone_sql_expr('phone') . " = :phone
            ORDER BY (role = 'customer') DESC, id DESC
            LIMIT 1
        ");
        $stmt->execute([':phone' => $last10]);
    }
    $user = $stmt->fetch();

    if (!$user || !password_verify($payload['password'], $user['password_hash'])) {
        json_error('Invalid email or password.', 401);
    }

    // Every active role logs in through the same endpoint. Customers get a
    // token too: it is what lets them see their own points, create coupons
    // and spend them. Management routes stay guarded by RBAC.
    $token = jwt_encode(
        ['sub' => $user['id'], 'email' => $user['email'], 'role' => $user['role'], 'iss' => env('JWT_ISSUER', 'savoria-api')],
        env_required_secret('JWT_SECRET'),
        (int) env('JWT_EXPIRY_SECONDS', 3600)
    );

    loyalty_log_action($pdo, ['sub' => (int) $user['id'], 'email' => $user['email']], 'auth.login', 'user', $user['id'], null);

    json_success([
        'token'      => $token,
        'token_type' => 'Bearer',
        'expires_in' => (int) env('JWT_EXPIRY_SECONDS', 3600),
        'user'       => [
            'id'                    => (int) $user['id'],
            'full_name'             => $user['full_name'],
            'email'                 => $user['email'],
            'phone'                 => $user['phone'],
            'role'                  => $user['role'],
            'force_password_change' => (bool) $user['force_password_change'],
        ],
    ], 'Login successful.');
}

if ($path === '/auth/me' && $method === 'GET') {
    $currentUser = require_auth();
    $stmt = $pdo->prepare('SELECT id, full_name, email, phone, role, is_active, force_password_change, created_at FROM users WHERE id = :id');
    $stmt->execute([':id' => $currentUser['sub']]);
    $user = $stmt->fetch();
    if (!$user) json_error('User no longer exists.', 404);
    if (!(int) $user['is_active']) json_error('This account has been deactivated.', 403);
    json_success([
        'id'                    => (int) $user['id'],
        'full_name'             => $user['full_name'],
        'email'                 => $user['email'],
        'phone'                 => $user['phone'],
        'role'                  => $user['role'],
        'force_password_change' => (bool) $user['force_password_change'],
        'created_at'            => $user['created_at'],
    ]);
}

if ($path === '/auth/me' && $method === 'PATCH') {
    $currentUser = require_auth();
    $userId = (int) $currentUser['sub'];

    $stmt = $pdo->prepare('SELECT id, full_name, email, phone, role, is_active, force_password_change, created_at FROM users WHERE id = :id');
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();
    if (!$user) json_error('User no longer exists.', 404);
    if (!(int) $user['is_active']) json_error('This account has been deactivated.', 403);

    $payload = get_request_body();
    $errors = [];

    // The phone is the restaurant's identity key (orders, loyalty and
    // coupons all hang off it), so customers edit name and email only.
    $fullName = null;
    if (array_key_exists('full_name', $payload)) {
        $fullName = sanitize_string((string) $payload['full_name']);
        if ($fullName === '' || mb_strlen($fullName) < 2) {
            $errors['full_name'] = 'Full name must be at least 2 characters.';
        }
    }

    $email = null;
    if (array_key_exists('email', $payload)) {
        $emailInput = strtolower(trim((string) $payload['email']));
        if ($emailInput === '') {
            // Clearing the field keeps the internal login address that
            // stands in for "no email" on phone-only accounts.
            $email = str_ends_with((string) $user['email'], '@customer.tarmez.local')
                ? $user['email']
                : loyalty_normalize_phone((string) $user['phone']) . '@customer.tarmez.local';
        } elseif (!filter_var($emailInput, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'A valid email address is required.';
        } else {
            $email = $emailInput;
        }
    }

    if ($email !== null && $email !== $user['email']) {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = :email AND id <> :id');
        $check->execute([':email' => $email, ':id' => $userId]);
        if ($check->fetch()) {
            $errors['email'] = 'This email is already used by another account.';
        }
    }

    if ($errors) json_error('Validation failed.', 422, $errors);
    if ($fullName === null && $email === null) json_error('Nothing to update.', 422);

    $sets = [];
    $params = [':id' => $userId];
    if ($fullName !== null) { $sets[] = 'full_name = :full_name'; $params[':full_name'] = $fullName; }
    if ($email !== null)    { $sets[] = 'email = :email';         $params[':email'] = $email; }
    $pdo->prepare('UPDATE users SET ' . implode(', ', $sets) . ' WHERE id = :id')->execute($params);

    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();
    json_success([
        'id'                    => (int) $user['id'],
        'full_name'             => $user['full_name'],
        'email'                 => $user['email'],
        'phone'                 => $user['phone'],
        'role'                  => $user['role'],
        'force_password_change' => (bool) $user['force_password_change'],
        'created_at'            => $user['created_at'],
    ], 'Your account details were updated.');
}

if ($path === '/auth/logout' && $method === 'POST') {
    require_auth();
    json_success(null, 'Logged out. Discard the token on the client.');
}

if ($path === '/auth/change-password' && $method === 'POST') {
    $currentUser = require_auth();
    $payload = get_request_body();
    [$isValid, $errors] = validate_change_password_payload($payload);
    if (!$isValid) json_error('Validation failed.', 422, $errors);

    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id');
    $stmt->execute([':id' => $currentUser['sub']]);
    $user = $stmt->fetch();
    if (!$user || !password_verify($payload['current_password'], $user['password_hash'])) {
        json_error('Current password is incorrect.', 401);
    }

    $update = $pdo->prepare('
        UPDATE users SET password_hash = :hash, force_password_change = FALSE WHERE id = :id
    ');
    $update->execute([
        ':hash' => password_hash($payload['new_password'], PASSWORD_BCRYPT),
        ':id'   => $user['id'],
    ]);
    json_success(['force_password_change' => false], 'Password changed successfully.');
}

/**
 * Forgot password: always responds with a generic success message
 * regardless of whether the email exists, to avoid leaking which
 * emails are registered. No email service is wired up in this
 * project, so — for local dev/testing only — the raw reset link is
 * included in the response when APP_DEBUG is enabled. In production
 * this token would be emailed to the user instead of returned here.
 */
if ($path === '/auth/forgot-password' && $method === 'POST') {
    $payload = get_request_body();
    [$isValid, $errors] = validate_forgot_password_payload($payload);
    if (!$isValid) json_error('Validation failed.', 422, $errors);

    $email = strtolower(trim($payload['email']));
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email AND is_active = 1');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    $response = ['message' => 'If an account with that email exists, a password reset link has been sent.'];

    if ($user) {
        $rawToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $rawToken);
        $expiresAt = date('Y-m-d H:i:s', time() + 1800); // 30 minutes

        $insert = $pdo->prepare('
            INSERT INTO password_resets (user_id, token_hash, expires_at)
            VALUES (:user_id, :token_hash, :expires_at)
        ');
        $insert->execute([':user_id' => $user['id'], ':token_hash' => $tokenHash, ':expires_at' => $expiresAt]);

        if (filter_var(env('APP_DEBUG', 'true'), FILTER_VALIDATE_BOOLEAN)) {
            $response['dev_reset_token'] = $rawToken;
            $response['dev_note'] = 'APP_DEBUG is on, so the token is returned here instead of emailed. Set APP_DEBUG=false in production.';
        }
    }

    json_success($response, $response['message']);
}

if ($path === '/auth/reset-password' && $method === 'POST') {
    $payload = get_request_body();
    [$isValid, $errors] = validate_reset_password_payload($payload);
    if (!$isValid) json_error('Validation failed.', 422, $errors);

    $tokenHash = hash('sha256', (string) $payload['token']);
    $stmt = $pdo->prepare('
        SELECT * FROM password_resets
        WHERE token_hash = :hash AND used_at IS NULL AND expires_at > NOW()
        ORDER BY id DESC LIMIT 1
    ');
    $stmt->execute([':hash' => $tokenHash]);
    $reset = $stmt->fetch();

    if (!$reset) json_error('This reset link is invalid or has expired. Please request a new one.', 400);

    $pdo->beginTransaction();
    try {
        $update = $pdo->prepare('
            UPDATE users SET password_hash = :hash, force_password_change = FALSE WHERE id = :id
        ');
        $update->execute([':hash' => password_hash($payload['password'], PASSWORD_BCRYPT), ':id' => $reset['user_id']]);

        $markUsed = $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE id = :id');
        $markUsed->execute([':id' => $reset['id']]);

        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        json_error('Could not reset password due to a server error.', 500);
    }

    json_success(null, 'Password has been reset. You can now log in with your new password.');
}

/* =========================================================
   CATEGORIES
   Customer listing is visibility-filtered; the management
   listing lives at /admin/categories below.
   ========================================================= */

if ($path === '/categories' && $method === 'GET') {
    // The Arabic name/description travel next to the English ones, so a
    // client can switch language instantly without another request.
    $columns = i18n_select_list($pdo, 'categories', ['id', 'name', 'description', 'sort_order', 'image_url']);
    $stmt = $pdo->query("SELECT $columns FROM categories WHERE is_visible = 1 ORDER BY sort_order ASC");
    json_success($stmt->fetchAll());
}

if ($path === '/admin/categories' && $method === 'GET') {
    $currentUser = require_auth();
    require_role($currentUser, ROLES_MANAGEMENT);
    $stmt = $pdo->query('
        SELECT c.*, (SELECT COUNT(*) FROM menu_items m WHERE m.category_id = c.id) AS item_count
        FROM categories c ORDER BY c.sort_order ASC, c.id ASC
    ');
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['id'] = (int) $row['id'];
        $row['sort_order'] = (int) $row['sort_order'];
        $row['is_visible'] = (bool) $row['is_visible'];
        $row['item_count'] = (int) $row['item_count'];
    }
    json_success($rows);
}

/* =========================================================
   MENU ITEMS (customer + management writes)
   ========================================================= */

if (($segments[0] ?? '') === 'menu-items') {

    if ($method === 'GET' && isset($segments[1])) {
        $stmt = $pdo->prepare('
            SELECT m.*, c.name AS category_name' . (i18n_column_exists($pdo, 'categories', 'name_ar') ? ', c.name_ar AS category_name_ar' : '') . '
            FROM menu_items m JOIN categories c ON c.id = m.category_id
            WHERE m.id = :id
        ');
        $stmt->execute([':id' => (int) $segments[1]]);
        $item = $stmt->fetch();
        if (!$item) json_error('Menu item not found.', 404);
        json_success($item);
    }

    if ($method === 'GET') {
        $sql = 'SELECT m.*, c.name AS category_name' . (i18n_column_exists($pdo, 'categories', 'name_ar') ? ', c.name_ar AS category_name_ar' : '')
             . ', c.is_visible AS category_visible
                FROM menu_items m JOIN categories c ON c.id = m.category_id WHERE 1=1';
        $params = [];
        if (!empty($_GET['category_id'])) { $sql .= ' AND m.category_id = :category_id'; $params[':category_id'] = (int)$_GET['category_id']; }
        if (($_GET['available_only'] ?? '') === 'true') { $sql .= ' AND m.is_available = 1'; }

        // The public storefront hides items of invisible categories.
        // Management requests (valid staff/admin token) see everything.
        $currentUser = get_optional_user();
        $isManagement = $currentUser && in_array($currentUser['role'] ?? '', ROLES_MANAGEMENT, true);
        if (!$isManagement) {
            $sql .= ' AND c.is_visible = 1';
        }

        $sql .= (($_GET['all_sort'] ?? '') === 'true')
            ? ' ORDER BY c.sort_order ASC, m.id ASC'
            : ' ORDER BY m.category_id, m.name';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        json_success($stmt->fetchAll());
    }

    // Admin write operations
    if ($method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $payload = get_request_body();
        [$isValid, $errors] = validate_menu_item_payload($payload);
        if (!$isValid) json_error('Validation failed.', 422, $errors);

        try {
            $payload['image_url'] = savoria_validate_image_url((string) ($payload['image_url'] ?? ''));
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }

        $catExists = $pdo->prepare('SELECT id FROM categories WHERE id = :id');
        $catExists->execute([':id' => (int) $payload['category_id']]);
        if (!$catExists->fetch()) json_error('Category does not exist.', 422);

        // The Arabic name/description are optional; they only exist in the
        // database once the multi-language migration has been applied.
        $translatable = i18n_pick_translated($pdo, 'menu_items', ['name', 'description'], $payload);

        $columns = ['category_id', 'name', 'description', 'price', 'calories', 'image_url', 'spice_level', 'prep_time_minutes', 'is_available'];
        if (i18n_column_exists($pdo, 'menu_items', 'discount_percent')) {
            $columns[] = 'discount_percent';
        }
        $columns = array_merge($columns, array_keys($translatable));
        $placeholders = array_map(fn($c) => ':' . $c, $columns);

        $stmt = $pdo->prepare('
            INSERT INTO menu_items (' . implode(', ', $columns) . ')
            VALUES (' . implode(', ', $placeholders) . ')
        ');
        $insertParams = [
            ':category_id' => (int)$payload['category_id'], ':name' => sanitize_string($payload['name']),
            ':description' => sanitize_string($payload['description'] ?? ''),
            ':price' => round((float)$payload['price'], 2),
            ':calories' => (isset($payload['calories']) && $payload['calories'] !== '' && $payload['calories'] !== null)
                ? (int) round((float) $payload['calories']) : null,
            ':image_url' => $payload['image_url'] ?: null, ':spice_level' => (int)($payload['spice_level'] ?? 0),
            ':prep_time_minutes' => (int)($payload['prep_time_minutes'] ?? 15),
            ':is_available' => isset($payload['is_available']) ? (bool)$payload['is_available'] : true,
        ];
        if (i18n_column_exists($pdo, 'menu_items', 'discount_percent')) {
            $insertParams[':discount_percent'] = max(0.0, min(100.0, round((float)($payload['discount_percent'] ?? 0.0), 2)));
        }
        $stmt->execute(array_merge($insertParams, i18n_bind_params($translatable)));
        $stmt2 = $pdo->prepare('SELECT * FROM menu_items WHERE id = :id');
        $stmt2->execute([':id' => (int) $pdo->lastInsertId()]);
        $created = $stmt2->fetch();

        loyalty_log_action($pdo, $currentUser, 'menu_item.create', 'menu_item', (int) $created['id'], ["name" => $created['name']]);
        json_success($created, 'Menu item created.', 201);
    }

    if ($method === 'PUT' && isset($segments[1])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $id = (int) $segments[1];
        $payload = get_request_body();
        [$isValid, $errors] = validate_menu_item_payload($payload, true);
        if (!$isValid) json_error('Validation failed.', 422, $errors);

        if (array_key_exists('image_url', $payload)) {
            try {
                $payload['image_url'] = savoria_validate_image_url((string) $payload['image_url']);
            } catch (RuntimeException $e) {
                json_error($e->getMessage(), 422);
            }
        }

        $fields = []; $params = [':id' => $id];
        $updatable = ['category_id','name','description','price','image_url','spice_level','prep_time_minutes','is_available'];
        if (i18n_column_exists($pdo, 'menu_items', 'calories')) {
            $updatable[] = 'calories';
        }
        if (i18n_column_exists($pdo, 'menu_items', 'discount_percent')) {
            $updatable[] = 'discount_percent';
        }
        foreach ($updatable as $f) {
            if (array_key_exists($f, $payload)) {
                $value = $payload[$f];
                if ($f === 'price') $value = round((float) $value, 2);
                if ($f === 'is_available') $value = $value ? 1 : 0;
                if ($f === 'image_url' && $value === '') $value = null;
                if ($f === 'calories') {
                    // An empty value clears the published calories.
                    $value = ($value === '' || $value === null) ? null : (int) round((float) $value);
                }
                if ($f === 'discount_percent') {
                    $value = max(0.0, min(100.0, round((float) $value, 2)));
                }
                $fields[] = "$f = :$f";
                $params[":$f"] = $value;
            }
        }
        // Arabic companions (name_ar / description_ar) — only when the
        // database carries them.
        foreach (i18n_pick_translated($pdo, 'menu_items', ['name', 'description'], $payload) as $column => $value) {
            $fields[] = "$column = :$column";
            $params[":$column"] = $value;
        }
        if (empty($fields)) json_error('No updatable fields provided.', 422);

        $stmt = $pdo->prepare('UPDATE menu_items SET ' . implode(', ', $fields) . ' WHERE id = :id');
        $stmt->execute($params);

        $stmt2 = $pdo->prepare('SELECT * FROM menu_items WHERE id = :id');
        $stmt2->execute([':id' => $id]);
        $item = $stmt2->fetch();
        if (!$item) json_error('Menu item not found.', 404);

        loyalty_log_action($pdo, $currentUser, 'menu_item.update', 'menu_item', $id, ["fields" => array_keys($fields)]);
        json_success($item, 'Menu item updated.');
    }

    if ($method === 'DELETE' && isset($segments[1])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $id = (int) $segments[1];
        $stmt = $pdo->prepare('DELETE FROM menu_items WHERE id = :id');
        try {
            $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            // FK RESTRICT from order_items: the dish is part of old orders —
            // archive it instead so historical receipts stay intact.
            $archive = $pdo->prepare('UPDATE menu_items SET is_available = 0 WHERE id = :id');
            $archive->execute([':id' => $id]);
            json_error('This item is referenced by existing orders, so it was archived (marked unavailable) instead of deleted.', 409);
        }
        if ($stmt->rowCount() === 0) json_error('Menu item not found.', 404);
        loyalty_log_action($pdo, $currentUser, 'menu_item.delete', 'menu_item', $id, null);
        json_success(null, 'Menu item deleted.');
    }

    json_error('Method not allowed on /menu-items.', 405);
}

/* =========================================================
   CATEGORIES management (admin)
   ========================================================= */

if ($segments[0] === 'categories' && count($segments) <= 2) {

    // (Management listing lives at /admin/categories above — this group
    //  is write access only: POST / PUT / DELETE.)

    if ($method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $payload = get_request_body();

        $name = sanitize_string($payload['name'] ?? '');
        if (strlen($name) < 2) json_error('Category name must be at least 2 characters.', 422);
        if (!empty($payload['name']) && $name !== trim((string)$payload['name'])) {
            // name contained tags that were stripped — reject to stay explicit
        }
        try {
            $imageUrl = savoria_validate_image_url((string) ($payload['image_url'] ?? ''));
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }

        $dupe = $pdo->prepare('SELECT id FROM categories WHERE name = :name');
        $dupe->execute([':name' => $name]);
        if ($dupe->fetch()) json_error('A category with this name already exists.', 409);

        $maxOrder = (int) $pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM categories')->fetchColumn();

        // Arabic companions (name_ar / description_ar) — only added when
        // the database actually carries those columns.
        $translatable = i18n_pick_translated($pdo, 'categories', ['name', 'description'], $payload);
        $columns = ['name', 'description', 'sort_order', 'is_visible', 'image_url'];
        $columns = array_merge($columns, array_keys($translatable));
        $placeholders = array_map(fn($c) => ':' . $c, $columns);

        $stmt = $pdo->prepare('
            INSERT INTO categories (' . implode(', ', $columns) . ')
            VALUES (' . implode(', ', $placeholders) . ')
        ');
        $stmt->execute(array_merge([
            ':name' => $name,
            ':description' => sanitize_string($payload['description'] ?? '') ?: null,
            ':sort_order' => max(0, (int) ($payload['sort_order'] ?? 0)) ?: $maxOrder + 1,
            ':is_visible' => isset($payload['is_visible']) ? (bool) $payload['is_visible'] : true,
            ':image_url' => $imageUrl ?: null,
        ], i18n_bind_params($translatable)));
        $newCategoryId = (int) $pdo->lastInsertId();
        $stmt2 = $pdo->prepare('SELECT * FROM categories WHERE id = :id');
        $stmt2->execute([':id' => $newCategoryId]);
        loyalty_log_action($pdo, $currentUser, 'category.create', 'category', $newCategoryId, ["name" => $name]);
        json_success($stmt2->fetch(), 'Category created.', 201);
    }

    if ($method === 'PUT' && isset($segments[1]) && $segments[1] !== 'order') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $id = (int) $segments[1];
        $payload = get_request_body();

        $fields = []; $params = [':id' => $id];
        if (array_key_exists('name', $payload)) {
            $name = sanitize_string((string) $payload['name']);
            if (strlen($name) < 2) json_error('Category name must be at least 2 characters.', 422);
            $fields[] = 'name = :name'; $params[':name'] = $name;
        }
        if (array_key_exists('description', $payload)) {
            $fields[] = 'description = :description';
            $params[':description'] = sanitize_string((string) $payload['description']) ?: null;
        }
        // Arabic companions (name_ar / description_ar).
        foreach (i18n_pick_translated($pdo, 'categories', ['name', 'description'], $payload) as $column => $value) {
            $fields[] = "$column = :$column";
            $params[":$column"] = $value;
        }
        if (array_key_exists('image_url', $payload)) {
            try {
                $imageUrl = savoria_validate_image_url((string) $payload['image_url']);
                $fields[] = 'image_url = :image_url';
                $params[':image_url'] = $imageUrl ?: null;
            } catch (RuntimeException $e) {
                json_error($e->getMessage(), 422);
            }
        }
        if (array_key_exists('is_visible', $payload)) {
            $fields[] = 'is_visible = :is_visible';
            $params[':is_visible'] = $payload['is_visible'] ? 1 : 0;
        }
        if (array_key_exists('sort_order', $payload)) {
            $fields[] = 'sort_order = :sort_order';
            $params[':sort_order'] = max(0, (int) $payload['sort_order']);
        }
        if (strlen(($fields[0] ?? '')) === 0) json_error('No updatable fields provided.', 422);

        // Name uniqueness when renaming
        if (isset($params[':name'])) {
            $dupe = $pdo->prepare('SELECT id FROM categories WHERE name = :name AND id != :id');
            $dupe->execute([':name' => $params[':name'], ':id' => $id]);
            if ($dupe->fetch()) json_error('Another category already uses this name.', 409);
        }

        $stmt = $pdo->prepare('UPDATE categories SET ' . implode(', ', $fields) . ' WHERE id = :id');
        $stmt->execute($params);
        if ($stmt->rowCount() === 0) {
            $exists = $pdo->prepare('SELECT id FROM categories WHERE id = :id');
            $exists->execute([':id' => $id]);
            if (!$exists->fetch()) json_error('Category not found.', 404);
        }
        loyalty_log_action($pdo, $currentUser, 'category.update', 'category', $id, ["fields" => array_keys($params)]);
        $stmt2 = $pdo->query('SELECT * FROM categories WHERE id = ' . $id);
        json_success($stmt2->fetch(), 'Category updated.');
    }

    // Reorder: PUT /categories/order  body: { order: [ids...] }
    if ($method === 'PUT' && ($segments[1] ?? '') === 'order') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $payload = get_request_body();
        $order = $payload['order'] ?? null;
        if (!is_array($order) || !count($order)) json_error('order array is required (list of category ids).', 422);

        $pdo->beginTransaction();
        try {
            $upd = $pdo->prepare('UPDATE categories SET sort_order = :pos WHERE id = :id');
            foreach (array_values($order) as $position => $categoryId) {
                $upd->execute([':pos' => $position + 1, ':id' => (int) $categoryId]);
            }
            $pdo->commit();
        } catch (PDOException $e) {
            $pdo->rollBack();
            json_error('Could not save the new order.', 500);
        }
        loyalty_log_action($pdo, $currentUser, 'category.reorder', 'category', null, ["order" => $order]);
        json_success(null, 'Category order saved.');
    }

    if ($method === 'DELETE' && isset($segments[1])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $id = (int) $segments[1];

        try {
            if (($_GET['move_items_to'] ?? '') !== '') $moveTo = (int) $_GET['move_items_to'];
            else {
                $payload = get_request_body();
                $moveTo = isset($payload['move_items_to']) ? (int) $payload['move_items_to'] : null;
            }

            $pdo->beginTransaction();
            try {
                if ($moveTo !== null && $moveTo > 0) {
                    if ($moveTo === $id) throw new RuntimeException('Cannot move items into the category being deleted.');
                    $exists = $pdo->prepare('SELECT id FROM categories WHERE id = :id');
                    $exists->execute([':id' => $moveTo]);
                    if (!$exists->fetch()) throw new RuntimeException('Target category not found.');
                    $pdo->prepare('UPDATE menu_items SET category_id = :to WHERE category_id = :from')
                        ->execute([':to' => $moveTo, ':from' => $id]);
                } else {
                    $used = $pdo->prepare('SELECT COUNT(*) FROM menu_items WHERE category_id = :id');
                    $used->execute([':id' => $id]);
                    if ((int) $used->fetchColumn() > 0) {
                        throw new RuntimeException('This category still has menu items. Pass move_items_to=<category id> to reassign them, or delete the items first.');
                    }
                }
                $del = $pdo->prepare('DELETE FROM categories WHERE id = :id');
                $del->execute([':id' => $id]);
                if ($del->rowCount() === 0) throw new RuntimeException('Category not found.');
                $pdo->commit();
            } catch (Throwable $inner) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $inner;
            }
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 409);
        }

        loyalty_log_action($pdo, $currentUser, 'category.delete', 'category', $id, ["move_items_to" => $moveTo ?? null]);
        json_success(null, 'Category deleted.');
    }

    json_error('Method not allowed on /categories.', 405);
}

/* =========================================================
   ORDERS
   ========================================================= */

if (($segments[0] ?? '') === 'orders') {

    // Public order history by phone: GET /orders/track?phone=
    // Lets a customer who just checked out find their order(s) without
    // remembering the order number. Formatting-insensitive: spaces,
    // dashes, and country codes are ignored (last 10 digits compared).
    if ($method === 'GET' && ($segments[1] ?? '') === 'track') {
        $phoneDigits = preg_replace('/\D/', '', (string) ($_GET['phone'] ?? ''));
        if (strlen($phoneDigits) < 7) {
            json_error('Please enter a valid phone number.', 422);
        }

        // Tracking answers for the last 24 hours only: after that the
        // order is history, whatever its status (completed or cancelled
        // included). The full list stays on the customer's account page.
        $stmt = $pdo->prepare("
            SELECT * FROM orders
            WHERE RIGHT(REGEXP_REPLACE(phone, '[^0-9]', ''), 10) = :phone
              AND created_at >= NOW() - INTERVAL 24 HOUR
            ORDER BY created_at DESC, id DESC
            LIMIT 20
        ");
        $stmt->execute([':phone' => substr($phoneDigits, -10)]);
        $orders = $stmt->fetchAll();

        $itemStmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = :id');
        foreach ($orders as &$order) {
            $itemStmt->execute([':id' => $order['id']]);
            $order['items'] = $itemStmt->fetchAll();
            $order['total_amount'] = (float) $order['total_amount'];
            $order['discount_amount'] = (float) $order['discount_amount'];
            $order['points_discount'] = (float) $order['points_discount'];
        }
        unset($order);

        json_success(['orders' => $orders]);
    }

    if ($method === 'GET' && isset($segments[1])) {
        // Guest order tracking: requires either a valid auth token (owner,
        // staff, or admin) or the phone number the order was placed under,
        // so order details (name, address, items, total) can't be scraped
        // by simply guessing sequential order IDs.
        $id = (int) $segments[1];
        $stmt = $pdo->prepare('SELECT * FROM orders WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $order = $stmt->fetch();
        if (!$order) json_error('Order not found.', 404);

        $optionalUser = get_optional_user();
        $isOwnerOrManagement = $optionalUser && (
            (int)($optionalUser['sub'] ?? 0) === (int)$order['user_id']
            || in_array($optionalUser['role'] ?? '', ROLES_MANAGEMENT, true)
        );

        if (!$isOwnerOrManagement) {
            $suppliedPhone = preg_replace('/\D/', '', (string) ($_GET['phone'] ?? ''));
            $orderPhone = preg_replace('/\D/', '', (string) $order['phone']);
            if ($suppliedPhone === '' || $suppliedPhone !== $orderPhone) {
                json_error('To track this order, include the phone number it was placed under (?phone=).', 403);
            }
            // Same 24-hour window as /orders/track: an order that grew
            // too old for the tracking list is not reachable by id either.
            $freshStmt = $pdo->prepare('SELECT created_at >= NOW() - INTERVAL 24 HOUR FROM orders WHERE id = :id');
            $freshStmt->execute([':id' => $id]);
            if (!$freshStmt->fetchColumn()) {
                json_error('This order is older than 24 hours and is no longer available for tracking.', 404);
            }
        }

        $itemsStmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = :id');
        $itemsStmt->execute([':id' => $id]);
        $order['items'] = $itemsStmt->fetchAll();

        // Management viewers also see the points ledger linked to the order.
        if ($isOwnerOrManagement && in_array($optionalUser['role'] ?? '', ROLES_MANAGEMENT, true)) {
            $loyStmt = $pdo->prepare('SELECT type, points_delta, points_balance_after, cash_value, qualified_amount, reason, created_by_name, created_at FROM loyalty_transactions WHERE order_id = :id ORDER BY id ASC');
            $loyStmt->execute([':id' => $id]);
            $order['loyalty'] = $loyStmt->fetchAll();
        }
        $order['total_amount'] = (float) $order['total_amount'];
        $order['discount_amount'] = (float) $order['discount_amount'];
        $order['points_discount'] = (float) $order['points_discount'];
        json_success($order);
    }

    if ($method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);
        $stmt = $pdo->query('SELECT * FROM orders ORDER BY created_at DESC');
        json_success($stmt->fetchAll());
    }

    if ($method === 'POST') {
        $optionalUser = get_optional_user(); // logged-in customers get user_id attached; guests can still order
        $payload = get_request_body();
        [$isValid, $errors] = validate_order_payload($payload);
        if (!$isValid) json_error('Validation failed.', 422, $errors);

        // ── The table, when the order came from a table's QR code ──────
        // The browser only ever sends the token. The number is read from
        // the database here, so editing the link cannot change what the
        // order claims, and an unknown or disabled table is refused.
        $tableToken     = trim((string) ($payload['table_token'] ?? ''));
        $resolvedTable  = null;
        $hasTableColumn = false;
        if ($tableToken !== '') {
            if (!tables_ensure_schema($pdo)) {
                json_error('Table ordering is not available yet.', 503);
            }
            $resolvedTable = table_by_token($pdo, $tableToken, true);
            if (!$resolvedTable) {
                json_error(
                    'This table QR code is not valid or the table is disabled. Please ask the staff.',
                    422,
                    ['table_token' => 'This table QR code is not valid or the table is disabled.']
                );
            }
            $hasTableColumn = i18n_column_exists($pdo, 'orders', 'table_id');
        }

        // A table QR is a dine-in order — the server decides that, not the link.
        $orderType    = $resolvedTable ? 'dine_in' : (string) $payload['order_type'];
        $orderTableNo = $resolvedTable ? (int) $resolvedTable['table_number'] : ($payload['table_number'] ?? null);
        $orderTableId = $resolvedTable ? (int) $resolvedTable['id'] : null;

        // A signed-in customer orders as themselves: the stored contact and
        // the coupon identity come from the account, never from the request
        // body. A forged phone in the body therefore cannot spend another
        // customer's coupon or attach the order to their history.
        $orderPhone = (string) $payload['phone'];
        $orderName  = (string) $payload['customer_name'];
        if ($optionalUser && ($optionalUser['role'] ?? '') === 'customer') {
            $accountStmt = $pdo->prepare('SELECT full_name, phone FROM users WHERE id = :id');
            $accountStmt->execute([':id' => (int) $optionalUser['sub']]);
            $accountRow = $accountStmt->fetch();
            if ($accountRow) {
                if (trim((string) $accountRow['phone']) !== '') $orderPhone = (string) $accountRow['phone'];
                if (trim((string) $accountRow['full_name']) !== '') $orderName = (string) $accountRow['full_name'];
            }
        }

        $hasEarnedColumns = coupon_earned_columns_ready($pdo);

        // Schema work must happen BEFORE the transaction opens — MySQL
        // commits implicitly around DDL. Notifications and the coupon
        // owner column are then plain INSERT/UPDATEs inside the order.
        schema_ensure_column($pdo, 'coupons', 'user_id',
            'ALTER TABLE coupons ADD COLUMN user_id INT UNSIGNED DEFAULT NULL AFTER loyalty_account_id');
        notifications_ensure_schema($pdo);
        // Expiry is a committed state change, so it must happen before the
        // order transaction opens — otherwise the rollback caused by the
        // refused coupon would undo the "expired" mark with it.
        coupon_expire_stale($pdo);

        try {
            $pdo->beginTransaction();

            $total = 0.0;
            $resolvedItems = [];
            $menuStmt = $pdo->prepare('SELECT * FROM menu_items WHERE id = :id AND is_available = 1 FOR UPDATE');

            foreach ($payload['items'] as $line) {
                $menuStmt->execute([':id' => (int) $line['menu_item_id']]);
                $menuItem = $menuStmt->fetch();
                if (!$menuItem) throw new RuntimeException("Menu item id {$line['menu_item_id']} is unavailable or does not exist.");
                $rawPrice = (float) $menuItem['price'];
                $discountPercent = isset($menuItem['discount_percent']) ? (float) $menuItem['discount_percent'] : 0.0;
                $effectivePrice = ($discountPercent > 0 && $discountPercent <= 100)
                    ? round($rawPrice * (1 - $discountPercent / 100), 2)
                    : round($rawPrice, 2);
                $qty = (int) $line['quantity'];
                $subtotal = round($effectivePrice * $qty, 2);
                $total += $subtotal;
                $resolvedItems[] = [
                    'menu_item_id' => $menuItem['id'], 'name' => $menuItem['name'],
                    'unit_price' => $effectivePrice, 'quantity' => $qty, 'subtotal' => $subtotal,
                    'instructions' => isset($line['special_instructions']) && trim((string) $line['special_instructions']) !== ''
                        ? sanitize_string(trim((string) $line['special_instructions'])) : null,
                ];
            }

            [$appliedPromo, $discount] = resolve_promo_discount($payload['promo_code'] ?? null, $total);
            $billAfterPromo = round($total - $discount, 2);

            $orderSettings = loyalty_get_settings($pdo);
            $loyaltyActive = (bool) ($orderSettings['enabled'] ?? false);

            /* ---------------- Coupons ----------------
               The customer may spend coupons they already hold. The bill
               then earns ONE new coupon worth a percentage of it — the
               manager sets that percentage in the admin panel. */
            $couponCodes  = $loyaltyActive ? coupon_normalize_codes($payload['coupon_codes'] ?? []) : [];
            $couponAccount = null;

            if ($optionalUser) {
                $couponAccount = coupon_account_for_user($pdo, $optionalUser);
            }
            if (!$couponAccount && !$optionalUser && trim($orderPhone) !== '') {
                $normPhone = loyalty_normalize_phone($orderPhone);
                if ($normPhone !== '') {
                    $couponAccount = loyalty_get_or_create_account($pdo, $normPhone, $orderName);
                }
            }

            $appliedCoupons = $couponCodes
                ? coupon_validate_for_order(
                    $pdo,
                    $couponCodes,
                    $couponAccount,
                    $billAfterPromo,
                    true,
                    $orderPhone,
                    $optionalUser ? (int) ($optionalUser['sub'] ?? 0) : null
                )
                : [];
            $couponDiscount = coupon_stack_total($appliedCoupons);

            // A coupon keeps its face value. If the stack is worth more than
            // the bill, the customer must remove one — never shrink a coupon.
            if ($couponDiscount > $billAfterPromo + 0.001) {
                throw new RuntimeException(sprintf(
                    'The coupons are worth SAR %.2f but the bill is SAR %.2f — remove a coupon or add more items.',
                    $couponDiscount,
                    $billAfterPromo
                ));
            }

            $billAfterCoupons = round(max(0.0, $billAfterPromo - $couponDiscount), 2);
            $vatRate = (float) ($orderSettings['vat_rate'] ?? 15.00);
            $vatAmount = round($billAfterCoupons * ($vatRate / 100), 2);
            $finalTotal = round($billAfterCoupons + $vatAmount, 2);

            // The coupon this invoice earns is only promised now. Its amount
            // is frozen on the order and the coupon itself is issued when
            // management confirms the order.
            $earnedRules = coupon_settings($pdo);
            $earnedValue = coupon_value_for_bill($earnedRules, $billAfterCoupons);
            $earnedPercent = $earnedValue > 0 ? $earnedRules['percent'] : 0.0;

            // Two numbers:
            //   · the order number is a sequence of its own, handed out
            //     here inside the transaction, so a failed order never
            //     burns a number and two orders can never share one.
            //     The manager can reset it from the panel.
            //   · the invoice number is the permanent number of the
            //     order — it is the order's own id and is never reset.
            $orderNumber = savoria_next_order_number($pdo);
            $hasNumbering = savoria_order_numbering_ready($pdo);

            $hasVatOrders = schema_ensure_column($pdo, 'orders', 'vat_amount',
                'ALTER TABLE orders ADD COLUMN vat_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00, ADD COLUMN vat_rate DECIMAL(5,2) NOT NULL DEFAULT 15.00');

            $orderColumns = ['user_id', 'customer_name', 'phone', 'order_type', 'delivery_address', 'table_number', 'order_notes', 'status', 'total_amount', 'promo_code', 'discount_amount', 'points_discount', 'coupon_discount', 'redeemed_points', 'redeemed_discount'];
            $orderValues  = [':user_id', ':customer_name', ':phone', ':order_type', ':delivery_address', ':table_number', ':order_notes', '"pending"', ':total_amount', ':promo_code', ':discount_amount', ':points_discount', ':coupon_discount', ':redeemed_points', ':redeemed_discount'];
            if ($hasNumbering) {
                $orderColumns[] = 'order_number';
                $orderValues[]  = ':order_number';
            }
            if ($hasVatOrders) {
                $orderColumns[] = 'vat_amount';
                $orderValues[]  = ':vat_amount';
                $orderColumns[] = 'vat_rate';
                $orderValues[]  = ':vat_rate';
            }
            if ($hasTableColumn) {
                $orderColumns[] = 'table_id';
                $orderValues[]  = ':table_id';
            }
            if ($hasEarnedColumns) {
                $orderColumns[] = 'earned_coupon_value';
                $orderValues[]  = ':earned_coupon_value';
                $orderColumns[] = 'earned_coupon_percent';
                $orderValues[]  = ':earned_coupon_percent';
            }

            $orderStmt = $pdo->prepare('
                INSERT INTO orders (' . implode(', ', $orderColumns) . ')
                VALUES (' . implode(', ', $orderValues) . ')
            ');
            $orderStmt->execute(array_merge([
                ':user_id' => $optionalUser['sub'] ?? null,
                ':customer_name' => sanitize_string($orderName), ':phone' => sanitize_string($orderPhone),
                ':order_type' => $orderType,
                ':delivery_address' => $orderType === 'delivery' ? sanitize_string($payload['delivery_address']) : null,
                ':table_number' => $orderTableNo, ':total_amount' => $finalTotal,
                ':order_notes' => isset($payload['order_notes']) && trim((string) $payload['order_notes']) !== ''
                    ? sanitize_string(trim((string) $payload['order_notes'])) : null,
                ':promo_code' => $appliedPromo, ':discount_amount' => $discount,
                ':points_discount' => 0,
                ':coupon_discount' => $couponDiscount,
                ':redeemed_points' => 0,
                ':redeemed_discount' => 0,
            ], $hasNumbering ? [':order_number' => $orderNumber] : [],
               $hasVatOrders ? [':vat_amount' => $vatAmount, ':vat_rate' => $vatRate] : [],
               $hasTableColumn ? [':table_id' => $orderTableId] : [],
               $hasEarnedColumns ? [':earned_coupon_value' => $earnedValue, ':earned_coupon_percent' => $earnedPercent] : []));
            $orderId = (int) $pdo->lastInsertId();

            // The invoice number is the order's own id — permanent, and
            // never affected by a counter reset.
            if (i18n_column_exists($pdo, 'orders', 'invoice_number')) {
                $pdo->prepare('UPDATE orders SET invoice_number = :inv WHERE id = :id')
                    ->execute([':inv' => $orderId, ':id' => $orderId]);
            }

            $itemStmt = $pdo->prepare('
                INSERT INTO order_items (order_id, menu_item_id, item_name_snapshot, unit_price, quantity, subtotal, special_instructions)
                VALUES (:order_id, :menu_item_id, :name, :unit_price, :quantity, :subtotal, :instructions)
            ');
            foreach ($resolvedItems as $item) {
                $itemStmt->execute([
                    ':order_id' => $orderId, ':menu_item_id' => $item['menu_item_id'], ':name' => $item['name'],
                    ':unit_price' => $item['unit_price'], ':quantity' => $item['quantity'],
                    ':subtotal' => $item['subtotal'], ':instructions' => $item['instructions'],
                ]);
            }

            // Lock the coupons the customer spent. They stay 'reserved'
            // until management confirms the order, so a pending order never
            // burns a coupon on its own.
            if ($appliedCoupons) {
                coupon_attach_to_order($pdo, $appliedCoupons, $orderId, $optionalUser);
            }

            // The earned coupon is NOT created here: it is issued inside
            // the confirmation branch of PATCH /orders, using the amount
            // frozen on this row. The UNIQUE issued_for_order_id index still
            // guarantees exactly one coupon per invoice.

            if ($appliedCoupons) {
                loyalty_log_action($pdo, $optionalUser, 'order.discount_applied', 'order', $orderId, [
                    'coupons'         => array_map(fn ($c) => ['code' => $c['code'], 'value' => (float) $c['value']], $appliedCoupons),
                    'coupon_discount' => $couponDiscount,
                ]);
            }

            // Real event: the customer's order is in. Guest orders with no
            // matching login simply produce no notification.
            notification_order_status($pdo, [
                'id'           => $orderId,
                'order_number' => $hasNumbering ? $orderNumber : null,
                'user_id'      => $optionalUser['sub'] ?? null,
                'phone'        => $orderPhone,
                'table_number' => $orderTableNo,
            ], 'pending');

            $pdo->commit();

            $stmt = $pdo->prepare('SELECT * FROM orders WHERE id = :id');
            $stmt->execute([':id' => $orderId]);
            $order = $stmt->fetch();
            $order['items'] = $resolvedItems;
            $order['total_amount'] = (float) $order['total_amount'];
            $order['subtotal'] = (float) $total;
            $order['vat_amount'] = isset($order['vat_amount']) ? (float) $order['vat_amount'] : $vatAmount;
            $order['vat_rate'] = isset($order['vat_rate']) ? (float) $order['vat_rate'] : $vatRate;
            $order['discount_amount'] = (float) $order['discount_amount'];
            $order['points_discount'] = (float) $order['points_discount'];
            $order['coupon_discount'] = (float) $order['coupon_discount'];
            $order['redeemed_points'] = (int) $order['redeemed_points'];
            $order['redeemed_discount'] = (float) $order['redeemed_discount'];
            $order['earned_coupon_value'] = (float) ($order['earned_coupon_value'] ?? $earnedValue);
            $order['earned_coupon_percent'] = (float) ($order['earned_coupon_percent'] ?? $earnedPercent);
            $order['coupons'] = array_map(
                fn ($c) => [
                    'code' => (string) $c['code'],
                    'value' => isset($c['calculated_discount']) ? round((float) $c['calculated_discount'], 2) : round((float) $c['value'], 2),
                ],
                $appliedCoupons
            );
            $order['earned_coupon_preview'] = $earnedValue > 0 ? [
                'value'   => round($earnedValue, 2),
                'percent' => $earnedPercent,
                'status'  => 'pending_confirmation',
            ] : null;
            // The name of the table the guest is sitting at (when the order
            // arrived from a table QR), alongside its number.
            $order['table_label'] = $resolvedTable['label'] ?? null;
            $order['table_label_ar'] = $resolvedTable['label_ar'] ?? null;

            $parts = [];
            if ($couponDiscount > 0) {
                $parts[] = sprintf('SAR %.2f in coupons (%d)', $couponDiscount, count($appliedCoupons));
            }
            if ($earnedValue > 0) {
                $parts[] = sprintf('a SAR %.2f coupon will be added once the order is confirmed', $earnedValue);
            }
            $message = $parts
                ? 'Order placed — ' . implode(', ', $parts) . '.'
                : 'Order placed successfully.';
            json_success($order, $message, 201);
        } catch (RuntimeException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            json_error($e->getMessage(), 422);
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            json_error('Failed to place order due to a database error.', 500);
        }
    }

    if ($method === 'PATCH' && isset($segments[1])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);

        $id = (int) $segments[1];
        $actorId = (int) $currentUser['sub'];
        $payload = get_request_body();
        $validStatuses = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled'];
        $validPayments = ['cash', 'card', 'online'];

        $hasStatus = array_key_exists('status', $payload);
        $hasPayment = array_key_exists('payment_method', $payload);
        if (!$hasStatus && !$hasPayment) {
            json_error('Provide a status and/or payment_method to update.', 422);
        }

        coupon_earned_columns_ready($pdo);
        schema_ensure_column($pdo, 'coupons', 'user_id',
            'ALTER TABLE coupons ADD COLUMN user_id INT UNSIGNED DEFAULT NULL AFTER loyalty_account_id');
        notifications_ensure_schema($pdo);

        $currentStmt = $pdo->prepare('SELECT * FROM orders WHERE id = :id FOR UPDATE');
        $currentStmt->execute([':id' => $id]);
        $current = $currentStmt->fetch();
        if (!$current) json_error('Order not found.', 404);

        $newStatus = $hasStatus ? (string) $payload['status'] : $current['status'];
        if ($hasStatus && !in_array($newStatus, $validStatuses, true)) {
            json_error('A valid status is required: ' . implode(', ', $validStatuses), 422);
        }
        $newPayment = $current['payment_method'];
        if ($hasPayment) {
            $newPayment = $payload['payment_method'] === null || $payload['payment_method'] === ''
                ? null : (string) $payload['payment_method'];
            if ($newPayment !== null && !in_array($newPayment, $validPayments, true)) {
                json_error('payment_method must be one of: ' . implode(', ', $validPayments) . ' (or null).', 422);
            }
        }

        try {
            $pdo->beginTransaction();

            $upd = $pdo->prepare('
                UPDATE orders
                SET status = :status,
                    payment_method = :payment_method,
                    processed_by = :processed_by
                WHERE id = :id
            ');
            $upd->execute([
                ':status' => $newStatus,
                ':payment_method' => $newPayment,
                ':processed_by' => $actorId,
                ':id' => $id,
            ]);

            // A pending order only holds its coupons. The moment management
            // moves it forward (confirmed or any later stage) the reserved
            // coupons are really spent; cancelling puts them back.
            if ($hasStatus && in_array($newStatus, ['confirmed', 'preparing', 'out_for_delivery', 'delivered'], true)) {
                $committed = coupon_commit_order($pdo, $id, $currentUser);
                if (!empty($committed)) {
                    loyalty_log_action($pdo, $currentUser, 'order.coupons_committed', 'order', $id, [
                        'coupons' => array_map(fn ($c) => ['code' => $c['code'], 'value' => (float) $c['value']], $committed),
                    ]);
                }

                // Confirmation is also when the coupon promised at checkout
                // is actually issued. The amount was frozen on the order, so
                // a rule change while it waited cannot alter it.
                $promisedValue = (float) ($current['earned_coupon_value'] ?? 0.0);
                if ($promisedValue > 0) {
                    $already = $pdo->prepare('SELECT COUNT(*) FROM coupons WHERE issued_for_order_id = :oid');
                    $already->execute([':oid' => $id]);
                    if ((int) $already->fetchColumn() === 0) {
                        $billBeforeVat = round((float) $current['total_amount'] - (float) ($current['vat_amount'] ?? 0.0), 2);
                        $earned = coupon_issue_for_order(
                            $pdo,
                            $id,
                            (string) $current['phone'],
                            $current['customer_name'] ?? null,
                            $billBeforeVat,
                            $promisedValue,
                            (float) ($current['earned_coupon_percent'] ?? 0.0)
                        );
                        if ($earned) {
                            loyalty_log_action($pdo, $currentUser, 'coupon.issue_from_order', 'coupon', $earned['id'], [
                                'code'     => $earned['code'],
                                'value'    => $earned['value'],
                                'order_id' => $id,
                                'bill'     => $billBeforeVat,
                                'percent'  => (float) ($current['earned_coupon_percent'] ?? 0.0),
                            ]);
                            notification_coupon_created($pdo, $earned, isset($current['user_id']) ? (int) $current['user_id'] : null);
                        }
                    }
                }
            }

            // Coupons are real, single-use instruments. Cancelling the order
            // returns the coupons spent on it AND revokes the coupon this
            // invoice earned (if it has not been spent elsewhere yet).
            if ($hasStatus && $newStatus === 'cancelled' && $current['status'] !== 'cancelled') {
                $release = coupon_release_order($pdo, $id, 'Order cancelled — coupon returned', $currentUser);
                if (!empty($release['released_coupons']) || !empty($release['revoked_coupons'])) {
                    loyalty_log_action($pdo, $currentUser, 'order.coupons_released', 'order', $id, $release);
                }
                foreach ($release['revoked_coupons'] ?? [] as $revoked) {
                    notification_coupon_cancelled($pdo, $revoked, 'The order that earned this coupon was cancelled.');
                }
            }

            // One notification per real status change. The dedupe key on
            // the row makes a retried PATCH harmless.
            if ($hasStatus && $current['status'] !== $newStatus) {
                notification_order_status($pdo, array_merge($current, ['status' => $newStatus]), $newStatus);
            }

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            json_error('Failed to update the order: ' . $e->getMessage(), 500);
        }

        $stmt2 = $pdo->prepare('
            SELECT o.*, s.full_name AS processed_by_name
            FROM orders o LEFT JOIN users s ON s.id = o.processed_by
            WHERE o.id = :id
        ');
        $stmt2->execute([':id' => $id]);
        $order = $stmt2->fetch();
        if (!$order) json_error('Order not found.', 404);

        loyalty_log_action($pdo, $currentUser, 'order.status_update', 'order', $id, [
            'from' => $current['status'], 'to' => $newStatus,
            'payment_method' => $newPayment,
        ]);

        $order['total_amount'] = (float) $order['total_amount'];
        $order['discount_amount'] = (float) $order['discount_amount'];
        $order['points_discount'] = (float) $order['points_discount'];

        json_success($order, 'Order status updated.');
    }

    json_error('Method not allowed on /orders.', 405);
}

/* =========================================================
   MY ORDERS (authenticated customer's own order history)
   ========================================================= */

if ($path === '/my/orders' && $method === 'GET') {
    $currentUser = require_auth();
    $uid = (int) $currentUser['sub'];

    // Orders placed while signed in carry user_id. Orders placed earlier
    // with the same phone (guest checkout, before accounts were required)
    // are included too — that is the customer's own order history.
    //
    // Two visibility rules apply only to the customer:
    //   1. A pending order that management did not confirm within one hour
    //      is hidden so it cannot sit in the account forever.
    //   2. An order the customer dismissed with the × button on its card
    //      stays hidden for that account.
    // The order itself is never deleted: management still sees it and can
    // confirm or cancel it at any time.
    $uStmt = $pdo->prepare('SELECT phone FROM users WHERE id = :id');
    $uStmt->execute([':id' => $uid]);
    $myPhone = phone_last10((string) ($uStmt->fetchColumn() ?: ''));

    $hiddenSql = '';
    $hiddenParams = [];
    if (customer_hidden_orders_ensure_schema($pdo)) {
        $hiddenSql = '
              AND NOT EXISTS (
                  SELECT 1 FROM customer_hidden_orders customer_hidden
                  WHERE customer_hidden.order_id = orders.id
                    AND customer_hidden.user_id = :hidden_uid
              )';
        $hiddenParams[':hidden_uid'] = $uid;
    }

    if ($myPhone !== '') {
        $stmt = $pdo->prepare('
            SELECT * FROM orders
            WHERE (user_id = :uid OR (' . phone_sql_expr('phone') . ' = :phone))
              AND NOT (status = "pending" AND created_at < (NOW() - INTERVAL 1 HOUR))'
            . $hiddenSql . '
            ORDER BY created_at DESC, id DESC
            LIMIT 200
        ');
        $stmt->execute(array_merge([':uid' => $uid, ':phone' => $myPhone], $hiddenParams));
    } else {
        $stmt = $pdo->prepare('
            SELECT * FROM orders
            WHERE user_id = :uid
              AND NOT (status = "pending" AND created_at < (NOW() - INTERVAL 1 HOUR))'
            . $hiddenSql . '
            ORDER BY created_at DESC, id DESC
            LIMIT 200
        ');
        $stmt->execute(array_merge([':uid' => $uid], $hiddenParams));
    }

    $orders = $stmt->fetchAll();
    $itemStmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = :id ORDER BY id ASC');

    foreach ($orders as &$order) {
        $itemStmt->execute([':id' => $order['id']]);
        $order['items'] = $itemStmt->fetchAll();
        $order['total_amount'] = (float) $order['total_amount'];
        $order['discount_amount'] = (float) $order['discount_amount'];
        $order['points_discount'] = (float) $order['points_discount'];
        $order['coupon_discount'] = (float) ($order['coupon_discount'] ?? 0);
        $order['redeemed_points'] = (int) ($order['redeemed_points'] ?? 0);
        $order['redeemed_discount'] = (float) ($order['redeemed_discount'] ?? 0);
        $order['vat_amount'] = (float) ($order['vat_amount'] ?? 0);
        $order['vat_rate'] = (float) ($order['vat_rate'] ?? 0);
        $order['earned_coupon_value'] = (float) ($order['earned_coupon_value'] ?? 0);
        // The table name when the order came from a table QR.
        $order['table_label'] = null;
        $order['table_label_ar'] = null;
        if (!empty($order['table_id']) && schema_table_exists($pdo, 'restaurant_tables')) {
            $t = $pdo->prepare('SELECT label, label_ar FROM restaurant_tables WHERE id = :id');
            $t->execute([':id' => (int) $order['table_id']]);
            $tableRow = $t->fetch();
            if ($tableRow) {
                $order['table_label'] = $tableRow['label'] ?? null;
                $order['table_label_ar'] = $tableRow['label_ar'] ?? null;
            }
        }
    }
    unset($order);

    json_success($orders);
}

/* Hide one order from this customer's account. The × on the order card
   calls this. It is per account, persistent, and does not touch the order
   row or what management sees. */
if (preg_match('#^/my/orders/(\d+)/hide$#', $path, $m) && $method === 'POST') {
    $currentUser = require_auth();
    $uid = (int) $currentUser['sub'];
    $orderId = (int) $m[1];

    $uStmt = $pdo->prepare('SELECT phone FROM users WHERE id = :id');
    $uStmt->execute([':id' => $uid]);
    $myPhone = phone_last10((string) ($uStmt->fetchColumn() ?: ''));

    if ($myPhone !== '') {
        $own = $pdo->prepare('
            SELECT id FROM orders
            WHERE id = :id
              AND (user_id = :uid OR (' . phone_sql_expr('phone') . ' = :phone))
            LIMIT 1
        ');
        $own->execute([':id' => $orderId, ':uid' => $uid, ':phone' => $myPhone]);
    } else {
        $own = $pdo->prepare('SELECT id FROM orders WHERE id = :id AND user_id = :uid LIMIT 1');
        $own->execute([':id' => $orderId, ':uid' => $uid]);
    }
    if (!$own->fetchColumn()) json_error('Order not found.', 404);

    if (!customer_hide_order($pdo, $uid, $orderId)) {
        json_error('Could not hide the order.', 500);
    }

    json_success(['order_id' => $orderId], 'Order hidden from your account.');
}

/* =========================================================
   MY RESERVATIONS (signed-in customer)
   ---------------------------------------------------------
   Table bookings are made from the account, so the account page can
   show every reservation and its live status. Legacy rows without a
   user_id are matched by the phone on the account.
   ========================================================= */

if ($path === '/me/reservations' && $method === 'GET') {
    $currentUser = require_auth();

    $uStmt = $pdo->prepare('SELECT phone FROM users WHERE id = :id');
    $uStmt->execute([':id' => (int) $currentUser['sub']]);
    $myPhone = phone_last10((string) ($uStmt->fetchColumn() ?: ''));

    if ($myPhone !== '') {
        $stmt = $pdo->prepare('
            SELECT * FROM reservations
            WHERE user_id = :uid
               OR ' . phone_sql_expr('phone') . ' = :phone
            ORDER BY reservation_date DESC, reservation_time DESC, id DESC
            LIMIT 100
        ');
        $stmt->execute([':uid' => (int) $currentUser['sub'], ':phone' => $myPhone]);
    } else {
        $stmt = $pdo->prepare('SELECT * FROM reservations WHERE user_id = :uid ORDER BY reservation_date DESC, reservation_time DESC, id DESC LIMIT 100');
        $stmt->execute([':uid' => (int) $currentUser['sub']]);
    }

    json_success($stmt->fetchAll());
}

/* =========================================================
   COUPON RULES (public, no identity needed)
   The storefront previews the coupon the current bill will earn from
   these values; the server recomputes the exact same figure on checkout.
   ========================================================= */

if ($path === '/loyalty/rules' && $method === 'GET') {
    $rules = coupon_settings($pdo);
    json_success([
        'enabled'        => $rules['enabled'],
        'coupon_percent' => $rules['percent'],
        'min_invoice'    => $rules['min_invoice'],
        'max_per_order'  => $rules['max_per_order'],
        'vat_rate'       => $rules['vat_rate'],
    ]);
}

/* =========================================================
   LOYALTY BALANCE BY PHONE (legacy, kept for historical data and
   admin tooling; the storefront no longer uses phone-keyed balances)
   ========================================================= */

if ($path === '/loyalty/balance' && $method === 'GET') {
    $phone = loyalty_normalize_phone((string) ($_GET['phone'] ?? ''));
    if ($phone === '') json_error('A valid phone number is required.', 422);
    $settings = loyalty_get_settings($pdo);
    $account = $settings['enabled'] ? loyalty_get_account($pdo, $phone) : null;
    $balance = $account ? (int) $account['points_balance'] : 0;
    $value = (float) $settings['redeem_point_value'];
    json_success([
        'found' => (bool) $account,
        'phone' => $phone,
        'balance' => $balance,
        'point_value' => $value,
        'worth' => round($balance * $value, 2),
        'redeem_min_points' => (int) $settings['redeem_min_points'],
        'enabled' => (bool) $settings['enabled'],
    ]);
}

/* =========================================================
   MY LOYALTY (authenticated customer's own points summary,
   for showing the live balance + value during checkout)
   ========================================================= */

if ($path === '/me/loyalty' && $method === 'GET') {
    $currentUser = require_auth();
    $uStmt = $pdo->prepare('SELECT phone, full_name FROM users WHERE id = :id');
    $uStmt->execute([':id' => (int) $currentUser['sub']]);
    $me = $uStmt->fetch();
    if (!$me) json_error('Session expired — log in again.', 401);

    $phone = loyalty_normalize_phone((string) $me['phone']);
    $account = $phone !== '' ? loyalty_get_account($pdo, $phone) : null;
    json_success([
        'found' => (bool) $account,
        'phone' => $phone,
        'customer_name' => $me['full_name'],
        'account' => $account ? [
            'points_balance' => (int) $account['points_balance'],
            'total_earned'   => (int) $account['total_earned'],
            'total_redeemed' => (int) $account['total_redeemed'],
        ] : null,
        'settings' => loyalty_get_settings($pdo),
    ]);
}

/* =========================================================
   COUPONS (customer)
   ---------------------------------------------------------
   A coupon is created by exchanging points and is bound to the
   signed-in customer. The storefront never decides ownership —
   every code is re-validated here before it can pay a bill.
   ========================================================= */

if ($path === '/me/coupons' && $method === 'GET') {
    $currentUser = require_auth();
    $account = coupon_account_for_user($pdo, $currentUser);
    $rules = coupon_settings($pdo);

    coupon_expire_stale($pdo);
    $coupons = $account ? coupon_list_for_account($pdo, (int) $account['id']) : [];
    $available = array_values(array_filter($coupons, fn ($c) => $c['status'] === 'available'));

    json_success([
        'found'           => (bool) $account,
        'enabled'         => $rules['enabled'],
        'phone'           => $account['phone'] ?? null,
        'customer_name'   => $account['customer_name'] ?? null,
        'max_per_order'   => $rules['max_per_order'],
        'available_count' => count($available),
        'coupons'         => $coupons,
    ]);
}

/* =========================================================
   MY NOTIFICATIONS (signed-in customer, per-account isolation)
   ========================================================= */

if ($path === '/me/notifications' && $method === 'GET') {
    $currentUser = require_auth();
    $uid = (int) $currentUser['sub'];
    $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 50;
    $unreadOnly = filter_var($_GET['unread_only'] ?? false, FILTER_VALIDATE_BOOLEAN);

    json_success([
        'notifications' => notification_list($pdo, $uid, $limit, $unreadOnly),
        'unread_count'  => notification_unread_count($pdo, $uid),
    ]);
}

if ($path === '/me/notifications/unread-count' && $method === 'GET') {
    $currentUser = require_auth();
    json_success(['unread_count' => notification_unread_count($pdo, (int) $currentUser['sub'])]);
}

if ($path === '/me/notifications/read-all' && $method === 'POST') {
    $currentUser = require_auth();
    $marked = notification_mark_all_read($pdo, (int) $currentUser['sub']);
    json_success(['marked' => $marked, 'unread_count' => 0], 'All notifications marked as read.');
}

if (preg_match('#^/me/notifications/(\d+)/read$#', $path, $m) && $method === 'POST') {
    $currentUser = require_auth();
    $uid = (int) $currentUser['sub'];
    $notificationId = (int) $m[1];

    if (!notification_mark_read($pdo, $uid, $notificationId)) {
        json_error('Notification not found.', 404);
    }
    json_success([
        'id'            => $notificationId,
        'unread_count'  => notification_unread_count($pdo, $uid),
    ], 'Notification marked as read.');
}

// Public coupon lookup by phone (no login required!)
if ($path === '/coupons/lookup' && $method === 'GET') {
    $phone = (string) ($_GET['phone'] ?? '');
    json_success(coupon_lookup_by_phone($pdo, $phone));
}

// Single coupon validation (preview in cart / checkout)
if ($path === '/coupons/validate' && $method === 'POST') {
    $payload = get_request_body();
    $code = (string) ($payload['code'] ?? '');
    $phone = isset($payload['phone']) && $payload['phone'] !== '' ? (string) $payload['phone'] : null;
    $subtotal = max(0.0, (float) ($payload['subtotal'] ?? 0));

    $optionalUser = get_optional_user();
    $userId = $optionalUser ? (int) ($optionalUser['sub'] ?? 0) : null;

    $res = coupon_validate_single($pdo, $code, $phone, $subtotal, $userId);
    if (!$res['valid']) {
        json_error($res['message'], 422);
    }
    json_success($res, $res['message']);
}

/* =========================================================
   RESERVATIONS
   ========================================================= */

if (($segments[0] ?? '') === 'reservations') {

    if ($method === 'POST') {
        // Reservations are a signed-in feature: the booking is attached to
        // the customer's account so its confirmation/status updates can be
        // delivered to their notification centre.
        $currentUser = require_auth();
        $payload = get_request_body();
        [$isValid, $errors] = validate_reservation_payload($payload);
        if (!$isValid) json_error('Validation failed.', 422, $errors);

        $partySize = (int) $payload['party_size'];
        if (str_contains((string)$payload['party_size'], '6+')) $partySize = 6;
        $reservationTime = normalize_reservation_time((string)$payload['reservation_time']);
        $reservationName = sanitize_string((string) $payload['full_name']);
        $reservationPhone = sanitize_string((string) $payload['phone']);
        $reservationNotes = sanitize_string((string) ($payload['notes'] ?? ''));

        // Prevent double-booking: cap total guests seated per date+time slot.
        $capacity = (int) env('RESTAURANT_SEATING_CAPACITY', '40');

        try {
            $pdo->beginTransaction();

            $bookedStmt = $pdo->prepare("
                SELECT COALESCE(SUM(party_size), 0) AS booked
                FROM reservations
                WHERE reservation_date = :date
                  AND reservation_time = :time
                  AND status IN ('pending', 'confirmed')
                FOR UPDATE
            ");
            $bookedStmt->execute([':date' => $payload['reservation_date'], ':time' => $reservationTime]);
            $booked = (int) $bookedStmt->fetchColumn();

            if ($booked + $partySize > $capacity) {
                $pdo->rollBack();
                json_error('That time slot is fully booked. Please choose a different time.', 409);
            }

            $stmt = $pdo->prepare('
                INSERT INTO reservations (user_id, full_name, phone, party_size, reservation_date, reservation_time, notes)
                VALUES (:user_id, :full_name, :phone, :party_size, :reservation_date, :reservation_time, :notes)
            ');
            $stmt->execute([
                ':user_id' => (int) $currentUser['sub'],
                ':full_name' => $reservationName, ':phone' => $reservationPhone,
                ':party_size' => $partySize, ':reservation_date' => $payload['reservation_date'],
                ':reservation_time' => $reservationTime,
                ':notes' => $reservationNotes,
            ]);
            $reservationId = (int) $pdo->lastInsertId();

            $pdo->commit();
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            json_error('Failed to create reservation due to a database error.', 500);
        }

        // Write the "request received" notification after the booking is
        // safely committed; a notification failure never loses the table.
        try {
            notification_reservation_status($pdo, [
                'id'               => $reservationId,
                'user_id'          => (int) $currentUser['sub'],
                'full_name'        => $reservationName,
                'phone'            => $reservationPhone,
                'party_size'       => $partySize,
                'reservation_date' => $payload['reservation_date'],
                'reservation_time' => $reservationTime,
                'notes'            => $reservationNotes,
            ], 'pending');
        } catch (Throwable $e) {
            // The reservation itself is already saved.
        }

        json_success(['id' => $reservationId], 'Reservation request received.', 201);
    }

    // Public reservation history by phone: GET /reservations/track?phone=
    // Same formatting-insensitive phone match as orders, so a guest can
    // check whether their table was approved without knowing the ID.
    if ($method === 'GET' && ($segments[1] ?? '') === 'track') {
        $phoneDigits = preg_replace('/\D/', '', (string) ($_GET['phone'] ?? ''));
        if (strlen($phoneDigits) < 7) {
            json_error('Please enter a valid phone number.', 422);
        }

        $stmt = $pdo->prepare("
            SELECT * FROM reservations
            WHERE RIGHT(REGEXP_REPLACE(phone, '[^0-9]', ''), 10) = :phone
            ORDER BY reservation_date DESC, reservation_time DESC, id DESC
            LIMIT 20
        ");
        $stmt->execute([':phone' => substr($phoneDigits, -10)]);

        json_success(['reservations' => $stmt->fetchAll()]);
    }

    // Public reservation tracking: GET /reservations/{id}?phone=
    if ($method === 'GET' && isset($segments[1])) {
        $id = (int) $segments[1];
        $stmt = $pdo->prepare('SELECT * FROM reservations WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $reservation = $stmt->fetch();
        if (!$reservation) json_error('Reservation not found.', 404);

        $optionalUser = get_optional_user();
        $isOwnerOrManagement = $optionalUser && (
            (int)($optionalUser['sub'] ?? 0) === (int)$reservation['user_id']
            || in_array($optionalUser['role'] ?? '', ROLES_MANAGEMENT, true)
        );

        if (!$isOwnerOrManagement) {
            $suppliedPhone = preg_replace('/\D/', '', (string) ($_GET['phone'] ?? ''));
            $reservationPhone = preg_replace('/\D/', '', (string) $reservation['phone']);
            if ($suppliedPhone === '' || $suppliedPhone !== $reservationPhone) {
                json_error('To track this reservation, include the phone number it was placed under (?phone=).', 403);
            }
        }

        json_success($reservation);
    }

    if ($method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);
        $stmt = $pdo->query('SELECT * FROM reservations ORDER BY reservation_date, reservation_time');
        json_success($stmt->fetchAll());
    }

    if ($method === 'PATCH' && isset($segments[1])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);

        $id = (int) $segments[1];
        $payload = get_request_body();
        $validStatuses = ['pending', 'confirmed', 'cancelled', 'completed'];
        if (empty($payload['status']) || !in_array($payload['status'], $validStatuses, true)) {
            json_error('A valid status is required: ' . implode(', ', $validStatuses), 422);
        }

        $stmt = $pdo->prepare('SELECT * FROM reservations WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $reservation = $stmt->fetch();
        if (!$reservation) json_error('Reservation not found.', 404);
        $previousStatus = (string) $reservation['status'];

        $update = $pdo->prepare('UPDATE reservations SET status = :status WHERE id = :id');
        $update->execute([':status' => $payload['status'], ':id' => $id]);

        loyalty_log_action($pdo, $currentUser, 'reservation.status_update', 'reservation', $id, ["to" => $payload['status']]);

        // Tell the customer their table was confirmed/cancelled/completed.
        // A repeated PATCH for the same status is deduplicated in SQL.
        if ($previousStatus !== $payload['status']) {
            try {
                notification_reservation_status(
                    $pdo,
                    array_merge($reservation, ['status' => $payload['status']]),
                    $payload['status']
                );
            } catch (Throwable $e) {
                // The status change itself is already saved.
            }
        }

        json_success(['id' => $id, 'status' => $payload['status']], 'Reservation updated.');
    }

    json_error('Method not allowed on /reservations.', 405);
}

/* =========================================================
   PUBLIC — WEBSITE CONTENT (the storefront reads this)
   ========================================================= */

if ($path === '/site-content' && $method === 'GET') {
    $version = site_content_version($pdo);

    // Revalidate on every visit: the panel can change the content at any
    // moment, so the public payload is served with a weak ETag instead of
    // being cached blindly by the browser.
    header('Cache-Control: no-cache, must-revalidate');
    header('ETag: "' . $version . '"');
    if (trim((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? '')) === '"' . $version . '"') {
        http_response_code(304);
        exit;
    }

    json_success([
        'settings'    => site_content_get_settings($pdo),
        'settings_ar' => site_content_get_settings_ar($pdo),
        'images'      => site_content_get_images($pdo),
        'reviews'     => site_content_public_reviews($pdo),
        'version'     => $version,
        'languages'   => i18n_supported_languages(),
    ]);
}

/* =========================================================
   ORDER NUMBER COUNTER (admin)
   The order number is the operational counter the manager can
   reset; the invoice number is permanent and is never touched.
   ========================================================= */

if ($path === '/admin/order-counter' && $method === 'GET') {
    $currentUser = require_auth();
    require_role($currentUser, ROLES_MANAGEMENT);
    json_success([
        'current'  => savoria_order_counter($pdo),
        'ready'    => savoria_order_numbering_ready($pdo),
    ]);
}

if ($path === '/admin/order-counter/reset' && $method === 'POST') {
    $currentUser = require_auth();
    require_role($currentUser, ROLES_ADMIN);

    $value = savoria_reset_order_counter($pdo);
    loyalty_log_action($pdo, $currentUser, 'order_counter.reset', 'order_counter', 'order', ['reset_to' => $value]);

    json_success(['current' => $value], 'The order counter was reset — the next order will be order #1.');
}

/* =========================================================
   ADMIN — TODAY'S DASHBOARD DATA
   ========================================================= */

if ($path === '/admin/summary' && $method === 'GET') {
    $currentUser = require_auth();
    require_role($currentUser, ROLES_MANAGEMENT);

    $today = date('Y-m-d');

    $ordersToday = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = :today");
    $ordersToday->execute([':today' => $today]);

    $revenueToday = $pdo->prepare("
        SELECT COALESCE(SUM(total_amount), 0) FROM orders
        WHERE DATE(created_at) = :today AND status != 'cancelled'
    ");
    $revenueToday->execute([':today' => $today]);

    $pendingOrders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('pending','confirmed','preparing')")->fetchColumn();
    $pendingReservations = $pdo->query("SELECT COUNT(*) FROM reservations WHERE status = 'pending'")->fetchColumn();

    json_success([
        'orders_today'          => (int) $ordersToday->fetchColumn(),
        'revenue_today'         => (float) $revenueToday->fetchColumn(),
        'pending_orders'        => (int) $pendingOrders,
        'pending_reservations'  => (int) $pendingReservations,
    ]);
}

/**
 * Today's orders ledger for the Site Management tool: real data only,
 * with per-order items, status-filtering, phone/order search, loyalty
 * movements, processing staff, and payment method.
 */
if ($path === '/admin/orders-today' && $method === 'GET') {
    $currentUser = require_auth();
    require_role($currentUser, ROLES_MANAGEMENT);

    $today = date('Y-m-d');

    // The table's own name, when the order came from a table QR code. The
    // number itself travels with the order (o.table_number), so this only
    // adds the optional label the manager gave the table.
    $hasTablesSchema = schema_table_exists($pdo, 'restaurant_tables');
    $tableSelect = $hasTablesSchema ? ', t.label AS table_label, t.label_ar AS table_label_ar' : '';
    $tableJoin   = $hasTablesSchema ? ' LEFT JOIN restaurant_tables t ON t.id = o.table_id' : '';

    $sql = '
        SELECT o.*, s.full_name AS processed_by_name' . $tableSelect . ',
               (SELECT COALESCE(SUM(ot.quantity), 0) FROM order_items ot WHERE ot.order_id = o.id) AS item_count
        FROM orders o
        LEFT JOIN users s ON s.id = o.processed_by' . $tableJoin . '
        WHERE DATE(o.created_at) = :today
    ';
    $params = [':today' => $today];

    $search = trim((string) ($_GET['search'] ?? ''));
    $status = trim((string) ($_GET['status'] ?? ''));
    if ($search !== '') {
        if (ctype_digit($search)) {
            // Both numbers are searchable: the permanent invoice number
            // and the operational order number (plus the internal id
            // and the phone number, as before).
            $sql .= ' AND (o.invoice_number = :inv OR o.order_number = :ordno OR o.id = :oid OR o.phone LIKE :sphone)';
            $params[':inv'] = (int) $search;
            $params[':ordno'] = (int) $search;
            $params[':oid'] = (int) $search;
            $params[':sphone'] = $search . '%';
        } else {
            $sql .= ' AND (o.phone LIKE :sphone OR o.customer_name LIKE :sname)';
            $params[':sphone'] = $search . '%';
            $params[':sname'] = '%' . $search . '%';
        }
    }
    $phoneOnly = trim((string) ($_GET['phone'] ?? ''));
    if ($phoneOnly !== '') {
        $sql .= ' AND REPLACE(REPLACE(REPLACE(o.phone, " ", ""), "-", ""), "+", "") = :phone';
        $params[':phone'] = loyalty_normalize_phone($phoneOnly);
    }
    if ($status !== '' && in_array($status, ['pending','confirmed','preparing','out_for_delivery','delivered','cancelled'], true)) {
        $sql .= ' AND o.status = :status';
        $params[':status'] = $status;
    }
    $sql .= ' ORDER BY o.created_at DESC, o.id DESC';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $orders = $stmt->fetchAll();

    // Attach items + the coupons spent/earned per order
    $itemsStmt = $pdo->prepare('SELECT menu_item_id, item_name_snapshot, unit_price, quantity, subtotal, special_instructions FROM order_items WHERE order_id = :id');
    $usedStmt = $pdo->prepare('SELECT code, value FROM order_coupons WHERE order_id = :id ORDER BY id ASC');
    $earnedStmt = $pdo->prepare('SELECT code, value, status FROM coupons WHERE issued_for_order_id = :id LIMIT 1');
    foreach ($orders as &$order) {
        $itemsStmt->execute([':id' => (int) $order['id']]);
        $order['items'] = $itemsStmt->fetchAll();
        $usedStmt->execute([':id' => (int) $order['id']]);
        $order['coupons_used'] = $usedStmt->fetchAll();
        $earnedStmt->execute([':id' => (int) $order['id']]);
        $order['earned_coupon'] = $earnedStmt->fetch() ?: null;
        $order['earned_coupon_value'] = (float) ($order['earned_coupon_value'] ?? 0);
        $order['earned_coupon_percent'] = (float) ($order['earned_coupon_percent'] ?? 0);
        // Promised but not issued yet — the customer sees it as pending
        // until management confirms the order.
        $order['earned_coupon_pending'] = !$order['earned_coupon']
            && $order['earned_coupon_value'] > 0
            && $order['status'] !== 'cancelled'
            ? ['value' => $order['earned_coupon_value'], 'percent' => $order['earned_coupon_percent']]
            : null;
        $order['total_amount'] = (float) $order['total_amount'];
        $order['discount_amount'] = (float) $order['discount_amount'];
        $order['coupon_discount'] = (float) ($order['coupon_discount'] ?? 0);
    }
    unset($order);

    $summaryStmt = $pdo->prepare('
        SELECT
            COUNT(*) AS total_orders,
            SUM(status = "pending") AS pending,
            SUM(status = "confirmed") AS confirmed,
            SUM(status = "preparing") AS preparing,
            SUM(status = "out_for_delivery") AS out_for_delivery,
            SUM(status = "delivered") AS delivered,
            SUM(status = "cancelled") AS cancelled,
            COALESCE(SUM(CASE WHEN status != "cancelled" THEN total_amount ELSE 0 END), 0) AS revenue
        FROM orders WHERE DATE(created_at) = :today
    ');
    $summaryStmt->execute([':today' => $today]);
    $summary = $summaryStmt->fetch();
    $summary = array_map(fn($v) => (int) $v, $summary);
    $summary['revenue'] = $summaryStmt->fetchColumn();
    // revenue must be a float, refetch from same query result:
    $revenueStmt = $pdo->prepare("
        SELECT COALESCE(SUM(CASE WHEN status != 'cancelled' THEN total_amount ELSE 0 END), 0)
        FROM orders WHERE DATE(created_at) = :today
    ");
    $revenueStmt->execute([':today' => $today]);
    $summary['revenue'] = (float) $revenueStmt->fetchColumn();

    json_success([
        'summary' => [
            'total_orders'      => (int) $summary['total_orders'],
            'pending'           => (int) $summary['pending'],
            'confirmed'         => (int) $summary['confirmed'],
            'preparing'         => (int) $summary['preparing'],
            'out_for_delivery'  => (int) $summary['out_for_delivery'],
            'delivered'         => (int) $summary['delivered'],
            'cancelled'         => (int) $summary['cancelled'],
            'revenue'           => $summary['revenue'],
        ],
        'orders' => $orders,
    ]);
}

/* =========================================================
   ADMIN — USER ACCOUNT MANAGEMENT
   ========================================================= */

if ($path === '/admin/users' && $method === 'GET') {
    $currentUser = require_auth();
    // Account lists contain customer emails and management roles, so they are
    // reserved for the Super Admin (the same rule POST/PATCH already follow).
    require_role($currentUser, [ROLE_SUPER_ADMIN]);
    $stmt = $pdo->query('SELECT id, full_name, email, phone, role, is_active, force_password_change, created_at, updated_at FROM users ORDER BY created_at DESC');
    $users = $stmt->fetchAll();
    foreach ($users as &$u) {
        $u['id'] = (int) $u['id'];
        $u['is_active'] = (bool) $u['is_active'];
        $u['force_password_change'] = (bool) $u['force_password_change'];
    }
    json_success($users);
}

if ($path === '/admin/users' && $method === 'POST') {
    $currentUser = require_auth();
    require_role($currentUser, [ROLE_SUPER_ADMIN]);

    $payload = get_request_body();
    [$isValid, $errors] = validate_register_payload($payload);
    if (!$isValid) json_error('Validation failed.', 422, $errors);

    $role = (string) ($payload['role'] ?? 'cashier');
    if ($role === ROLE_CUSTOMER) {
        json_error('Customer accounts are created from the registration page, not from Site Management.', 422);
    }
    if (!in_array($role, ROLES_CREATABLE, true)) {
        json_error('A valid management role is required.', 422);
    }

    $email = strtolower(trim($payload['email']));
    $dupe = $pdo->prepare('SELECT id FROM users WHERE email = :email');
    $dupe->execute([':email' => $email]);
    if ($dupe->fetch()) json_error('An account with this email (username) already exists.', 409);

    if (!empty($payload['phone'])) {
        $phone = loyalty_normalize_phone($payload['phone']);
        if (!preg_match('/^\d{10,13}$/', $phone)) json_error('Phone number format is invalid.', 422);
        $dupePhone = $pdo->prepare('SELECT id FROM users WHERE phone = :phone');
        $dupePhone->execute([':phone' => $phone]);
        if ($dupePhone->fetch()) json_error('An account with this phone number already exists.', 409);
        $payload['phone'] = $phone;
    }

    $stmt = $pdo->prepare('
        INSERT INTO users (full_name, email, phone, password_hash, role, is_active, force_password_change)
        VALUES (:full_name, :email, :phone, :password_hash, :role, TRUE, TRUE)
    ');
    // force_password_change = TRUE: the new owner must change the
    // temporary password before the panel becomes usable.
    $stmt->execute([
        ':full_name'     => sanitize_string($payload['full_name']),
        ':email'         => $email,
        ':phone'         => $payload['phone'] ?? null,
        ':password_hash' => password_hash($payload['password'], PASSWORD_BCRYPT),
        ':role'          => $role,
    ]);
    $newId = (int) $pdo->lastInsertId();

    loyalty_log_action($pdo, $currentUser, 'user.create', 'user', $newId, ["email" => $email, "role" => $role]);
    json_success([
        'id' => $newId,
        'email' => $email,
        'role' => $role,
        'force_password_change' => true,
    ], 'Account created — its owner must change the temporary password at first login.', 201);
}

if (($segments[0] ?? '') === 'admin' && ($segments[1] ?? '') === 'users') {

    // PATCH /admin/users/{id}/role (legacy route kept working)
    if (isset($segments[2]) && ($segments[3] ?? '') === 'role' && $method === 'PATCH') {
        $currentUser = require_auth();
        require_role($currentUser, [ROLE_SUPER_ADMIN]);

        $targetId = (int) $segments[2];
        $payload = get_request_body();

        $targetStmt = $pdo->prepare('SELECT id, role FROM users WHERE id = :id');
        $targetStmt->execute([':id' => $targetId]);
        $target = $targetStmt->fetch();
        if (!$target) json_error('User not found.', 404);

        $role = (string) ($payload['role'] ?? '');
        if ($target['role'] === ROLE_CUSTOMER) {
            json_error('Customer accounts cannot be promoted to management. Create a separate management account instead.', 409);
        }
        if ($role === ROLE_CUSTOMER) {
            json_error('Management accounts cannot be converted into customer accounts.', 409);
        }
        if (!in_array($role, ROLES_CREATABLE, true)) {
            json_error('A valid management role is required.', 422);
        }
        if ($targetId === (int) $currentUser['sub'] && $role !== ROLE_SUPER_ADMIN) {
            json_error('You cannot demote your own account.', 400);
        }

        $stmt = $pdo->prepare('UPDATE users SET role = :role WHERE id = :id');
        $stmt->execute([':role' => $role, ':id' => $targetId]);
        loyalty_log_action($pdo, $currentUser, 'user.role_update', 'user', $targetId, ["role" => $role]);
        json_success(['id' => $targetId, 'role' => $role], 'User role updated.');
    }

    // PATCH /admin/users/{id} — profile edit / role change / activate / deactivate
    if (isset($segments[2]) && ($segments[3] ?? '') !== 'role' && $method === 'PATCH') {
        $currentUser = require_auth();
        require_role($currentUser, [ROLE_SUPER_ADMIN]);

        $targetId = (int) $segments[2];
        $payload = get_request_body();

        $targetStmt = $pdo->prepare('SELECT * FROM users WHERE id = :id');
        $targetStmt->execute([':id' => $targetId]);
        $target = $targetStmt->fetch();
        if (!$target) json_error('User not found.', 404);

        $fields = []; $params = [':id' => $targetId];
        if (array_key_exists('full_name', $payload)) {
            $name = sanitize_string((string) $payload['full_name']);
            if (strlen($name) < 2) json_error('Full name must be at least 2 characters.', 422);
            $fields[] = 'full_name = :full_name'; $params[':full_name'] = $name;
        }
        if (array_key_exists('email', $payload)) {
            $email = strtolower(trim((string) $payload['email']));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_error('A valid email address is required.', 422);
            $dupe = $pdo->prepare('SELECT id FROM users WHERE email = :email AND id != :id');
            $dupe->execute([':email' => $email, ':id' => $targetId]);
            if ($dupe->fetch()) json_error('An account with this email (username) already exists.', 409);
            $fields[] = 'email = :email'; $params[':email'] = $email;
        }
        if (array_key_exists('phone', $payload)) {
            $phone = loyalty_normalize_phone((string) $payload['phone']);
            if (!preg_match('/^\d{10,13}$/', $phone)) json_error('Phone number format is invalid.', 422);
            $dupe = $pdo->prepare('SELECT id FROM users WHERE phone = :phone AND id != :id');
            $dupe->execute([':phone' => $phone, ':id' => $targetId]);
            if ($dupe->fetch()) json_error('Another account already uses this phone number.', 409);
            $fields[] = 'phone = :phone'; $params[':phone'] = $phone;
        }
        if (array_key_exists('role', $payload)) {
            $role = (string) $payload['role'];
            // The customer/management boundary is permanent: a customer
            // account can never become a staff/admin account, and a
            // management account can never become a customer account.
            if ($target['role'] === ROLE_CUSTOMER) {
                json_error('Customer accounts cannot be promoted to management. Create a separate management account instead.', 409);
            }
            if ($role === ROLE_CUSTOMER) {
                json_error('Management accounts cannot be converted into customer accounts.', 409);
            }
            if (!in_array($role, ROLES_CREATABLE, true)) {
                json_error('A valid management role is required.', 422);
            }
            $isSelf = $targetId === (int) $currentUser['sub'];
            if ($isSelf && $role !== ROLE_SUPER_ADMIN) {
                json_error('You cannot demote your own account.', 400);
            }
            if ($target['role'] === ROLE_SUPER_ADMIN && $role !== ROLE_SUPER_ADMIN) {
                // Avoid a locked-out system: keep at least one super admin.
                $others = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = "super_admin" AND id != :id AND is_active = 1');
                $others->execute([':id' => $targetId]);
                if ((int) $others->fetchColumn() === 0) {
                    json_error('At least one active super admin account must remain.', 409);
                }
            }
            $fields[] = 'role = :role'; $params[':role'] = $role;
        }
        if (array_key_exists('is_active', $payload)) {
            $active = (bool) $payload['is_active'];
            if (!$active && $targetId === (int) $currentUser['sub']) {
                json_error('You cannot deactivate your own account.', 400);
            }
            if (!$active && $target['role'] === ROLE_SUPER_ADMIN) {
                $others = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = "super_admin" AND id != :id AND is_active = 1');
                $others->execute([':id' => $targetId]);
                if ((int) $others->fetchColumn() === 0) {
                    json_error('At least one active super admin account must remain.', 409);
                }
            }
            $fields[] = 'is_active = :is_active'; $params[':is_active'] = $active ? 1 : 0;
        }
        if (empty($fields)) json_error('No updatable fields provided.', 422);

        $stmt = $pdo->prepare('UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = :id');
        $stmt->execute($params);
        loyalty_log_action($pdo, $currentUser, 'user.update', 'user', $targetId, ["fields" => array_keys($params)]);
        $stmt2 = $pdo->prepare('SELECT id, full_name, email, phone, role, is_active, force_password_change, created_at FROM users WHERE id = :id');
        $stmt2->execute([':id' => $targetId]);
        $row = $stmt2->fetch();
        $row['id'] = (int) $row['id'];
        $row['is_active'] = (bool) $row['is_active'];
        $row['force_password_change'] = (bool) $row['force_password_change'];
        json_success($row, 'Account updated.');
    }

    // POST /admin/users/{id}/password — set a new password for an account
    if (isset($segments[2]) && ($segments[3] ?? '') === 'password' && $method === 'POST') {
        $currentUser = require_auth();
        $targetId = (int) $segments[2];
        $payload = get_request_body();

        $password = (string) ($payload['password'] ?? '');
        if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
            json_error('Password must be at least 8 characters and include an uppercase letter and a number.', 422);
        }

        $isSelf = $targetId === (int) $currentUser['sub'];
        if ($isSelf) {
            // Self-service password change must verify the current one.
            if (empty($payload['current_password'])) {
                json_error('Your current password is required.', 422);
            }
            $self = $pdo->prepare('SELECT password_hash FROM users WHERE id = :id');
            $self->execute([':id' => $targetId]);
            if (!password_verify($payload['current_password'], $self->fetchColumn())) {
                json_error('Current password is incorrect.', 401);
            }
        } else {
            require_role($currentUser, [ROLE_SUPER_ADMIN]);
        }

        $stmt = $pdo->prepare('
            UPDATE users
            SET password_hash = :hash,
                force_password_change = :force
            WHERE id = :id
        ');
        $stmt->execute([
            ':hash'  => password_hash($password, PASSWORD_BCRYPT),
            // A super-resetting someone else's password forces that user
            // to change it at their next login.
            ':force' => !$isSelf,
            ':id'    => $targetId,
        ]);
        if ($stmt->rowCount() === 0) json_error('User not found.', 404);
        loyalty_log_action($pdo, $currentUser, 'user.password_reset', 'user', $targetId, ["forced_change" => !$isSelf]);
        json_success(['force_password_change' => !$isSelf], $isSelf ? 'Password changed.' : 'Password set — the account will be asked to change it at next login.');
    }

    json_error('Route not found on /admin/users.', 404);
}

/* =========================================================
   ADMIN — LOYALTY SYSTEM
   ========================================================= */

if (($segments[0] ?? '') === 'admin' && ($segments[1] ?? '') === 'loyalty') {

    $subSegment = $segments[2] ?? '';
    $idSegment = isset($segments[3]) ? (int) $segments[3] : null;

    // ---- Loyalty settings (rules) ----
    if ($subSegment === 'settings' && $method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        json_success(loyalty_get_settings($pdo));
    }

    if ($subSegment === 'settings' && $method === 'PUT') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $payload = get_request_body();

        $settings = loyalty_get_settings($pdo);
        $next = [
            'enabled' => array_key_exists('enabled', $payload) ? (bool) $payload['enabled'] : $settings['enabled'],
            'coupon_percent' => array_key_exists('coupon_percent', $payload)
                ? (float) $payload['coupon_percent'] : (float) ($settings['coupon_percent'] ?? 10.00),
            // The minimum invoice is stored in earn_min_order_amount (legacy
            // column name) so no destructive migration is needed.
            'earn_min_order_amount' => array_key_exists('earn_min_order_amount', $payload)
                ? (float) $payload['earn_min_order_amount'] : (float) $settings['earn_min_order_amount'],
            'max_coupons_per_order' => array_key_exists('max_coupons_per_order', $payload)
                ? (int) $payload['max_coupons_per_order'] : (int) ($settings['max_coupons_per_order'] ?? 0),
            'vat_rate' => array_key_exists('vat_rate', $payload)
                ? (float) $payload['vat_rate'] : (float) ($settings['vat_rate'] ?? 15.00),
        ];

        if ($next['coupon_percent'] < 0 || $next['coupon_percent'] > 100) {
            json_error('coupon_percent must be between 0 and 100.', 422);
        }
        if ($next['earn_min_order_amount'] < 0) json_error('The minimum invoice cannot be negative.', 422);
        if ($next['max_coupons_per_order'] < 0) json_error('max_coupons_per_order cannot be negative (0 = no limit).', 422);
        if ($next['vat_rate'] < 0 || $next['vat_rate'] > 100) json_error('vat_rate must be between 0 and 100.', 422);

        $hasVatCol = schema_ensure_column($pdo, 'loyalty_settings', 'vat_rate',
            'ALTER TABLE loyalty_settings ADD COLUMN vat_rate DECIMAL(5,2) NOT NULL DEFAULT 15.00');
        $hasPercentCol = schema_ensure_column($pdo, 'loyalty_settings', 'coupon_percent',
            'ALTER TABLE loyalty_settings ADD COLUMN coupon_percent DECIMAL(5,2) NOT NULL DEFAULT 10.00');

        $vatSet = $hasVatCol ? ', vat_rate = :vat_rate' : '';
        $percentSet = $hasPercentCol ? ', coupon_percent = :coupon_percent' : '';
        $stmt = $pdo->prepare("
            UPDATE loyalty_settings
            SET enabled = :enabled,
                earn_min_order_amount = :earn_min,
                max_coupons_per_order = :max_coupons,
                updated_by = :updated_by
                {$percentSet}
                {$vatSet}
            WHERE id = 1
        ");
        $params = [
            ':enabled' => $next['enabled'] ? 1 : 0,
            ':earn_min' => round($next['earn_min_order_amount'], 2),
            ':max_coupons' => $next['max_coupons_per_order'],
            ':updated_by' => (int) $currentUser['sub'],
        ];
        if ($hasPercentCol) {
            $params[':coupon_percent'] = round($next['coupon_percent'], 2);
        }
        if ($hasVatCol) {
            $params[':vat_rate'] = round($next['vat_rate'], 2);
        }
        $stmt->execute($params);

        $updated = loyalty_get_settings($pdo);
        loyalty_log_action($pdo, $currentUser, 'loyalty.settings_update', 'loyalty_settings', 1, $next);
        json_success($updated, 'Coupon settings saved.');
    }

    // ---- Accounts list ----
    if ($subSegment === 'accounts' && $method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);
        json_success(loyalty_list_accounts($pdo, (string) ($_GET['search'] ?? '')));
    }

    // ---- Customer lookup: full summary + ledger ----
    if ($subSegment === 'customer' && $method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);
        $phone = (string) ($_GET['phone'] ?? '');
        if (loyalty_normalize_phone($phone) === '') {
            json_error('A phone number is required (?phone=).', 422);
        }
        $summary = loyalty_customer_summary($pdo, $phone);
        if ($summary === null) {
            // Not an error the operator must fix — the UI shows a clear
            // not-found message instead of fake data.
            json_success([
                'found' => false,
                'phone' => loyalty_normalize_phone($phone),
                'message' => 'No historical loyalty account exists for this phone number. Balances are kept for older orders and manual grants; the storefront’s instant discount is recorded on each order.',
            ], 'No loyalty account found.');
        }
        $summary['found'] = true;
        $summary['settings'] = loyalty_get_settings($pdo);
        json_success($summary);
    }

    // ---- Manual adjust ----
    if ($subSegment === 'adjust' && $method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);
        $payload = get_request_body();

        $phone = (string) ($payload['phone'] ?? '');
        if (loyalty_normalize_phone($phone) === '') json_error('A valid phone number is required.', 422);
        $points = (int) ($payload['points'] ?? 0);
        $reason = sanitize_string((string) ($payload['reason'] ?? ''));
        try {
            $result = loyalty_adjust_points($pdo, $phone, $points, $reason, $currentUser, sanitize_string((string) ($payload['customer_name'] ?? '')));
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }
        json_success($result, ($points > 0 ? 'Granted ' : 'Deducted ') . abs($points) . ' points. New balance: ' . $result['balance'] . '.');
    }

    // ---- Redeem ----
    if ($subSegment === 'redeem' && $method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);
        $payload = get_request_body();

        $phone = (string) ($payload['phone'] ?? '');
        if (loyalty_normalize_phone($phone) === '') json_error('A valid phone number is required.', 422);
        $points = (int) ($payload['points'] ?? 0);
        $reason = sanitize_string((string) ($payload['reason'] ?? ''));
        $orderId = isset($payload['order_id']) && $payload['order_id'] !== null && $payload['order_id'] !== ''
            ? (int) $payload['order_id'] : null;
        try {
            $result = loyalty_redeem_points($pdo, $phone, $points, $currentUser, $reason ?: null, $orderId);
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }
        json_success($result, sprintf('Redeemed %d points (SAR %s) — new balance %d.', $points, number_format($result['cash_value'], 2), $result['balance']));
    }

    // ---- Zero balance ----
    if ($subSegment === 'zero' && $method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $payload = get_request_body();

        $phone = (string) ($payload['phone'] ?? '');
        if (loyalty_normalize_phone($phone) === '') json_error('A valid phone number is required.', 422);
        $reason = sanitize_string((string) ($payload['reason'] ?? ''));
        try {
            $result = loyalty_zero_balance($pdo, $phone, $reason, $currentUser);
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }
        $cleared = $result['cleared'];
        json_success($result, $cleared > 0
            ? "Balance zeroed — {$cleared} points cleared, settlement recorded in the ledger."
            : 'Balance was already zero.');
    }

    json_error('Route not found on /admin/loyalty.', 404);
}

/* =========================================================
   ADMIN — COUPONS
   ---------------------------------------------------------
   Read is open to every management role (staff need it at the
   counter); cancelling is an admin action and is always audited.
   Historical rows are never deleted — a cancelled coupon keeps its
   code, owner, value and reason for the record.
   ========================================================= */

if (($segments[0] ?? '') === 'admin' && ($segments[1] ?? '') === 'coupons') {

    $couponId = isset($segments[2]) && ctype_digit((string) $segments[2]) ? (int) $segments[2] : null;
    $action   = isset($segments[3]) ? (string) $segments[3] : '';

    // ---- List / search ----
    if (($segments[2] ?? '') === '' && $method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);

        coupon_expire_stale($pdo);

        json_success([
            'coupons'  => coupon_admin_list(
                $pdo,
                trim((string) ($_GET['search'] ?? '')),
                (string) ($_GET['status'] ?? '')
            ),
            'stats'    => coupon_admin_stats($pdo),
            'settings' => coupon_settings($pdo),
        ]);
    }

    // ---- One coupon + its lifecycle log ----
    if ($couponId !== null && $action === '' && $method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_MANAGEMENT);

        $coupon = coupon_find($pdo, $couponId);
        if (!$coupon) json_error('Coupon not found.', 404);

        json_success([
            'coupon' => coupon_present($coupon),
            'events' => coupon_log($pdo, $couponId),
        ]);
    }

    // ---- Cancel an available coupon (reason required) ----
    if ($couponId !== null && $action === 'cancel' && $method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $payload = get_request_body();

        $coupon = coupon_find($pdo, $couponId);
        if (!$coupon) json_error('Coupon not found.', 404);

        $reason = sanitize_string(trim((string) ($payload['reason'] ?? '')));
        if ($reason === '') json_error('A cancellation reason is required.', 422);

        try {
            $cancelled = coupon_cancel($pdo, $coupon, $reason, $currentUser);
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }

        loyalty_log_action($pdo, $currentUser, 'coupon.cancel', 'coupon', $couponId, [
            'code'   => $coupon['code'],
            'value'  => (float) $coupon['value'],
            'phone'  => $coupon['phone'],
            'reason' => $reason,
        ]);

        notification_coupon_cancelled($pdo, $cancelled, $reason);

        json_success($cancelled, 'Coupon cancelled.');
    }

    // ---- Create new coupon ----
    if (($segments[2] ?? '') === '' && $method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $payload = get_request_body();

        try {
            $created = coupon_create($pdo, $payload, $currentUser);
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        } catch (PDOException $e) {
            json_error('Database error while creating coupon: ' . $e->getMessage(), 500);
        }

        loyalty_log_action($pdo, $currentUser, 'coupon.create', 'coupon', $created['id'], [
            'code'          => $created['code'],
            'value'         => $created['value'],
            'discount_type' => $created['discount_type'],
            'phone'         => $created['phone'],
        ]);

        // A coupon created for a customer is a real reward event: it lands
        // in their account and notification centre immediately.
        if (!empty($created['phone'])) {
            notification_coupon_created($pdo, $created);
        }

        json_success($created, 'Coupon created successfully.', 201);
    }

    // ---- Toggle coupon status (active/inactive) ----
    if ($couponId !== null && $action === 'status' && $method === 'PATCH') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);
        $payload = get_request_body();

        $isActive = (bool) ($payload['is_active'] ?? true);
        try {
            $updated = coupon_toggle_active($pdo, $couponId, $isActive, $currentUser);
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }

        loyalty_log_action($pdo, $currentUser, 'coupon.status_toggle', 'coupon', $couponId, [
            'is_active' => $isActive,
        ]);

        json_success($updated, 'Coupon status updated.');
    }

    // ---- Delete coupon ----
    if ($couponId !== null && $action === '' && $method === 'DELETE') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        try {
            $deleted = coupon_delete($pdo, $couponId, $currentUser);
        } catch (RuntimeException $e) {
            json_error($e->getMessage(), 422);
        }

        loyalty_log_action($pdo, $currentUser, 'coupon.delete', 'coupon', $couponId, []);
        json_success(['id' => $couponId, 'deleted' => $deleted], 'Coupon deleted successfully.');
    }

    json_error('Route not found on /admin/coupons.', 404);
}

/* =========================================================
   ADMIN — WEBSITE CONTENT MANAGEMENT (admin + super admin)
   ========================================================= */

if (($segments[0] ?? '') === 'admin' && ($segments[1] ?? '') === 'site-content') {

    // Full CMS payload: the field schema (drives the form), the current
    // values, the image slots and the reviews.
    if ($method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $reviews = $pdo->prepare('SELECT * FROM reviews WHERE restaurant_id = :rid ORDER BY is_featured DESC, display_order ASC, id ASC');
        $reviews->execute([':rid' => SITE_RESTAURANT_ID]);
        $reviewRows = $reviews->fetchAll();
        foreach ($reviewRows as &$r) {
            $r['id'] = (int) $r['id'];
            $r['rating'] = (int) $r['rating'];
            $r['is_featured'] = (bool) $r['is_featured'];
            $r['display_order'] = (int) $r['display_order'];
        }
        unset($r);

        json_success([
            'schema'       => site_content_fields(),
            'image_slots'  => site_content_image_slots(),
            'settings'     => site_content_get_settings($pdo),
            'settings_ar'  => site_content_get_settings_ar($pdo),
            'overrides'    => site_content_get_overrides($pdo, 'en'),
            'overrides_ar' => site_content_get_overrides($pdo, 'ar'),
            'images'       => site_content_get_images($pdo),
            'reviews'      => $reviewRows,
            'version'      => site_content_version($pdo),
        ]);
    }

    // Save a batch of text values.
    if ($method === 'PUT') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $payload = get_request_body();
        $values = is_array($payload['values'] ?? null) ? $payload['values'] : [];
        $valuesAr = is_array($payload['values_ar'] ?? null) ? $payload['values_ar'] : [];

        $currentVersion = site_content_version($pdo);
        if (!empty($payload['version']) && $payload['version'] !== $currentVersion) {
            json_error('The website content was changed by someone else while you were editing. Reload the panel and apply your changes again.', 409);
        }
        if (!$values && !$valuesAr) json_error('There is nothing to save.', 422);

        $clean = [];
        if ($values) {
            [$isValid, $errors, $cleanEn] = site_content_validate($values);
            if (!$isValid) json_error('Some fields need attention.', 422, $errors);
            $clean = $cleanEn;
        }
        $cleanAr = [];
        if ($valuesAr) {
            [$isValidAr, $errorsAr, $cleanArValues] = site_content_validate($valuesAr);
            if (!$isValidAr) json_error('Some fields need attention.', 422, $errorsAr);
            $cleanAr = $cleanArValues;
        }

        try {
            $pdo->beginTransaction();
            if ($clean) site_content_save_settings($pdo, $clean, $currentUser, 'en');
            if ($cleanAr) site_content_save_settings($pdo, $cleanAr, $currentUser, 'ar');
            $pdo->commit();
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            json_error('Could not save the website content.', 500);
        }

        loyalty_log_action($pdo, $currentUser, 'site_content.update', 'site_content', 'settings', [
            'keys' => array_keys($clean),
            'keys_ar' => array_keys($cleanAr),
        ]);

        json_success(
            [
                'settings'    => site_content_get_settings($pdo),
                'settings_ar' => site_content_get_settings_ar($pdo),
                'version'     => site_content_version($pdo),
            ],
            'Website content saved — the public site picks it up on its next load.'
        );
    }

    // Restore one group (or everything) to the shipped defaults.
    if ($method === 'POST' && ($segments[2] ?? '') === 'reset') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $payload = get_request_body();
        $group = isset($payload['group']) && $payload['group'] !== '' ? (string) $payload['group'] : null;
        $deleted = site_content_reset_group($pdo, $group);

        loyalty_log_action($pdo, $currentUser, 'site_content.reset', 'site_content', $group ?? 'all', ['restored' => $deleted]);

        json_success(
            ['settings' => site_content_get_settings($pdo), 'version' => site_content_version($pdo)],
            $deleted > 0
                ? 'Restored the default text for this section.'
                : 'This section was already using the default text.'
        );
    }

    // Replace / update one image slot.
    if ($method === 'POST' && ($segments[2] ?? '') === 'image') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $slots = [];
        foreach (site_content_image_slots() as $slot) $slots[$slot['key']] = $slot;

        // The endpoint accepts both a multipart upload (file + key) and a
        // JSON body (key + url) so the panel can also link an external image.
        $jsonPayload = [];
        if (empty($_POST['key']) && str_contains((string) ($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
            $jsonPayload = get_request_body();
        }

        $key = (string) ($_POST['key'] ?? ($jsonPayload['key'] ?? ''));
        if (!isset($slots[$key])) json_error('Unknown image slot.', 422);
        $slot = $slots[$key];

        $alt = trim((string) ($_POST['alt'] ?? ($jsonPayload['alt'] ?? '')));
        $url = null;
        $urlInput = trim((string) ($_POST['url'] ?? ($jsonPayload['url'] ?? '')));

        $fileKey = isset($_FILES['file']) ? 'file' : (isset($_FILES['image']) ? 'image' : null);
        if ($fileKey !== null) {
            try {
                $url = savoria_process_upload($_FILES[$fileKey], 'site', ['w' => $slot['width'], 'h' => $slot['height']]);
            } catch (RuntimeException $e) {
                json_error($e->getMessage(), 422);
            }
        } elseif ($urlInput !== '') {
            try {
                $url = savoria_validate_image_url($urlInput);
            } catch (RuntimeException $e) {
                json_error($e->getMessage(), 422);
            }
        }

        $existing = $pdo->prepare('SELECT image_url, alt_text FROM site_images WHERE restaurant_id = :rid AND image_key = :k');
        $existing->execute([':rid' => SITE_RESTAURANT_ID, ':k' => $key]);
        $current = $existing->fetch();

        $finalUrl = $url ?? ($current['image_url'] ?? null);
        $finalAlt = $alt !== '' ? $alt : ($current['alt_text'] ?? $slot['alt']);

        $stmt = $pdo->prepare('
            INSERT INTO site_images (restaurant_id, image_key, image_url, default_url, alt_text, updated_by)
            VALUES (:rid, :k, :url, :def, :alt, :by)
            ON DUPLICATE KEY UPDATE
                image_url  = VALUES(image_url),
                alt_text   = VALUES(alt_text),
                updated_by = VALUES(updated_by),
                updated_at = CURRENT_TIMESTAMP
        ');
        $stmt->execute([
            ':rid' => SITE_RESTAURANT_ID,
            ':k'   => $key,
            ':url' => $finalUrl,
            ':def' => $slot['default_url'],
            ':alt' => $finalAlt,
            ':by'  => $currentUser['sub'] ?? null,
        ]);

        loyalty_log_action($pdo, $currentUser, 'site_image.update', 'site_image', $key, ['url' => $finalUrl]);

        json_success(
            ['key' => $key, 'url' => $finalUrl, 'alt' => $finalAlt, 'images' => site_content_get_images($pdo)],
            $url ? 'Image uploaded and applied to the website.' : 'Image details updated.'
        );
    }

    // Restore one image slot to the shipped default.
    if ($method === 'DELETE' && ($segments[2] ?? '') === 'image' && isset($segments[3])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $key = (string) $segments[3];
        $slots = [];
        foreach (site_content_image_slots() as $slot) $slots[$slot['key']] = $slot;
        if (!isset($slots[$key])) json_error('Unknown image slot.', 404);

        $stmt = $pdo->prepare('DELETE FROM site_images WHERE restaurant_id = :rid AND image_key = :k');
        $stmt->execute([':rid' => SITE_RESTAURANT_ID, ':k' => $key]);

        loyalty_log_action($pdo, $currentUser, 'site_image.reset', 'site_image', $key, []);

        json_success(
            ['images' => site_content_get_images($pdo)],
            'The default image is back in place.'
        );
    }

    json_error('Route not found on /admin/site-content.', 404);
}

/* =========================================================
   ADMIN — CUSTOMER REVIEWS (homepage testimonials)
   ========================================================= */

if (($segments[0] ?? '') === 'admin' && ($segments[1] ?? '') === 'reviews') {

    if ($method === 'GET') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $stmt = $pdo->prepare('SELECT * FROM reviews WHERE restaurant_id = :rid ORDER BY is_featured DESC, display_order ASC, id ASC');
        $stmt->execute([':rid' => SITE_RESTAURANT_ID]);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$r) {
            $r['id'] = (int) $r['id'];
            $r['rating'] = (int) $r['rating'];
            $r['is_featured'] = (bool) $r['is_featured'];
            $r['display_order'] = (int) $r['display_order'];
        }
        unset($r);

        json_success($rows);
    }

    if ($method === 'POST') {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $payload = get_request_body();
        $errors = [];
        $name = trim(strip_tags((string) ($payload['author_name'] ?? '')));
        $content = trim(strip_tags((string) ($payload['content'] ?? '')));
        $rating = (int) ($payload['rating'] ?? 5);
        if ($name === '') $errors['author_name'] = 'The guest name is required.';
        if (mb_strlen($name) > 120) $errors['author_name'] = 'The guest name is too long.';
        if ($rating < 1 || $rating > 5) $errors['rating'] = 'Rating must be between 1 and 5.';
        if (mb_strlen($content) > 600) $errors['content'] = 'The review text is too long.';
        if ($errors) json_error('Please fix the highlighted fields.', 422, $errors);

        $source = in_array($payload['source'] ?? '', ['seed', 'customer', 'editorial'], true) ? (string) $payload['source'] : 'editorial';
        $status = in_array($payload['status'] ?? '', ['published', 'pending', 'hidden'], true) ? (string) $payload['status'] : 'published';

        $maxStmt = $pdo->prepare('SELECT COALESCE(MAX(display_order), 0) FROM reviews WHERE restaurant_id = :rid');
        $maxStmt->execute([':rid' => SITE_RESTAURANT_ID]);
        $nextOrder = (int) $maxStmt->fetchColumn() + 1;

        // Arabic companions (author_meta_ar / content_ar).
        $translatable = i18n_pick_translated($pdo, 'reviews', ['author_meta', 'content'], $payload);

        $columns = ['restaurant_id', 'author_name', 'author_meta', 'author_avatar', 'rating', 'content', 'source', 'status', 'is_featured', 'display_order', 'updated_by'];
        $columns = array_merge($columns, array_keys($translatable));
        $placeholders = array_map(fn($c) => ':' . $c, $columns);

        $stmt = $pdo->prepare('
            INSERT INTO reviews (' . implode(', ', $columns) . ')
            VALUES (' . implode(', ', $placeholders) . ')
        ');
        $stmt->execute(array_merge([
            ':rid'      => SITE_RESTAURANT_ID,
            ':name'     => $name,
            ':meta'     => trim(strip_tags((string) ($payload['author_meta'] ?? ''))) ?: null,
            ':avatar'   => trim((string) ($payload['author_avatar'] ?? '')) ?: null,
            ':rating'   => $rating,
            ':content'  => $content,
            ':source'   => $source,
            ':status'   => $status,
            ':featured' => !empty($payload['is_featured']) ? 1 : 0,
            ':ord'      => (int) ($payload['display_order'] ?? $nextOrder),
            ':by'       => $currentUser['sub'] ?? null,
        ], i18n_bind_params($translatable)));
        $newId = (int) $pdo->lastInsertId();

        loyalty_log_action($pdo, $currentUser, 'review.create', 'review', $newId, ['source' => $source, 'status' => $status]);

        json_success(['id' => $newId], 'Review added.', 201);
    }

    if ($method === 'PATCH' && isset($segments[2])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $id = (int) $segments[2];
        $payload = get_request_body();

        $check = $pdo->prepare('SELECT * FROM reviews WHERE id = :id AND restaurant_id = :rid');
        $check->execute([':id' => $id, ':rid' => SITE_RESTAURANT_ID]);
        $review = $check->fetch();
        if (!$review) json_error('Review not found.', 404);

        $errors = [];
        $name = array_key_exists('author_name', $payload) ? trim(strip_tags((string) $payload['author_name'])) : $review['author_name'];
        if ($name === '') $errors['author_name'] = 'The guest name is required.';

        $rating = array_key_exists('rating', $payload) ? (int) $payload['rating'] : (int) $review['rating'];
        if ($rating < 1 || $rating > 5) $errors['rating'] = 'Rating must be between 1 and 5.';

        $content = array_key_exists('content', $payload) ? trim(strip_tags((string) $payload['content'])) : (string) $review['content'];
        if (mb_strlen($content) > 600) $errors['content'] = 'The review text is too long.';

        $status = array_key_exists('status', $payload) ? (string) $payload['status'] : (string) $review['status'];
        if (!in_array($status, ['published', 'pending', 'hidden'], true)) $errors['status'] = 'Invalid status.';

        $source = array_key_exists('source', $payload) ? (string) $payload['source'] : (string) $review['source'];
        if (!in_array($source, ['seed', 'customer', 'editorial'], true)) $errors['source'] = 'Invalid source.';

        if ($errors) json_error('Please fix the highlighted fields.', 422, $errors);

        $meta = array_key_exists('author_meta', $payload) ? trim(strip_tags((string) $payload['author_meta'])) : (string) $review['author_meta'];
        $avatar = array_key_exists('author_avatar', $payload) ? trim((string) $payload['author_avatar']) : (string) $review['author_avatar'];

        // Arabic companions (author_meta_ar / content_ar).
        $translatable = i18n_pick_translated($pdo, 'reviews', ['author_meta', 'content'], $payload);
        $setParts = [
            'author_name = :name', 'author_meta = :meta', 'author_avatar = :avatar',
            'rating = :rating', 'content = :content', 'source = :source', 'status = :status',
            'is_featured = :featured', 'display_order = :ord', 'updated_by = :by',
        ];
        $bind = [
            ':name'     => $name,
            ':meta'     => $meta !== '' ? $meta : null,
            ':avatar'   => $avatar !== '' ? $avatar : null,
            ':rating'   => $rating,
            ':content'  => $content,
            ':source'   => $source,
            ':status'   => $status,
            ':featured' => array_key_exists('is_featured', $payload) ? (!empty($payload['is_featured']) ? 1 : 0) : ($review['is_featured'] ? 1 : 0),
            ':ord'      => array_key_exists('display_order', $payload) ? (int) $payload['display_order'] : (int) $review['display_order'],
            ':by'       => $currentUser['sub'] ?? null,
            ':id'       => $id,
            ':rid'      => SITE_RESTAURANT_ID,
        ];
        foreach ($translatable as $column => $value) {
            $setParts[] = "$column = :$column";
            $bind[":$column"] = $value;
        }

        $stmt = $pdo->prepare('
            UPDATE reviews
            SET ' . implode(', ', $setParts) . '
            WHERE id = :id AND restaurant_id = :rid
        ');
        $stmt->execute($bind);

        loyalty_log_action($pdo, $currentUser, 'review.update', 'review', $id, [
            'from' => $review['status'], 'to' => $status,
        ]);

        json_success(['id' => $id], 'Review updated.');
    }

    if ($method === 'DELETE' && isset($segments[2])) {
        $currentUser = require_auth();
        require_role($currentUser, ROLES_ADMIN);

        $id = (int) $segments[2];
        $stmt = $pdo->prepare('DELETE FROM reviews WHERE id = :id AND restaurant_id = :rid');
        $stmt->execute([':id' => $id, ':rid' => SITE_RESTAURANT_ID]);
        if ($stmt->rowCount() === 0) json_error('Review not found.', 404);

        loyalty_log_action($pdo, $currentUser, 'review.delete', 'review', $id, []);

        json_success(['id' => $id], 'Review deleted.');
    }

    json_error('Route not found on /admin/reviews.', 404);
}

/* =========================================================
   RESTAURANT TABLES & QR CODES
   =========================================================
   · The manager creates a table here. The server mints its QR token,
     so two tables can never share a number or a code.
   · /tables/resolve is the only public door: it turns a scanned token
     back into the table (number + name) and refuses a disabled table.
     Nothing else about the restaurant's tables is public.
   ========================================================= */

if (($segments[0] ?? '') === 'admin' && ($segments[1] ?? '') === 'tables') {
    $currentUser = require_auth();
    require_role($currentUser, ROLES_MANAGEMENT);

    if (!tables_ensure_schema($pdo)) {
        json_error('The tables feature is not available on this database yet.', 503);
    }

    $tableId = isset($segments[2]) && ctype_digit((string) $segments[2]) ? (int) $segments[2] : null;

    // Every table the restaurant has, with its QR code and live status.
    if ($method === 'GET' && $tableId === null) {
        json_success(['tables' => tables_list($pdo)]);
    }

    // Creating, editing and disabling tables is an admin-level tool, the
    // same level as menu management (the panel enforces this too).
    if (in_array($method, ['POST', 'PUT', 'DELETE'], true)) {
        require_role($currentUser, ROLES_ADMIN);
    }

    if ($method === 'POST' && $tableId === null) {
        $payload = get_request_body();
        [$ok, $errors, $clean] = validate_table_payload($payload, false);
        if (!$ok) json_error('Validation failed.', 422, $errors);

        try {
            $stmt = $pdo->prepare('
                INSERT INTO restaurant_tables (table_number, label, label_ar, seats, status, qr_token)
                VALUES (:n, :l, :lar, :seats, :status, :token)
            ');
            $stmt->execute([
                ':n'      => $clean['table_number'],
                ':l'      => $clean['label'] ?? null,
                ':lar'    => $clean['label_ar'] ?? null,
                ':seats'  => $clean['seats'] ?? 4,
                ':status' => $clean['status'] ?? 'active',
                ':token'  => table_new_token($pdo),
            ]);
        } catch (PDOException $e) {
            // The UNIQUE index on table_number is the real guard: two tables
            // can never share a number, even when two managers add one at once.
            if ($e->getCode() === '23000') {
                json_error('Table number ' . $clean['table_number'] . ' already exists.', 422, [
                    'table_number' => 'This table number is already used by another table.',
                ]);
            }
            throw $e;
        }

        $newId = (int) $pdo->lastInsertId();
        loyalty_log_action($pdo, $currentUser, 'table.create', 'restaurant_table', $newId, [
            'table_number' => $clean['table_number'],
        ]);

        json_success(table_serialize(table_by_id($pdo, $newId), true), 'Table created.', 201);
    }

    if ($method === 'PUT' && $tableId !== null) {
        if (!table_by_id($pdo, $tableId)) json_error('Table not found.', 404);

        $payload = get_request_body();
        [$ok, $errors, $clean] = validate_table_payload($payload, true);
        if (!$ok) json_error('Validation failed.', 422, $errors);
        if (!$clean) json_error('Nothing to update.', 422);

        // $clean only ever carries whitelisted column names (see the validator),
        // so the statement below can never be built from user input.
        $sets = [];
        $params = [':id' => $tableId];
        foreach ($clean as $column => $value) {
            $sets[] = "$column = :$column";
            $params[":$column"] = $value;
        }

        try {
            $pdo->prepare('UPDATE restaurant_tables SET ' . implode(', ', $sets) . ' WHERE id = :id')
                ->execute($params);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                json_error('Table number ' . ($clean['table_number'] ?? '') . ' already exists.', 422, [
                    'table_number' => 'This table number is already used by another table.',
                ]);
            }
            throw $e;
        }

        loyalty_log_action($pdo, $currentUser, 'table.update', 'restaurant_table', $tableId, $clean);
        json_success(table_serialize(table_by_id($pdo, $tableId), true), 'Table updated.');
    }

    if ($method === 'DELETE' && $tableId !== null) {
        $existing = table_by_id($pdo, $tableId);
        if (!$existing) json_error('Table not found.', 404);

        // A table that has orders is never deleted: its history would lose
        // the table it was served at. Disabling it stops its QR code from
        // working while the history stays intact.
        $refs = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE table_id = :id');
        $refs->execute([':id' => $tableId]);
        if ((int) $refs->fetchColumn() > 0) {
            json_error(
                'This table has orders in its history, so it cannot be deleted. Disable it instead.',
                409,
                ['table' => 'Disable the table instead — it has order history.']
            );
        }

        $pdo->prepare('DELETE FROM restaurant_tables WHERE id = :id')->execute([':id' => $tableId]);
        loyalty_log_action($pdo, $currentUser, 'table.delete', 'restaurant_table', $tableId, [
            'table_number' => (int) $existing['table_number'],
        ]);

        json_success(['id' => $tableId], 'Table deleted.');
    }

    json_error('Method not allowed on /admin/tables.', 405);
}

/* =========================================================
   PUBLIC — RESOLVE A TABLE QR TOKEN
   =========================================================
   The only public door to the tables. It turns the token printed on a
   QR code back into the table it belongs to, so the menu page can show
   the table and bind the order to it. A disabled or unknown table is
   refused; nothing else about the tables is exposed.
   ========================================================= */

if ($path === '/tables/resolve' && $method === 'GET') {
    $token = (string) ($_GET['token'] ?? '');
    if ($token === '' || !tables_ensure_schema($pdo) || !table_token_is_well_formed($token)) {
        json_error('This table QR code is not valid.', 404);
    }

    $table = table_by_token($pdo, $token, true);
    if (!$table) {
        json_error('This table QR code is not valid or the table is disabled.', 404);
    }

    json_success(table_serialize($table, false), 'Table found.');
}

/* =========================================================
   ADMIN — AUDIT LOG (super admin)
   ========================================================= */

if ($path === '/admin/audit-log' && $method === 'GET') {
    $currentUser = require_auth();
    require_role($currentUser, [ROLE_SUPER_ADMIN]);
    $limit = max(1, min(200, (int) ($_GET['limit'] ?? 60)));
    $stmt = $pdo->prepare('SELECT * FROM admin_audit_log ORDER BY created_at DESC, id DESC LIMIT :lim');
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) $r['user_id'] = $r['user_id'] !== null ? (int) $r['user_id'] : null;
    json_success($rows);
}

/* =========================================================
   ADMIN — IMAGE UPLOAD (processed & stored server-side)
   ========================================================= */

if ($path === '/admin/upload' && $method === 'POST') {    $currentUser = require_auth();
    require_role($currentUser, ROLES_ADMIN);

    $key = $_FILES['file'] ? 'file' : ($_FILES['image'] ? 'image' : null);
    if ($key === null) json_error('Attach the image in the "file" (or "image") form field.', 422);
    $prefix = ($_POST['prefix'] ?? 'menu') === 'category' ? 'category' : 'menu';
    try {
        $url = savoria_process_upload($_FILES[$key], $prefix);
    } catch (RuntimeException $e) {
        json_error($e->getMessage(), 422);
    }
    json_success(['url' => $url], 'Image uploaded and processed.');
}

json_error("Route {$path} not found.", 404);
