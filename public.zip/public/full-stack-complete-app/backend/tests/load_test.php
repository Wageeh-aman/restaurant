<?php
/**
 * Tarmez — read-only load tester.
 *
 * No dependencies: uses curl_multi, so it runs from XAMPP as-is.
 *
 *   C:/xampp/php/php.exe backend/tests/load_test.php --base=http://localhost:8000 --duration=60 --concurrency=20
 *
 * Optional admin traffic (adds /admin/summary and /admin/orders-today):
 *   ... --email=admin@savoria.example --password=Password123!
 *
 * The loop keeps N requests in flight (closed loop). Read the result as
 * "throughput at N concurrent visitors", not the hosting ceiling: raise
 * --concurrency in steps and stop when p95 doubles or errors appear.
 *
 * Every endpoint below is read-only; no orders, coupons or settings change.
 */

declare(strict_types=1);

$opts = getopt('', ['base::', 'duration::', 'concurrency::', 'timeout::', 'email::', 'password::']);

$base        = rtrim((string) ($opts['base'] ?? getenv('LOAD_BASE') ?: 'http://localhost:8000'), '/');
$duration    = max(1, min(3600, (int) ($opts['duration'] ?? 60)));
$concurrency = max(1, min(200, (int) ($opts['concurrency'] ?? 20)));
$timeout     = max(1, min(60, (int) ($opts['timeout'] ?? 15)));

/* Traffic mix, roughly matching a real visit: menu browsing dominates. */
$endpoints = [
    ['path' => '/menu-items',   'weight' => 35],
    ['path' => '/categories',   'weight' => 15],
    ['path' => '/loyalty/rules', 'weight' => 15],
    ['path' => '/site-content', 'weight' => 10],
    ['path' => '/orders/track?phone=03000000000', 'weight' => 10],
];

$token = null;
if (!empty($opts['email']) && !empty($opts['password'])) {
    $token = login($base, (string) $opts['email'], (string) $opts['password'], $timeout);
    if ($token === null) {
        fwrite(STDERR, "! Admin login failed — running public endpoints only.\n");
    } else {
        $endpoints[] = ['path' => '/admin/summary',      'weight' => 8];
        $endpoints[] = ['path' => '/admin/orders-today', 'weight' => 7];
    }
}

echo "Load test against $base\n";
printf("Concurrency %d · duration %d s · timeout %d s · endpoints %d%s\n",
    $concurrency, $duration, $timeout, count($endpoints), $token ? ' (admin session)' : '');
echo "Warming up connections...\n";

$mh = curl_multi_init();
$slots = [];
$handleToSlot = [];

for ($i = 0; $i < $concurrency; $i++) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => $timeout,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_ENCODING       => '',   // accept gzip, like a browser
        CURLOPT_HEADER         => false,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $slots[$i] = ['ch' => $ch, 'busy' => false, 'start' => 0.0, 'path' => ''];
    $handleToSlot[spl_object_id($ch)] = $i;
}

$headers = ['Accept: application/json'];
if ($token !== null) $headers[] = 'Authorization: Bearer ' . $token;

$startAll   = microtime(true);
$deadline   = $startAll + $duration;
$nextStatus = $startAll + 5;

$inFlight  = 0;
$completed = 0;
$errors    = 0;
$latencies = [];
$perPath   = [];
$statuses  = [];

while (true) {
    // Fill every idle slot until the clock runs out.
    if (microtime(true) < $deadline) {
        foreach ($slots as $i => $slot) {
            if ($slot['busy'] || microtime(true) >= $deadline) continue;

            $path = pick_endpoint($endpoints);
            $ch = $slot['ch'];
            curl_setopt_array($ch, [
                CURLOPT_URL        => $base . $path,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_HTTPGET    => true,
            ]);
            curl_multi_add_handle($mh, $ch);

            $slots[$i]['busy']  = true;
            $slots[$i]['start'] = microtime(true);
            $slots[$i]['path']  = $path;
            $inFlight++;
        }
    }

    if ($inFlight === 0 && microtime(true) >= $deadline) break;

    $mrc = curl_multi_exec($mh, $running);
    if ($running > 0 && $mrc === CURLM_OK) {
        if (curl_multi_select($mh, 0.2) === -1) usleep(1000);
    }

    while ($info = curl_multi_info_read($mh)) {
        $ch  = $info['handle'];
        $idx = $handleToSlot[spl_object_id($ch)];
        $slot = $slots[$idx];

        $http = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $lat  = microtime(true) - $slot['start'];
        $ok   = $info['result'] === CURLE_OK && $http >= 200 && $http < 400;

        if (!isset($perPath[$slot['path']])) {
            $perPath[$slot['path']] = ['n' => 0, 'err' => 0, 'lat' => []];
        }
        $perPath[$slot['path']]['n']++;
        $perPath[$slot['path']]['lat'][] = $lat;
        if (!$ok) $perPath[$slot['path']]['err']++;

        $latencies[] = $lat;
        $statuses[$http] = ($statuses[$http] ?? 0) + 1;
        $completed++;
        if (!$ok) $errors++;

        curl_multi_remove_handle($mh, $ch);
        $slots[$idx]['busy'] = false;
        $inFlight--;
    }

    $now = microtime(true);
    if ($now >= $nextStatus && $now < $deadline) {
        $elapsed = max(0.001, $now - $startAll);
        fprintf(STDERR, "  %4.0fs  %6d done  %7.1f req/s  %d errors\n",
            $elapsed, $completed, $completed / $elapsed, $errors);
        $nextStatus += 5;
    }
}

$elapsed = max(0.001, microtime(true) - $startAll);

foreach ($slots as $slot) {
    curl_multi_remove_handle($mh, $slot['ch']);
    curl_close($slot['ch']);
}
curl_multi_close($mh);

sort($latencies);

echo "\n──────────────\n";
printf("Target         %s\n", $base);
printf("Concurrency    %d\n", $concurrency);
printf("Wall time      %.1f s\n", $elapsed);
printf("Requests       %d (%d errors)\n", $completed, $errors);
printf("Throughput     %.1f req/s  →  %s req/min\n", $completed / $elapsed, number_format($completed / $elapsed * 60, 0));
printf("Latency        avg %.1f ms · p50 %.1f · p90 %.1f · p95 %.1f · p99 %.1f · max %.1f ms\n",
    avg($latencies) * 1000,
    percentile($latencies, 50) * 1000,
    percentile($latencies, 90) * 1000,
    percentile($latencies, 95) * 1000,
    percentile($latencies, 99) * 1000,
    ($latencies ? end($latencies) : 0) * 1000);

echo "\nStatus codes\n";
ksort($statuses);
foreach ($statuses as $code => $count) {
    printf("  %-4s %6d\n", $code === 0 ? 'ERR' : $code, $count);
}

echo "\nPer endpoint                            n      err   avg ms   p95 ms\n";
uksort($perPath, fn ($a, $b) => $perPath[$b]['n'] <=> $perPath[$a]['n']);
foreach ($perPath as $path => $stats) {
    printf("  %-36s %6d  %4d  %7.1f  %7.1f\n",
        $path, $stats['n'], $stats['err'],
        avg($stats['lat']) * 1000,
        percentile($stats['lat'], 95) * 1000);
}

echo "\nNote: this is throughput at {$concurrency} concurrent requests. Raise --concurrency\n";
echo "in steps (10 → 25 → 50 → 100); the point where p95 doubles or errors appear is\n";
echo "the practical ceiling of the hosting plan, not of the application.\n";

if ($errors > 0) {
    fwrite(STDERR, "\n! $errors failed requests — check the status codes above before trusting the numbers.\n");
}

/* ───────────────────────── helpers ───────────────────────── */

function pick_endpoint(array $endpoints): string
{
    $total = array_sum(array_column($endpoints, 'weight'));
    $roll = random_int(1, $total);
    foreach ($endpoints as $endpoint) {
        $roll -= $endpoint['weight'];
        if ($roll <= 0) return $endpoint['path'];
    }
    return $endpoints[0]['path'];
}

function avg(array $values): float
{
    return $values ? array_sum($values) / count($values) : 0.0;
}

function percentile(array $values, float $p): float
{
    $n = count($values);
    if ($n === 0) return 0.0;
    sort($values);
    $idx = (int) ceil($p / 100 * $n) - 1;
    return $values[max(0, min($idx, $n - 1))];
}

function login(string $base, string $email, string $password, int $timeout): ?string
{
    $ch = curl_init($base . '/auth/login');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode(['email' => $email, 'password' => $password]),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_CONNECTTIMEOUT => $timeout,
        CURLOPT_TIMEOUT        => $timeout,
    ]);
    $raw = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($status !== 200) return null;
    $json = json_decode((string) $raw, true);
    return $json['data']['token'] ?? null;
}
