<?php
/**
 * Tarmez — direct coupon model regression suite
 *
 * Runs against a LIVE backend (default http://localhost:8000) and the
 * same MySQL database, so every assertion is a real HTTP round trip.
 *
 *   C:\xampp\php\php.exe backend/tests/test_coupons.php
 *
 * Optional: API_BASE=http://localhost:8001
 *
 * Model under test:
 *   - every qualifying invoice PROMISES ONE coupon worth coupon_percent of
 *     the bill (after the coupons used on it, before VAT); the amount is
 *     frozen on the order and the coupon is issued only when management
 *     confirms the order;
 *   - the UNIQUE issued_for_order_id guarantees one coupon per invoice;
 *   - a new order only RESERVES its coupons; they are consumed when
 *     management confirms the order and released if it is cancelled;
 *   - a coupon can be spent once and never twice;
 *   - cancelling an order restores the coupon it used and revokes the one
 *     it earned (if still unused).
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

$BASE = rtrim(getenv('API_BASE') ?: 'http://localhost:8000', '/');
$pdo  = get_db_connection();

$PASS = 0;
$FAIL = 0;
$PHONE = '03211234567';
$ITEM_ID = 1;            // Charred Corn & Burrata — SAR 950.00
$ITEM_PRICE = 950.00;

/* ───────────────────────── harness ───────────────────────── */

function req(string $method, string $path, $body = null, ?string $token = null): array
{
    global $BASE;
    $ch = curl_init($BASE . $path);
    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    if ($token) $headers[] = 'Authorization: Bearer ' . $token;
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 30,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
    }
    $raw = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [$status, json_decode((string) $raw, true), $raw];
}

function ok(string $label, bool $cond, string $detail = ''): void
{
    global $PASS, $FAIL;
    if ($cond) {
        $PASS++;
        echo "  [PASS] $label\n";
    } else {
        $FAIL++;
        echo "  [FAIL] $label" . ($detail !== '' ? "  → $detail" : '') . "\n";
    }
}

function section(string $title): void
{
    echo "\n== $title ==\n";
}

function login(string $email, string $password = 'Password123!'): ?string
{
    [$status, $json] = req('POST', '/auth/login', ['email' => $email, 'password' => $password]);
    return $status === 200 ? ($json['data']['token'] ?? null) : null;
}

function settings(PDO $pdo): array
{
    return $pdo->query('SELECT * FROM loyalty_settings WHERE id = 1')->fetch();
}

function coupon_row(PDO $pdo, string $code): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM coupons WHERE code = :c');
    $stmt->execute([':c' => $code]);
    return $stmt->fetch() ?: null;
}

/** The coupon an invoice earned (NULL until management confirms it). */
function earned_coupon_row(PDO $pdo, int $orderId): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM coupons WHERE issued_for_order_id = :id LIMIT 1');
    $stmt->execute([':id' => $orderId]);
    return $stmt->fetch() ?: null;
}

function order_payload(int $qty = 1, array $extra = []): array
{
    global $PHONE, $ITEM_ID;
    return array_merge([
        'customer_name' => 'Ayesha Khan',
        'phone'         => $PHONE,
        'order_type'    => 'pickup',
        'items'         => [['menu_item_id' => $ITEM_ID, 'quantity' => $qty]],
    ], $extra);
}

/** Admin-created coupon owned by the test phone. */
function make_coupon(string $token, string $code, float $value, string $type = 'fixed'): ?string
{
    global $PHONE;
    [$st, $json] = req('POST', '/admin/coupons', [
        'code'          => $code,
        'title'         => 'Automated test coupon',
        'value'         => $value,
        'discount_type' => $type,
        'phone'         => $PHONE,
        'is_active'     => true,
    ], $token);
    return $st === 201 ? ($json['data']['code'] ?? $code) : null;
}

/* ───────────────────────── setup ───────────────────────── */

echo "Tarmez — direct coupon model test suite\nAPI: $BASE\n";

[$healthStatus, $rules] = req('GET', '/loyalty/rules');
if ($healthStatus !== 200) {
    fwrite(STDERR, "Backend is not answering on $BASE — start it first.\n");
    exit(2);
}
ok('GET /loyalty/rules exposes the simple rules', isset(
    $rules['data']['coupon_percent'],
    $rules['data']['min_invoice'],
    $rules['data']['max_per_order'],
    $rules['data']['vat_rate']
));

$adminToken    = login('admin@savoria.example');
$staffToken    = login('staff@savoria.example');
$customerToken = login('ayesha@savoria.example');

ok('admin can log in', $adminToken !== null);
ok('staff can log in', $staffToken !== null);
ok('customer can log in', $customerToken !== null);

if (!$adminToken || !$staffToken || !$customerToken) {
    fwrite(STDERR, "Cannot continue without tokens.\n");
    exit(2);
}

$original = settings($pdo);
$createdOrders = [];
$createdCoupons = [];
$run = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));

// Deterministic rules for the suite: 10% back, no minimum, VAT 15%.
[$st] = req('PUT', '/admin/loyalty/settings', [
    'enabled'               => true,
    'coupon_percent'        => 10,
    'earn_min_order_amount' => 0,
    'max_coupons_per_order' => 0,
    'vat_rate'              => 15,
], $adminToken);
ok('admin can save the coupon rules → 200', $st === 200, "status $st");

/* ───────────────── 1. one coupon per invoice ───────────────── */

section('1. Every qualifying invoice earns exactly one coupon — issued on confirmation');

[$st, $json] = req('POST', '/orders', order_payload(), $customerToken);
$order1 = $json['data']['id'] ?? null;
if ($order1) $createdOrders[] = $order1;
$preview1 = $json['data']['earned_coupon_preview'] ?? null;

ok('order accepted → 201', $st === 201, "status $st " . ($json['message'] ?? ''));
ok('checkout only promises the coupon', is_array($preview1) && abs((float) ($preview1['value'] ?? 0) - 95.0) < 0.001,
    'got ' . ($preview1['value'] ?? '?'));
ok('the promise is marked pending confirmation', ($preview1['status'] ?? '') === 'pending_confirmation');
ok('the percentage is frozen with the promise', abs((float) ($preview1['percent'] ?? 0) - 10.0) < 0.001,
    'got ' . ($preview1['percent'] ?? '?'));
ok('no coupon row exists before confirmation', earned_coupon_row($pdo, (int) $order1) === null);

// A rule change while the order waits must not alter what was promised.
req('PUT', '/admin/loyalty/settings', [
    'enabled'               => true,
    'coupon_percent'        => 50,
    'earn_min_order_amount' => 0,
    'max_coupons_per_order' => 0,
    'vat_rate'              => 15,
], $adminToken);

[$st] = req('PATCH', '/orders/' . $order1, ['status' => 'confirmed'], $staffToken);
ok('staff confirms the order → 200', $st === 200, "status $st");

req('PUT', '/admin/loyalty/settings', [
    'enabled'               => true,
    'coupon_percent'        => 10,
    'earn_min_order_amount' => 0,
    'max_coupons_per_order' => 0,
    'vat_rate'              => 15,
], $adminToken);

$earnedRow1 = earned_coupon_row($pdo, (int) $order1);
$earned1 = $earnedRow1 ? [
    'code'               => $earnedRow1['code'],
    'value'              => (float) $earnedRow1['value'],
    'status'             => $earnedRow1['status'],
    'source'             => $earnedRow1['source'],
    'issued_for_order_id' => (int) $earnedRow1['issued_for_order_id'],
] : null;
if ($earned1) $createdCoupons[] = $earned1['code'];

ok('confirmation issues exactly one coupon', $earnedRow1 !== null);
ok('coupon keeps the promised 10%, not the new 50%', abs((float) ($earned1['value'] ?? 0) - 95.0) < 0.001,
    'got ' . ($earned1['value'] ?? '?'));
ok('coupon starts available', ($earned1['status'] ?? '') === 'available');
ok('coupon is linked to its invoice', (int) ($earned1['issued_for_order_id'] ?? 0) === (int) $order1);
ok('coupon source is the order', ($earned1['source'] ?? '') === 'order');

$earnedRows = (int) $pdo->query('SELECT COUNT(*) FROM coupons WHERE issued_for_order_id = ' . (int) $order1)->fetchColumn();
ok('the database holds exactly one coupon for this invoice', $earnedRows === 1, "found $earnedRows");

$idx = $pdo->query("SHOW INDEX FROM coupons WHERE Key_name = 'uq_coupons_issued_order'")->fetch();
ok('uq_coupons_issued_order is UNIQUE', $idx !== false && (int) $idx['Non_unique'] === 0);

/* ───────────────── 2. reserve, then spend on confirmation ───────────────── */

section('2. A coupon is reserved by the order and spent only when management confirms');

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$earned1['code']]]), $customerToken);
$order2 = $json['data']['id'] ?? null;
if ($order2) $createdOrders[] = $order2;
$preview2 = $json['data']['earned_coupon_preview'] ?? null;
ok('no coupon is issued for the pending invoice yet', earned_coupon_row($pdo, (int) $order2) === null);

ok('order with the coupon → 201', $st === 201, "status $st " . ($json['message'] ?? ''));
ok('coupon discount is the full face value', abs((float) ($json['data']['coupon_discount'] ?? -1) - 95.0) < 0.001,
    'got ' . ($json['data']['coupon_discount'] ?? '?'));
ok('total = (950 − 95) + 15% VAT', abs((float) ($json['data']['total_amount'] ?? 0) - 983.25) < 0.001,
    'got ' . ($json['data']['total_amount'] ?? '?'));

$pendingRow = coupon_row($pdo, $earned1['code']);
ok('the coupon is only reserved while the order is pending', ($pendingRow['status'] ?? '') === 'reserved');
ok('the reservation points at the pending order', (int) ($pendingRow['order_id'] ?? 0) === (int) $order2);
ok('no use has been counted yet', (int) ($pendingRow['used_count'] ?? -1) === 0);

[$st] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$earned1['code']]]), $customerToken);
ok('a reserved coupon cannot be spent on another order → 422', $st === 422, "status $st");

[$st] = req('PATCH', '/orders/' . $order2, ['status' => 'confirmed'], $staffToken);
ok('staff confirms the order → 200', $st === 200, "status $st");

$confirmedRow = coupon_row($pdo, $earned1['code']);
ok('confirmation really spends the coupon', ($confirmedRow['status'] ?? '') === 'used');
ok('confirmation counts exactly one use', (int) ($confirmedRow['used_count'] ?? 0) === 1);
ok('confirmation records when it was used', !empty($confirmedRow['used_at']));

$earnedRow2 = earned_coupon_row($pdo, (int) $order2);
$earned2 = $earnedRow2 ? ['code' => $earnedRow2['code'], 'value' => (float) $earnedRow2['value']] : null;
if ($earned2) $createdCoupons[] = $earned2['code'];

ok('the discounted invoice promised its own 10% coupon', abs((float) ($preview2['value'] ?? 0) - 85.5) < 0.001,
    'got ' . ($preview2['value'] ?? '?'));
ok('confirming the second order issues that coupon', $earned2 !== null);
ok('the issued value matches the promise', abs((float) ($earned2['value'] ?? 0) - 85.5) < 0.001,
    'got ' . ($earned2['value'] ?? '?'));
ok('the new coupon is a different code', ($earned2['code'] ?? '') !== $earned1['code']);
ok('one coupon for the second invoice too',
    (int) $pdo->query('SELECT COUNT(*) FROM coupons WHERE issued_for_order_id = ' . (int) $order2)->fetchColumn() === 1);

/* ───────────────── 3. no double use ───────────────── */

section('3. The same coupon can never be used twice');

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$earned1['code']]]), $customerToken);
if (isset($json['data']['id'])) $createdOrders[] = $json['data']['id'];
ok('reusing a spent coupon → 422', $st === 422, "status $st");
ok('the rejection names the coupon', stripos((string) ($json['message'] ?? ''), $earned1['code']) !== false,
    (string) ($json['message'] ?? ''));
ok('the rejection explains it is not available', stripos((string) ($json['message'] ?? ''), 'not available') !== false);

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$earned2['code'], $earned2['code']]]), $customerToken);
$order3 = $json['data']['id'] ?? null;
if ($order3) $createdOrders[] = $order3;
ok('sending the same code twice applies it once', $st === 201
    && abs((float) ($json['data']['coupon_discount'] ?? 0) - 85.5) < 0.001,
    "status $st, discount " . ($json['data']['coupon_discount'] ?? '?'));

/* ───────────────── 4. coupons cannot exceed the bill ───────────────── */

section('4. A coupon stack worth more than the bill is rejected');

$bigCodes = [];
for ($i = 1; $i <= 3; $i++) {
    $code = "TST-$run-BIG$i";
    if (make_coupon($adminToken, $code, 500.0)) {
        $bigCodes[] = $code;
        $createdCoupons[] = $code;
    }
}
ok('three 500 SAR coupons created', count($bigCodes) === 3);

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => $bigCodes]), $customerToken);
ok('a 1500 SAR stack on a 950 bill → 422', $st === 422, "status $st");
ok('the message explains the bill limit', stripos((string) ($json['message'] ?? ''), 'bill') !== false,
    (string) ($json['message'] ?? ''));
ok('all oversized coupons stay available', count(array_filter(
    $bigCodes,
    fn ($c) => (coupon_row($pdo, $c)['status'] ?? '') === 'available'
)) === 3);

/* ───────────────── 5. per-order cap ───────────────── */

section('5. Per-order coupon cap');

$capCodes = [];
for ($i = 1; $i <= 3; $i++) {
    $code = "TST-$run-CAP$i";
    if (make_coupon($adminToken, $code, 1.0)) {
        $capCodes[] = $code;
        $createdCoupons[] = $code;
    }
}
[$st] = req('PUT', '/admin/loyalty/settings', [
    'enabled'               => true,
    'coupon_percent'        => 10,
    'earn_min_order_amount' => 0,
    'max_coupons_per_order' => 2,
    'vat_rate'              => 15,
], $adminToken);
ok('cap saved as 2', $st === 200);

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => $capCodes]), $customerToken);
ok('3 coupons with a cap of 2 → 422', $st === 422, "status $st");
ok('the message names the cap', stripos((string) ($json['message'] ?? ''), 'at most 2') !== false,
    (string) ($json['message'] ?? ''));

req('PUT', '/admin/loyalty/settings', [
    'enabled'               => true,
    'coupon_percent'        => 10,
    'earn_min_order_amount' => 0,
    'max_coupons_per_order' => 0,
    'vat_rate'              => 15,
], $adminToken);
ok('cap restored to no limit', (int) settings($pdo)['max_coupons_per_order'] === 0);

/* ───────────────── 6. server owns the amounts ───────────────── */

section('6. Client-supplied amounts are ignored');

$clientCode = "TST-$run-CLIENT";
if (make_coupon($adminToken, $clientCode, 40.0)) $createdCoupons[] = $clientCode;

[$st, $json] = req('POST', '/orders', order_payload(1, [
    'coupon_codes'    => [$clientCode],
    'coupon_discount' => 9999,
    'total_amount'    => 1,
]), $customerToken);
$order4 = $json['data']['id'] ?? null;
if ($order4) $createdOrders[] = $order4;
ok('order accepted → 201', $st === 201, "status $st " . ($json['message'] ?? ''));
ok('no earned coupon is issued while the order is pending', earned_coupon_row($pdo, (int) $order4) === null);
ok('server applied the real 40 SAR value', abs((float) ($json['data']['coupon_discount'] ?? 0) - 40.0) < 0.001,
    'got ' . ($json['data']['coupon_discount'] ?? '?'));
ok('server recomputed the total itself', abs((float) ($json['data']['total_amount'] ?? 0) - 1046.5) < 0.001,
    'got ' . ($json['data']['total_amount'] ?? '?'));

/* ───────────────── 7. cancellation reverses both sides ───────────────── */

section('7. Cancelling an order restores the coupon it used and revokes the one it earned');

$cancelCode = "TST-$run-CANCEL";
if (make_coupon($adminToken, $cancelCode, 40.0)) $createdCoupons[] = $cancelCode;

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$cancelCode]]), $customerToken);
$cancelOrder = $json['data']['id'] ?? null;
if ($cancelOrder) $createdOrders[] = $cancelOrder;

ok('order placed with the coupon → 201', $st === 201, "status $st " . ($json['message'] ?? ''));
ok('the pending order only reserves the coupon', (coupon_row($pdo, $cancelCode)['status'] ?? '') === 'reserved');
ok('no earned coupon exists before confirmation', earned_coupon_row($pdo, (int) $cancelOrder) === null);

[$st] = req('PATCH', '/orders/' . $cancelOrder, ['status' => 'confirmed'], $staffToken);
ok('staff confirmed the order → 200', $st === 200, "status $st");
ok('confirmation spent the coupon', (coupon_row($pdo, $cancelCode)['status'] ?? '') === 'used');

$cancelEarnedRow = earned_coupon_row($pdo, (int) $cancelOrder);
$cancelEarned = $cancelEarnedRow['code'] ?? null;
if ($cancelEarned) $createdCoupons[] = $cancelEarned;
ok('confirmation issued the earned coupon', ($cancelEarnedRow['status'] ?? '') === 'available');

[$st] = req('PATCH', '/orders/' . $cancelOrder, ['status' => 'cancelled'], $staffToken);
ok('staff cancelled the confirmed order → 200', $st === 200, "status $st");

$usedRow = coupon_row($pdo, $cancelCode);
$earnedRow = $cancelEarned !== null ? coupon_row($pdo, $cancelEarned) : null;
ok('the spent coupon is available again', ($usedRow['status'] ?? '') === 'available');
ok('the spent coupon no longer points at an order',
    is_array($usedRow) && array_key_exists('order_id', $usedRow) && $usedRow['order_id'] === null,
    'order_id = ' . var_export(is_array($usedRow) && array_key_exists('order_id', $usedRow) ? $usedRow['order_id'] : 'no row', true));
ok('the use counter was rolled back', (int) ($usedRow['used_count'] ?? -1) === 0);
ok('the coupon earned by the cancelled order is revoked', ($earnedRow['status'] ?? '') === 'cancelled');

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$cancelCode]]), $customerToken);
if (isset($json['data']['id'])) $createdOrders[] = $json['data']['id'];
ok('the restored coupon can be used on a new order → 201', $st === 201, "status $st");

section('7b. Cancelling a still-pending order also releases the reservation');

$pendingCode = "TST-$run-PENDING";
if (make_coupon($adminToken, $pendingCode, 30.0)) $createdCoupons[] = $pendingCode;

[$st, $json] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$pendingCode]]), $customerToken);
$pendingOrder = $json['data']['id'] ?? null;
if ($pendingOrder) $createdOrders[] = $pendingOrder;
ok('order placed with the coupon → 201', $st === 201, "status $st");
ok('the coupon is reserved, never used', (coupon_row($pdo, $pendingCode)['used_count'] ?? -1) === 0);
ok('no earned coupon exists yet', earned_coupon_row($pdo, (int) $pendingOrder) === null);

[$st] = req('PATCH', '/orders/' . $pendingOrder, ['status' => 'cancelled'], $staffToken);
ok('cancelling the pending order → 200', $st === 200, "status $st");
$pendingRow = coupon_row($pdo, $pendingCode);
ok('the reservation is released untouched', ($pendingRow['status'] ?? '') === 'available'
    && (int) ($pendingRow['used_count'] ?? -1) === 0
    && array_key_exists('order_id', $pendingRow) && $pendingRow['order_id'] === null);
ok('a cancelled pending order never earns a coupon', earned_coupon_row($pdo, (int) $pendingOrder) === null);

/* ───────────────── 8. admin lifecycle ───────────────── */

section('8. Admin cancellation keeps the record');

$adminCode = "TST-$run-ADMIN";
$adminId = 0;
if (make_coupon($adminToken, $adminCode, 15.0)) {
    $createdCoupons[] = $adminCode;
    $adminId = (int) (coupon_row($pdo, $adminCode)['id'] ?? 0);
}

[$st, $json] = req('POST', "/admin/coupons/$adminId/cancel", ['reason' => 'Issued by mistake'], $adminToken);
ok('admin cancels an available coupon → 200', $st === 200, "status $st");
ok('status is cancelled', ($json['data']['status'] ?? '') === 'cancelled');
ok('the reason is stored', ($json['data']['cancel_reason'] ?? '') === 'Issued by mistake');

[$st] = req('POST', '/orders', order_payload(1, ['coupon_codes' => [$adminCode]]), $customerToken);
ok('a cancelled coupon cannot be used → 422', $st === 422, "status $st");

[$st, $json] = req('GET', "/admin/coupons/$adminId", null, $adminToken);
ok('the lifecycle log is readable', $st === 200 && count($json['data']['events'] ?? []) >= 2);
ok('the log contains created + cancelled', count(array_filter(
    $json['data']['events'] ?? [],
    fn ($e) => in_array($e['event'], ['created', 'cancelled'], true)
)) >= 2);

[$st] = req('POST', "/admin/coupons/$adminId/cancel", ['reason' => ''], $adminToken);
ok('cancelling without a reason → 422', $st === 422, "status $st");

/* ───────────────── 9. rules validation ───────────────── */

section('9. Coupon rules validation');

[$st] = req('PUT', '/admin/loyalty/settings', [
    'enabled' => true, 'coupon_percent' => 150, 'earn_min_order_amount' => 0,
    'max_coupons_per_order' => 0, 'vat_rate' => 15,
], $adminToken);
ok('percentage above 100 → 422', $st === 422, "status $st");

[$st] = req('PUT', '/admin/loyalty/settings', [
    'enabled' => true, 'coupon_percent' => 10, 'earn_min_order_amount' => -1,
    'max_coupons_per_order' => 0, 'vat_rate' => 15,
], $adminToken);
ok('negative minimum invoice → 422', $st === 422, "status $st");

[$st, $json] = req('GET', '/admin/loyalty/settings', null, $adminToken);
ok('settings expose coupon_percent and vat_rate', $st === 200
    && isset($json['data']['coupon_percent'], $json['data']['vat_rate'], $json['data']['max_coupons_per_order']));

/* ───────────────── 10. permissions ───────────────── */

section('10. Permissions');

[$st] = req('GET', '/me/coupons');
ok('coupons without a token → 401', $st === 401, "status $st");

[$st] = req('POST', '/admin/coupons/1/cancel', ['reason' => 'x'], $customerToken);
ok('customer cannot cancel a coupon → 403', $st === 403, "status $st");

[$st] = req('POST', '/admin/coupons/1/cancel', ['reason' => 'x'], $staffToken);
ok('staff cannot cancel a coupon → 403', $st === 403, "status $st");

[$st, $json] = req('GET', '/admin/coupons?search=' . urlencode($PHONE), null, $staffToken);
ok('staff can read the coupon list → 200', $st === 200);

/* ───────────────── cleanup ───────────────── */

section('Cleanup');

// Restore the rules exactly as the suite found them.
[$st] = req('PUT', '/admin/loyalty/settings', [
    'enabled'               => (bool) $original['enabled'],
    'coupon_percent'        => (float) $original['coupon_percent'],
    'earn_min_order_amount' => (float) $original['earn_min_order_amount'],
    'max_coupons_per_order' => (int) $original['max_coupons_per_order'],
    'vat_rate'              => (float) $original['vat_rate'],
], $adminToken);
ok('coupon rules restored', $st === 200 && (float) settings($pdo)['coupon_percent'] === (float) $original['coupon_percent']);

// Remove the coupons this suite created (events first, then the rows).
$codes = array_values(array_unique(array_filter($createdCoupons)));
if ($codes) {
    $in = implode(',', array_map(fn ($c) => $pdo->quote($c), $codes));
    $pdo->exec("DELETE FROM coupon_events WHERE coupon_id IN (SELECT id FROM coupons WHERE code IN ($in))");
    $pdo->exec('DELETE FROM order_coupons WHERE coupon_id IN (SELECT id FROM coupons WHERE code IN (' . $in . '))');
    $pdo->exec("DELETE FROM coupons WHERE code IN ($in)");
}
// Any coupon still pointing at a test order goes with it.
$orders = array_values(array_filter(array_unique($createdOrders)));
if ($orders) {
    $in = implode(',', array_map('intval', $orders));
    $pdo->exec("DELETE FROM coupon_events WHERE coupon_id IN (SELECT id FROM coupons WHERE issued_for_order_id IN ($in))");
    $pdo->exec("DELETE FROM coupons WHERE issued_for_order_id IN ($in)");
    $pdo->exec("DELETE FROM order_coupons WHERE order_id IN ($in)");
    $pdo->exec("DELETE FROM order_items WHERE order_id IN ($in)");
    $pdo->exec("DELETE FROM orders WHERE id IN ($in)");
}
ok('test coupons removed', !$codes || (int) $pdo->query('SELECT COUNT(*) FROM coupons WHERE code IN (' . implode(',', array_map(fn ($c) => $pdo->quote($c), $codes)) . ')')->fetchColumn() === 0);

echo "\nOrders created by this run: " . (count($createdOrders) ? implode(', ', $createdOrders) : 'none') . "\n";
echo "Coupons touched: " . count($createdCoupons) . "\n";
echo "\n──────────────\n";
echo "PASS: $PASS   FAIL: $FAIL\n";
exit($FAIL === 0 ? 0 : 1);
