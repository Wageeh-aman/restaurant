<?php
/**
 * Tarmez — table & QR-code end-to-end suite
 *
 * Runs against a LIVE backend and the same MySQL database, so every
 * assertion is a real HTTP round trip. It also reads the database
 * directly to prove what the order actually stored.
 *
 *   C:\xampp\php\php.exe backend/tests/test_tables.php
 *   Optional: API_BASE=http://127.0.0.1:8003/api
 *
 * What is proven here:
 *   - a table's QR token is generated, unique and never exposed in a
 *     public response;
 *   - two tables can never share a number inside one restaurant;
 *   - a scanned token resolves to the real table (id + number);
 *   - an order carrying a token is bound to that table's id and number,
 *     with order_type forced to dine_in by the SERVER — a table number
 *     forged in the request body is ignored;
 *   - unknown / disabled codes are refused;
 *   - a table that has orders cannot be deleted (its history is kept).
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

$BASE = rtrim(getenv('API_BASE') ?: 'http://localhost:8000', '/');
$pdo  = get_db_connection();

$PASS = 0;
$FAIL = 0;
$PHONE = '03001234567';
$ITEM_ID = 1;
$ADMIN_EMAIL = 'admin@savoria.example';

$createdOrders = [];
$createdTableId = null;
$tableNumber = null;

/* ───────────────────────── harness ───────────────────────── */

function req(string $method, string $path, $body = null, ?string $token = null): array
{
    global $BASE;
    $ch = curl_init($BASE . $path);
    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    if ($token) $headers[] = 'Authorization: Bearer ' . $token;
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 30,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
    }
    $raw = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [$status, json_decode((string) $raw, true), $raw];
}

function ok(string $label, bool $cond, string $detail = ''): void
{
    global $PASS, $FAIL;
    if ($cond) {
        $PASS++;
        echo "  [PASS] $label\n";
    } else {
        $FAIL++;
        echo "  [FAIL] $label" . ($detail !== '' ? "  → $detail" : '') . "\n";
    }
}

function section(string $title): void
{
    echo "\n== $title ==\n";
}

function login(string $email, string $password = 'Password123!'): ?string
{
    [$status, $json] = req('POST', '/auth/login', ['email' => $email, 'password' => $password]);
    return $status === 200 ? ($json['data']['token'] ?? null) : null;
}

/* ───────────────────────── setup ───────────────────────── */

$adminToken = login($ADMIN_EMAIL);
if (!$adminToken) {
    fwrite(STDERR, "Could not log in as $ADMIN_EMAIL — is the backend running at $BASE?\n");
    exit(1);
}

/* Pick a table number nothing else is using yet. */
$taken = $pdo->query('SELECT table_number FROM restaurant_tables')->fetchAll(PDO::FETCH_COLUMN);
$taken = array_map('intval', $taken);
$tableNumber = null;
for ($n = 240; $n >= 100; $n--) {
    if (!in_array($n, $taken, true)) { $tableNumber = $n; break; }
}
if ($tableNumber === null) {
    fwrite(STDERR, "No free table number available for the test.\n");
    exit(1);
}

echo "Running table & QR suite against $BASE  (test table #$tableNumber)\n";

/* ───────────────────────── tests ───────────────────────── */

section('1. A scanned code that is not a real code is refused');
[$st, , ] = req('GET', '/tables/resolve?token=not-a-token');
ok('malformed token → 404', $st === 404, "got $st");

[$st, , ] = req('GET', '/tables/resolve?token=' . str_repeat('a', 32));
ok('unknown but well-formed token → 404', $st === 404, "got $st");

section('2. Creating a table mints its own QR token');
[$st, $json, $raw] = req('POST', '/admin/tables', [
    'table_number' => $tableNumber,
    'label'        => 'Test Terrace',
    'label_ar'     => 'تراس الاختبار',
    'seats'        => 6,
], $adminToken);
ok('create → 201', $st === 201, "got $st: $raw");
$createdTableId = (int) ($json['data']['id'] ?? 0);
$token = (string) ($json['data']['qr_token'] ?? '');
ok('the table got an id', $createdTableId > 0);
ok('the QR token is 32 hex chars', (bool) preg_match('/^[a-f0-9]{32}$/', $token), "token=$token");

section('3. Two tables cannot share a number');
[$st, , ] = req('POST', '/admin/tables', ['table_number' => $tableNumber], $adminToken);
ok('duplicate number → 422', $st === 422, "got $st");

section('4. The public resolve hides the token and finds the table');
[$st, $json, $raw] = req('GET', '/tables/resolve?token=' . $token);
ok('resolve → 200', $st === 200, "got $st: $raw");
ok('resolve returns the right number', (int) ($json['data']['table_number'] ?? 0) === $tableNumber);
ok('resolve never leaks the token', !isset($json['data']['qr_token']));

section('5. The admin list carries the token and live status');
[$st, $json, ] = req('GET', '/admin/tables', null, $adminToken);
$listed = null;
foreach (($json['data']['tables'] ?? []) as $row) {
    if ((int) ($row['id'] ?? 0) === $createdTableId) { $listed = $row; break; }
}
ok('the new table is listed', $listed !== null);
ok('the list carries the QR token', (string) ($listed['qr_token'] ?? '') === $token);
ok('the list carries an open-order count', array_key_exists('open_orders', $listed ?? []));

section('6. An order from a QR code is bound to that table (forged number ignored)');
[$st, $json, $raw] = req('POST', '/orders', [
    'customer_name' => 'QR Guest',
    'phone'         => $PHONE,
    'order_type'    => 'dine_in',
    'table_number'  => 99,                 // a forged number the server must ignore
    'table_token'   => $token,
    'items'         => [['menu_item_id' => $ITEM_ID, 'quantity' => 1]],
]);
ok('order → 201', $st === 201, "got $st: $raw");
$orderId = (int) ($json['data']['id'] ?? 0);
if ($orderId) $createdOrders[] = $orderId;
ok('the order stored the QR table number, not the forged one', (int) ($json['data']['table_number'] ?? 0) === $tableNumber);
ok('the order stored the table id', (int) ($json['data']['table_id'] ?? 0) === $createdTableId);

$row = $pdo->prepare('SELECT order_type, table_number, table_id FROM orders WHERE id = :id');
$row->execute([':id' => $orderId]);
$dbOrder = $row->fetch() ?: [];
ok('the DB row type is dine_in', ($dbOrder['order_type'] ?? '') === 'dine_in');
ok('the DB row table_number matches', (int) ($dbOrder['table_number'] ?? 0) === $tableNumber);
ok('the DB row table_id matches', (int) ($dbOrder['table_id'] ?? 0) === $createdTableId);

section('7. The server decides dine-in — a delivery body with a table code is coerced');
[$st, $json, $raw] = req('POST', '/orders', [
    'customer_name'    => 'QR Guest 2',
    'phone'            => $PHONE,
    'order_type'       => 'delivery',
    'delivery_address' => 'Somewhere far away',
    'table_token'      => $token,
    'items'            => [['menu_item_id' => $ITEM_ID, 'quantity' => 1]],
]);
ok('order → 201', $st === 201, "got $st: $raw");
$orderId2 = (int) ($json['data']['id'] ?? 0);
if ($orderId2) $createdOrders[] = $orderId2;
ok('the type became dine_in regardless of the body', ($json['data']['order_type'] ?? '') === 'dine_in');
ok('the table number is the code\'s table', (int) ($json['data']['table_number'] ?? 0) === $tableNumber);

section('8. Editing a table keeps its token (the printed code still works)');
[$st, $json, $raw] = req('PUT', '/admin/tables/' . $createdTableId, ['seats' => 8, 'label_ar' => 'تراس مطوّر'], $adminToken);
ok('update → 200', $st === 200, "got $st: $raw");
ok('the token is unchanged by an edit', (string) ($json['data']['qr_token'] ?? '') === $token);
ok('the seats were saved', (int) ($json['data']['seats'] ?? 0) === 8);

section('9. An unknown code cannot place an order');
[$st, , ] = req('POST', '/orders', [
    'customer_name' => 'Fake Guest',
    'phone'         => $PHONE,
    'order_type'    => 'dine_in',
    'table_token'   => str_repeat('b', 32),
    'items'         => [['menu_item_id' => $ITEM_ID, 'quantity' => 1]],
]);
ok('unknown token → 422', $st === 422, "got $st");

section('10. A disabled table stops working');
[$st, , ] = req('PUT', '/admin/tables/' . $createdTableId, ['status' => 'disabled'], $adminToken);
ok('disable → 200', $st === 200, "got $st");

[$st, , ] = req('GET', '/tables/resolve?token=' . $token);
ok('disabled table will not resolve → 404', $st === 404, "got $st");

[$st, , ] = req('POST', '/orders', [
    'customer_name' => 'Disabled Guest',
    'phone'         => $PHONE,
    'order_type'    => 'dine_in',
    'table_token'   => $token,
    'items'         => [['menu_item_id' => $ITEM_ID, 'quantity' => 1]],
]);
ok('disabled table refuses the order → 422', $st === 422, "got $st");

[$st, , ] = req('PUT', '/admin/tables/' . $createdTableId, ['status' => 'active'], $adminToken);
ok('re-enable → 200', $st === 200, "got $st");

section('11. A table with orders cannot be deleted (history is protected)');
[$st, , ] = req('DELETE', '/admin/tables/' . $createdTableId, null, $adminToken);
ok('delete refused → 409', $st === 409, "got $st");

section('12. A typed dine-in order still works (no QR — nothing broken)');
[$st, $json, $raw] = req('POST', '/orders', [
    'customer_name' => 'Typed Guest',
    'phone'         => $PHONE,
    'order_type'    => 'dine_in',
    'table_number'  => 5,
    'items'         => [['menu_item_id' => $ITEM_ID, 'quantity' => 1]],
]);
ok('order → 201', $st === 201, "got $st: $raw");
$orderId3 = (int) ($json['data']['id'] ?? 0);
if ($orderId3) $createdOrders[] = $orderId3;
ok('typed table number is stored', (int) ($json['data']['table_number'] ?? 0) === 5);
ok('a typed order has no table id', empty($json['data']['table_id']));

/* ───────────────────────── cleanup ───────────────────────── */

section('Cleanup');
if ($createdOrders) {
    $in = implode(',', array_map('intval', $createdOrders));
    $pdo->exec("DELETE FROM order_items WHERE order_id IN ($in)");
    $pdo->exec("DELETE FROM orders WHERE id IN ($in)");
    echo '  removed test orders: ' . implode(', ', $createdOrders) . "\n";
}
if ($createdTableId) {
    $pdo->prepare('DELETE FROM restaurant_tables WHERE id = :id')->execute([':id' => $createdTableId]);
    echo "  removed test table #$tableNumber\n";
}

echo "\n────────────────────────────\n";
echo "PASS: $PASS   FAIL: $FAIL\n";
exit($FAIL === 0 ? 0 : 1);