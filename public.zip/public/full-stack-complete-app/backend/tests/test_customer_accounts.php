<?php
/**
 * Tarmez — customer accounts, notifications & coupon ownership suite
 *
 * Runs against a LIVE backend and the same MySQL database, so every
 * assertion is a real HTTP round trip (and the database is read directly
 * where it matters).
 *
 *   C:\xampp\php\php.exe backend/tests/test_customer_accounts.php
 *
 * Optional:
 *   API_BASE=http://localhost:8000   (first server)
 *   API_BASE2=http://localhost:8001  (second server, for the true
 *                                     concurrency test on Windows where
 *                                     the built-in server is serialized)
 *
 * What is proven here:
 *   - public registration creates ONLY a customer account (a role sent in
 *     the body is ignored), refuses duplicate phone/email, stores bcrypt;
 *   - a customer can log in with a formatted phone number or email;
 *   - a QR order placed while signed in is tied to BOTH the account and
 *     the server-resolved table (a forged phone cannot change either);
 *   - /my/orders only ever returns the caller's own orders;
 *   - notifications are real, per-user, deduplicated, markable read;
 *   - a coupon created for one customer appears in their account and
 *     notification centre, and no other customer can preview or spend it;
 *   - a reserved coupon is consumed when management confirms the order,
 *     recorded against that order, and can never be used twice — not even
 *     by two simultaneous checkouts;
 *   - expiry and cross-account access are refused;
 *   - customers cannot reach management routes.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

$BASE  = rtrim(getenv('API_BASE') ?: 'http://localhost:8000', '/');
$BASE2 = rtrim(getenv('API_BASE2') ?: 'http://localhost:8001', '/');
$pdo   = get_db_connection();

$PASS = 0;
$FAIL = 0;
$ITEM_ID = 1;              // Charred Corn & Burrata — SAR 950.00
$ITEM_PRICE = 950.00;

/* ───────────────────────── harness ───────────────────────── */

function req_on(string $base, string $method, string $path, $body = null, ?string $token = null): array
{
    $ch = curl_init($base . $path);
    $headers = ['Content-Type: application/json', 'Accept: application/json'];
    if ($token) $headers[] = 'Authorization: Bearer ' . $token;
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 30,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
    }
    $raw = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [$status, json_decode((string) $raw, true), $raw];
}

function req(string $method, string $path, $body = null, ?string $token = null): array
{
    global $BASE;
    return req_on($BASE, $method, $path, $body, $token);
}

/** Fire several requests at the same time, one per base URL. */
function req_parallel(array $jobs): array
{
    $multi = curl_multi_init();
    $handles = [];
    foreach ($jobs as $i => $job) {
        $ch = curl_init($job['base'] . $job['path']);
        $headers = ['Content-Type: application/json', 'Accept: application/json'];
        if (!empty($job['token'])) $headers[] = 'Authorization: Bearer ' . $job['token'];
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $job['method'],
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 30,
        ]);
        if (array_key_exists('body', $job) && $job['body'] !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($job['body'], JSON_UNESCAPED_UNICODE));
        }
        curl_multi_add_handle($multi, $ch);
        $handles[$i] = $ch;
    }

    $running = null;
    do {
        curl_multi_exec($multi, $running);
        curl_multi_select($multi, 1.0);
    } while ($running > 0);

    $out = [];
    foreach ($handles as $i => $ch) {
        $raw = (string) curl_multi_getcontent($ch);
        $out[$i] = [(int) curl_getinfo($ch, CURLINFO_HTTP_CODE), json_decode($raw, true), $raw];
        curl_multi_remove_handle($multi, $ch);
        curl_close($ch);
    }
    curl_multi_close($multi);
    return $out;
}

function ok(string $label, bool $cond, string $detail = ''): void
{
    global $PASS, $FAIL;
    if ($cond) {
        $PASS++;
        echo "  [PASS] $label\n";
    } else {
        $FAIL++;
        echo "  [FAIL] $label" . ($detail !== '' ? "  → $detail" : '') . "\n";
    }
}

function section(string $title): void
{
    echo "\n== $title ==\n";
}

function login(string $identifier, string $password = 'Password123!'): ?string
{
    [$status, $json] = req('POST', '/auth/login', ['email' => $identifier, 'password' => $password]);
    return $status === 200 ? ($json['data']['token'] ?? null) : null;
}

function register(string $name, string $phone, string $password, ?string $email = null, array $extra = []): array
{
    $body = array_merge([
        'full_name' => $name,
        'phone'     => $phone,
        'password'  => $password,
    ], $email !== null ? ['email' => $email] : [], $extra);
    return array_merge(req('POST', '/auth/register', $body), [$body]);
}

function coupon_row(PDO $pdo, string $code): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM coupons WHERE code = :c');
    $stmt->execute([':c' => $code]);
    return $stmt->fetch() ?: null;
}

function notification_count(PDO $pdo, int $userId, ?string $eventKey = null): int
{
    $sql = 'SELECT COUNT(*) FROM notifications WHERE user_id = :u';
    $params = [':u' => $userId];
    if ($eventKey !== null) {
        $sql .= ' AND event_key = :e';
        $params[':e'] = $eventKey;
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int) $stmt->fetchColumn();
}

function notif_ids(array $payload): array
{
    return array_map(fn ($n) => (int) ($n['id'] ?? 0), $payload['data']['notifications'] ?? []);
}

function find_notification(array $payload, string $eventKey, ?int $linkId = null): ?array
{
    foreach (($payload['data']['notifications'] ?? []) as $n) {
        if (($n['event_key'] ?? '') !== $eventKey) continue;
        if ($linkId !== null && (int) ($n['link_id'] ?? 0) !== $linkId) continue;
        return $n;
    }
    return null;
}

function order_payload(string $name, string $phone, array $extra = []): array
{
    global $ITEM_ID;
    return array_merge([
        'customer_name' => $name,
        'phone'         => $phone,
        'order_type'    => 'pickup',
        'items'         => [['menu_item_id' => $ITEM_ID, 'quantity' => 1]],
    ], $extra);
}

function make_coupon(string $adminToken, string $phone, string $code, float $value, array $extra = []): array
{
    return req('POST', '/admin/coupons', array_merge([
        'code'          => $code,
        'title'         => 'Automated account test coupon',
        'value'         => $value,
        'discount_type' => 'fixed',
        'phone'         => $phone,
        'is_active'     => true,
    ], $extra), $adminToken);
}

/* ───────────────────────── setup ───────────────────────── */

echo "Tarmez — customer accounts / notifications / coupon ownership suite\n";
echo "API 1: $BASE\nAPI 2: $BASE2\n";

[$healthStatus] = req('GET', '/loyalty/rules');
if ($healthStatus !== 200) {
    fwrite(STDERR, "Backend is not answering on $BASE — start it first.\n");
    exit(2);
}

$adminToken = login('admin@savoria.example');
ok('admin can log in', $adminToken !== null);
if (!$adminToken) { fwrite(STDERR, "Cannot continue without an admin token.\n"); exit(2); }

$originalSettings = $pdo->query('SELECT * FROM loyalty_settings WHERE id = 1')->fetch();
req('PUT', '/admin/loyalty/settings', [
    'enabled'               => true,
    'coupon_percent'        => 10,
    'earn_min_order_amount' => 0,
    'max_coupons_per_order' => 0,
    'vat_rate'              => 15,
], $adminToken);

$run = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
$phoneA = '05' . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
$phoneB = '05' . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
while ($phoneB === $phoneA) {
    $phoneB = '05' . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);
}
$emailA = 'customer.a.' . strtolower($run) . '@example.test';
$nameA  = 'Mona Test ' . $run;
$nameB  = 'Karim Test ' . $run;
$pass   = 'StrongPass1';

$createdOrders  = [];
$createdCoupons = [];
$createdUsers   = [];
$tableId        = 0;

/* ───────────────── 1. registration ───────────────── */

section('1. Public registration creates a customer — never an admin');

[$st, $json, $raw] = req('POST', '/auth/register', [
    'full_name' => $nameA,
    'phone'     => $phoneA,
    'email'     => $emailA,
    'password'  => $pass,
    'role'      => 'admin',          // must be ignored by the server
]);
$userA = (int) ($json['data']['user']['id'] ?? 0);
$tokenA = (string) ($json['data']['token'] ?? '');
if ($userA) $createdUsers[] = $userA;

ok('registration → 201', $st === 201, "status $st: $raw");
ok('a token is returned', $tokenA !== '');
ok('the role is customer, whatever the body said', ($json['data']['user']['role'] ?? '') === 'customer');
ok('the phone is stored normalized', ($json['data']['user']['phone'] ?? '') === $phoneA);

$dbUser = $pdo->prepare('SELECT role, password_hash, phone, email FROM users WHERE id = :id');
$dbUser->execute([':id' => $userA]);
$dbUserRow = $dbUser->fetch() ?: [];
ok('the DB role is customer', ($dbUserRow['role'] ?? '') === 'customer');
ok('the password is bcrypt-hashed', str_starts_with((string) ($dbUserRow['password_hash'] ?? ''), '$2y$'));
ok('the plain password is never stored', ($dbUserRow['password_hash'] ?? '') !== $pass);
ok('the hash verifies the password', password_verify($pass, (string) ($dbUserRow['password_hash'] ?? '')));

[$st, $json] = req('GET', '/auth/me', null, $tokenA);
ok('/auth/me works for the new customer', $st === 200 && ($json['data']['role'] ?? '') === 'customer');

section('2. Registration validation and duplicate prevention');

[$st, $json] = req('POST', '/auth/register', [
    'full_name' => 'Second ' . $run,
    'phone'     => substr($phoneA, 0, 4) . ' ' . substr($phoneA, 4, 3) . ' ' . substr($phoneA, 7), // same digits
    'password'  => $pass,
]);
ok('duplicate phone (different formatting) → 409', $st === 409, "status $st: " . ($json['message'] ?? ''));

[$st] = req('POST', '/auth/register', [
    'full_name' => 'Third ' . $run,
    'phone'     => '05' . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT),
    'email'     => $emailA,
    'password'  => $pass,
]);
ok('duplicate email → 409', $st === 409, "status $st");

[$st] = req('POST', '/auth/register', ['full_name' => 'X', 'phone' => $phoneA, 'password' => $pass]);
ok('too-short name → 422', $st === 422, "status $st");

[$st] = req('POST', '/auth/register', ['full_name' => 'Valid Name', 'phone' => '123', 'password' => $pass]);
ok('invalid phone → 422', $st === 422, "status $st");

[$st] = req('POST', '/auth/register', ['full_name' => 'Valid Name', 'phone' => $phoneA, 'password' => 'lowercase1']);
ok('password without uppercase → 422', $st === 422, "status $st");

[$st] = req('POST', '/auth/register', ['full_name' => 'Valid Name', 'phone' => $phoneA, 'password' => 'NoNumberHere']);
ok('password without a number → 422', $st === 422, "status $st");

[$st] = req('POST', '/auth/register', [
    'full_name' => 'Valid Name',
    'phone'     => $phoneA,
    'email'     => 'not-an-email',
    'password'  => $pass,
]);
ok('invalid email → 422', $st === 422, "status $st");

section('3. Second customer registers without an email and logs in by phone');

[$st, $json, $raw] = register($nameB, $phoneB, $pass);
$userB = (int) ($json['data']['user']['id'] ?? 0);
$tokenB = (string) ($json['data']['token'] ?? '');
if ($userB) $createdUsers[] = $userB;

ok('registration without email → 201', $st === 201, "status $st: $raw");
ok('an internal email was generated', str_ends_with((string) ($json['data']['user']['email'] ?? ''), '@customer.tarmez.local'));

$spacedPhone = substr($phoneB, 0, 3) . '-' . substr($phoneB, 3, 4) . '-' . substr($phoneB, 7);
$tokenBlogin = login($spacedPhone, $pass);
ok('login with a formatted phone number works', $tokenBlogin !== null);
ok('login with a wrong password → 401', login($phoneB, 'WrongPass1') === null);

[$st] = req('POST', '/auth/login', ['email' => $emailA, 'password' => 'WrongPass1']);
ok('email login with a wrong password → 401', $st === 401, "status $st");

/* ───────────────── 4. QR table order tied to the account ───────────────── */

section('4. A QR order placed signed-in is tied to the account and the real table');

$tableNumber = 0;
for ($i = 0; $i < 40; $i++) {
    $candidate = random_int(201, 239);
    $chk = $pdo->prepare('SELECT COUNT(*) FROM restaurant_tables WHERE table_number = :n');
    $chk->execute([':n' => $candidate]);
    if ((int) $chk->fetchColumn() === 0) { $tableNumber = $candidate; break; }
}
[$st, $json, $raw] = req('POST', '/admin/tables', [
    'table_number' => $tableNumber,
    'label'        => 'Account Test Table ' . $run,
    'seats'        => 4,
], $adminToken);
$tableId = (int) ($json['data']['id'] ?? 0);
$tableToken = (string) ($json['data']['qr_token'] ?? '');
ok('a QR table was created', $st === 201 && $tableId > 0, "status $st: $raw");

[$st, $json, $raw] = req('POST', '/orders', [
    'customer_name' => 'Someone Else',   // must be replaced by the account's name
    'phone'         => '0500000000',     // forged phone — must be ignored
    'order_type'    => 'delivery',       // a table QR forces dine_in
    'delivery_address' => 'Nowhere',
    'table_number'  => 99,               // forged number — must be ignored
    'table_token'   => $tableToken,
    'items'         => [['menu_item_id' => $ITEM_ID, 'quantity' => 1]],
], $tokenA);
$orderA1 = (int) ($json['data']['id'] ?? 0);
if ($orderA1) $createdOrders[] = $orderA1;

ok('the signed-in QR order → 201', $st === 201, "status $st: $raw");
ok('the server forced dine_in', ($json['data']['order_type'] ?? '') === 'dine_in');
ok('the table number came from the QR', (int) ($json['data']['table_number'] ?? 0) === $tableNumber);
ok('the table id is stored', (int) ($json['data']['table_id'] ?? 0) === $tableId);
ok('the order is linked to the account', (int) ($json['data']['user_id'] ?? 0) === $userA);
ok('the stored phone is the account phone', (string) ($json['data']['phone'] ?? '') === $phoneA);
ok('the stored name is the account name', (string) ($json['data']['customer_name'] ?? '') === $nameA);

$row = $pdo->prepare('SELECT user_id, phone, customer_name, table_id, table_number, order_type FROM orders WHERE id = :id');
$row->execute([':id' => $orderA1]);
$dbOrder = $row->fetch() ?: [];
ok('the DB order carries the account id', (int) ($dbOrder['user_id'] ?? 0) === $userA);
ok('the DB order carries the account phone', (string) ($dbOrder['phone'] ?? '') === $phoneA);
ok('the DB order carries the account name', (string) ($dbOrder['customer_name'] ?? '') === $nameA);
ok('the DB order carries the QR table', (int) ($dbOrder['table_id'] ?? 0) === $tableId);

section('5. /my/orders is per-account');

[$st, $json] = req('GET', '/my/orders', null, $tokenA);
$idsA = array_map(fn ($o) => (int) ($o['id'] ?? 0), $json['data'] ?? []);
ok('/my/orders as A → 200', $st === 200);
ok('A sees the QR order', in_array($orderA1, $idsA, true));
$mine = null;
foreach (($json['data'] ?? []) as $o) { if ((int) $o['id'] === $orderA1) { $mine = $o; break; } }
ok('the order exposes its table label', ($mine['table_label'] ?? null) === 'Account Test Table ' . $run);

[$st, $json] = req('GET', '/my/orders', null, $tokenB);
$idsB = array_map(fn ($o) => (int) ($o['id'] ?? 0), $json['data'] ?? []);
ok('/my/orders as B → 200', $st === 200);
ok("B never sees A's order", !in_array($orderA1, $idsB, true));

[$st] = req('GET', '/orders/' . $orderA1, null, $tokenB);
ok("B cannot open A's order by id → 403", $st === 403, "status $st");
[$st, $json] = req('GET', '/orders/' . $orderA1, null, $tokenA);
ok('A can open their own order', $st === 200 && (int) ($json['data']['id'] ?? 0) === $orderA1);

[$st] = req('GET', '/my/orders');
ok('/my/orders without a token → 401', $st === 401, "status $st");

/* ───────────────── 6. notifications ───────────────── */

section('6. Notifications are real, scoped to the account and deduplicated');

[$st, $json] = req('GET', '/me/notifications', null, $tokenA);
ok('GET /me/notifications → 200', $st === 200);
$welcome = find_notification($json, 'account.welcome');
ok('the welcome notification exists', $welcome !== null);
$createdNotif = find_notification($json, 'order.created', $orderA1);
ok('the order notification exists', $createdNotif !== null);
ok('it links to the order', ($createdNotif['link_type'] ?? '') === 'order');
ok('it starts unread', (int) ($createdNotif['is_read'] ?? 1) === 0);
$before = notification_count($pdo, $userA, 'order.created');

// Re-sending the same status must not duplicate anything.
req('PATCH', '/orders/' . $orderA1, ['status' => 'pending'], $adminToken);
$after = notification_count($pdo, $userA, 'order.created');
ok('repeating the same status adds no notification', $after === $before, "before=$before after=$after");

[$st, $json] = req('PATCH', '/orders/' . $orderA1, ['status' => 'confirmed'], $adminToken);
ok('admin confirms the order → 200', $st === 200, "status $st");
$confirmedCount = notification_count($pdo, $userA, 'order.status.confirmed');
ok('the confirmation notification was created once', $confirmedCount === 1, "count=$confirmedCount");

req('PATCH', '/orders/' . $orderA1, ['status' => 'confirmed'], $adminToken);
$confirmedAgain = notification_count($pdo, $userA, 'order.status.confirmed');
ok('confirming again creates no duplicate', $confirmedAgain === 1, "count=$confirmedAgain");

[$st, $json] = req('GET', '/me/notifications/unread-count', null, $tokenA);
$unreadA = (int) ($json['data']['unread_count'] ?? -1);
ok('unread count is positive', $unreadA > 0, "count=$unreadA");

[$st, $json] = req('POST', '/me/notifications/' . (int) ($createdNotif['id'] ?? 0) . '/read', null, $tokenA);
$unreadAfterOne = (int) ($json['data']['unread_count'] ?? -1);
ok('marking one read works', $st === 200 && $unreadAfterOne === $unreadA - 1, "status $st count=$unreadAfterOne");

[$st] = req('POST', '/me/notifications/' . (int) ($createdNotif['id'] ?? 0) . '/read', null, $tokenB);
ok("another customer cannot mark A's notification read → 404", $st === 404, "status $st");

[$st, $json] = req('GET', '/me/notifications', null, $tokenB);
$idsNotifB = notif_ids($json);
ok("B's notification list does not contain A's rows", !in_array((int) ($createdNotif['id'] ?? 0), $idsNotifB, true));
ok('B has their own welcome notification', find_notification($json, 'account.welcome') !== null);

[$st, $json] = req('POST', '/me/notifications/read-all', null, $tokenA);
ok('mark all read → 200 and zero unread', $st === 200 && (int) ($json['data']['unread_count'] ?? -1) === 0);
[$st, $json] = req('GET', '/me/notifications/unread-count', null, $tokenA);
ok('the unread counter stays at zero', (int) ($json['data']['unread_count'] ?? -1) === 0);

[$st] = req('GET', '/me/notifications');
ok('notifications without a token → 401', $st === 401, "status $st");

/* ───────────────── 7. coupon ownership ───────────────── */

section('7. A coupon is owned by one customer — code alone is not enough');

$codeA1 = 'TACC' . $run . 'A';
[$st, $json, $raw] = make_coupon($adminToken, $phoneA, $codeA1, 50.0);
$couponA1 = (int) ($json['data']['id'] ?? 0);
if ($couponA1) $createdCoupons[] = $couponA1;
ok('admin creates a coupon for A → 201', $st === 201, "status $st: $raw");
$linked = $pdo->prepare('SELECT user_id FROM coupons WHERE id = :id');
$linked->execute([':id' => $couponA1]);
ok('the coupon is linked to the owner login', (int) $linked->fetchColumn() === $userA);

[$st, $json] = req('GET', '/me/notifications', null, $tokenA);
$couponNotif = find_notification($json, 'coupon.created', $couponA1);
ok('the coupon triggers a real notification', $couponNotif !== null);
ok('the notification links to the coupon', ($couponNotif['link_type'] ?? '') === 'coupon');

[$st, $json] = req('GET', '/me/coupons', null, $tokenA);
$codesA = array_map(fn ($c) => (string) ($c['code'] ?? ''), $json['data']['coupons'] ?? []);
ok('the coupon appears in My Coupons', in_array($codeA1, $codesA, true));
ok('it is available', (int) ($json['data']['available_count'] ?? 0) >= 1);

[$st, $json] = req('POST', '/coupons/validate', ['code' => $codeA1, 'subtotal' => $ITEM_PRICE], $tokenA);
ok('the owner can preview it', $st === 200 && ($json['data']['valid'] ?? false) === true, "status $st: " . ($json['message'] ?? ''));

[$st, $json] = req('POST', '/coupons/validate', [
    'code' => $codeA1,
    'phone' => $phoneA,   // B tries to claim A's phone
    'subtotal' => $ITEM_PRICE,
], $tokenB);
ok("another customer cannot preview it → 422", $st === 422, "status $st");

[$st, $json] = req('POST', '/orders', order_payload($nameB, $phoneA, [
    'coupon_codes' => [$codeA1],
]), $tokenB);
ok("B cannot spend it, even by sending A's phone → 422", $st === 422, "status $st: " . ($json['message'] ?? ''));

[$st, $json, $raw] = req('POST', '/orders', order_payload($nameA, $phoneA, [
    'coupon_codes' => [$codeA1],
]), $tokenA);
$orderA2 = (int) ($json['data']['id'] ?? 0);
if ($orderA2) $createdOrders[] = $orderA2;
ok('the owner can place the order with it → 201', $st === 201, "status $st: $raw");

$row = coupon_row($pdo, $codeA1);
ok('the coupon is reserved, not yet used', ($row['status'] ?? '') === 'reserved');
ok('it is reserved by that order', (int) ($row['order_id'] ?? 0) === $orderA2);

[$st, $json] = req('POST', '/orders', order_payload($nameA, $phoneA, [
    'coupon_codes' => [$codeA1],
]), $tokenA);
ok('the same coupon cannot be spent twice → 422', $st === 422, "status $st");

/* ───────────────── 8. true concurrent use ───────────────── */

section('8. Two simultaneous checkouts cannot both spend one coupon');

$codeA2 = 'TACC' . $run . 'B';
[$st, $json] = make_coupon($adminToken, $phoneA, $codeA2, 25.0);
$couponA2 = (int) ($json['data']['id'] ?? 0);
if ($couponA2) $createdCoupons[] = $couponA2;
ok('a second coupon exists', $st === 201);

$parallel = req_parallel([
    ['base' => $BASE,  'method' => 'POST', 'path' => '/orders', 'token' => $tokenA,
     'body' => order_payload($nameA, $phoneA, ['coupon_codes' => [$codeA2]])],
    ['base' => $BASE2, 'method' => 'POST', 'path' => '/orders', 'token' => $tokenA,
     'body' => order_payload($nameA, $phoneA, ['coupon_codes' => [$codeA2]])],
]);

$accepted = 0;
$rejected = 0;
foreach ($parallel as $res) {
    if ($res[0] === 201) {
        $accepted++;
        $createdOrders[] = (int) ($res[1]['data']['id'] ?? 0);
    } elseif ($res[0] === 422) {
        $rejected++;
    }
}
ok('exactly one simultaneous checkout wins', $accepted === 1, "accepted=$accepted statuses=" . implode(',', array_column($parallel, 0)));
ok('the other checkout is refused', $rejected === 1, "rejected=$rejected");

$row = coupon_row($pdo, $codeA2);
ok('the coupon is reserved exactly once', ($row['status'] ?? '') === 'reserved');
$linkStmt = $pdo->prepare('SELECT COUNT(*) FROM order_coupons WHERE coupon_id = :id');
$linkStmt->execute([':id' => $couponA2]);
ok('only one order is linked to the coupon', (int) $linkStmt->fetchColumn() === 1);

/* ───────────────── 9. consume on confirmation + usage record ───────────────── */

section('9. Confirmation consumes the coupon and records the usage against the order');

[$st] = req('PATCH', '/orders/' . $orderA2, ['status' => 'confirmed'], $adminToken);
ok('admin confirms the order with the coupon → 200', $st === 200, "status $st");

$row = coupon_row($pdo, $codeA1);
ok('the coupon is now used', ($row['status'] ?? '') === 'used');
ok('used_count is one', (int) ($row['used_count'] ?? 0) === 1);
ok('the coupon keeps the order it paid', (int) ($row['order_id'] ?? 0) === $orderA2);

$usage = $pdo->prepare('SELECT * FROM order_coupons WHERE order_id = :o AND coupon_id = :c');
$usage->execute([':o' => $orderA2, ':c' => $couponA1]);
$usageRow = $usage->fetch();
ok('the order records which coupon paid it', $usageRow !== false);

$event = $pdo->prepare('SELECT COUNT(*) FROM coupon_events WHERE coupon_id = :c AND event = "used"');
$event->execute([':c' => $couponA1]);
ok('a real usage event was written', (int) $event->fetchColumn() === 1);

req('PATCH', '/orders/' . $orderA2, ['status' => 'confirmed'], $adminToken);
$row = coupon_row($pdo, $codeA1);
ok('re-confirming never double-counts the use', (int) ($row['used_count'] ?? 0) === 1);

[$st, $json] = req('POST', '/orders', order_payload($nameA, $phoneA, [
    'coupon_codes' => [$codeA1],
]), $tokenA);
ok('a used coupon cannot be spent again → 422', $st === 422, "status $st");

/* ───────────────── 10. expiry ───────────────── */

section('10. An expired coupon is refused and marked expired');

$codeA3 = 'TACC' . $run . 'C';
[$st, $json] = make_coupon($adminToken, $phoneA, $codeA3, 30.0);
$couponA3 = (int) ($json['data']['id'] ?? 0);
if ($couponA3) $createdCoupons[] = $couponA3;
$pdo->prepare('UPDATE coupons SET expires_at = DATE_SUB(NOW(), INTERVAL 1 DAY) WHERE id = :id')
    ->execute([':id' => $couponA3]);

[$st, $json] = req('POST', '/orders', order_payload($nameA, $phoneA, [
    'coupon_codes' => [$codeA3],
]), $tokenA);
ok('an expired coupon is refused → 422', $st === 422, "status $st: " . ($json['message'] ?? ''));
$row = coupon_row($pdo, $codeA3);
ok('the row is moved to expired', ($row['status'] ?? '') === 'expired');

/* ───────────────── 11. role separation ───────────────── */

section('11. Customer tokens cannot reach management routes');

[$st] = req('POST', '/admin/coupons', ['code' => 'NOPE' . $run, 'value' => 10], $tokenA);
ok('a customer cannot create admin coupons → 403', $st === 403, "status $st");

[$st] = req('PATCH', '/orders/' . $orderA1, ['status' => 'cancelled'], $tokenA);
ok('a customer cannot change order status → 403', $st === 403, "status $st");

[$st] = req('GET', '/admin/users', null, $tokenA);
ok('a customer cannot list admin users → 403', $st === 403, "status $st");

[$st] = req('GET', '/me/coupons');
ok('/me/coupons without a token → 401', $st === 401, "status $st");

/* ───────────────── cleanup ───────────────── */

section('Cleanup');

try {
    // Orders first: coupon links cascade; coupon FKs fall back to NULL.
    foreach ($createdOrders as $oid) {
        $oid = (int) $oid;
        if ($oid <= 0) continue;
        $pdo->prepare('DELETE FROM order_coupons WHERE order_id = :id')->execute([':id' => $oid]);
        $pdo->prepare('DELETE FROM loyalty_transactions WHERE order_id = :id')->execute([':id' => $oid]);
        $pdo->prepare('DELETE FROM orders WHERE id = :id')->execute([':id' => $oid]);
    }
    foreach ($createdCoupons as $cid) {
        $cid = (int) $cid;
        if ($cid <= 0) continue;
        $pdo->prepare('DELETE FROM coupon_events WHERE coupon_id = :id')->execute([':id' => $cid]);
        $pdo->prepare('DELETE FROM order_coupons WHERE coupon_id = :id')->execute([':id' => $cid]);
        $pdo->prepare('DELETE FROM coupons WHERE id = :id')->execute([':id' => $cid]);
    }
    // Any coupon issued by the orders in this run (earned on confirmation).
    foreach ([$phoneA, $phoneB] as $p) {
        $pdo->prepare("DELETE FROM coupons WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone, ''), '[^0-9]', ''), 10) = RIGHT(REGEXP_REPLACE(:p, '[^0-9]', ''), 10)")
            ->execute([':p' => $p]);
    }
    foreach ($createdUsers as $uid) {
        $uid = (int) $uid;
        $pdo->prepare('DELETE FROM notifications WHERE user_id = :id')->execute([':id' => $uid]);
        $pdo->prepare('DELETE FROM loyalty_transactions WHERE created_by = :id')->execute([':id' => $uid]);
        $pdo->prepare('DELETE FROM password_resets WHERE user_id = :id')->execute([':id' => $uid]);
        $pdo->prepare('DELETE FROM refresh_tokens WHERE user_id = :id')->execute([':id' => $uid]);
        $pdo->prepare('DELETE FROM users WHERE id = :id')->execute([':id' => $uid]);
    }
    foreach ([$phoneA, $phoneB] as $p) {
        $pdo->prepare('DELETE FROM loyalty_transactions WHERE loyalty_account_id IN (SELECT id FROM loyalty_accounts WHERE phone = :p)')
            ->execute([':p' => $p]);
        $pdo->prepare('DELETE FROM loyalty_accounts WHERE phone = :p')->execute([':p' => $p]);
    }
    if ($tableId > 0) {
        $pdo->prepare('DELETE FROM restaurant_tables WHERE id = :id')->execute([':id' => $tableId]);
    }
    if ($originalSettings) {
        req('PUT', '/admin/loyalty/settings', [
            'enabled'               => (bool) $originalSettings['enabled'],
            'coupon_percent'        => (float) $originalSettings['coupon_percent'],
            'earn_min_order_amount' => (float) $originalSettings['earn_min_order_amount'],
            'max_coupons_per_order' => (int) $originalSettings['max_coupons_per_order'],
            'vat_rate'              => (float) $originalSettings['vat_rate'],
        ], $adminToken);
    }
    echo "  removed users " . implode(', ', $createdUsers)
        . "; orders " . implode(', ', $createdOrders)
        . "; coupons " . implode(', ', $createdCoupons) . "\n";
} catch (Throwable $e) {
    echo "  cleanup warning: " . $e->getMessage() . "\n";
}

echo "\n──────────────\nPASS: $PASS   FAIL: $FAIL\n";
exit($FAIL === 0 ? 0 : 1);
