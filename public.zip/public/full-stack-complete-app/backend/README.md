# 🍽️ Savoria — Full-Stack Complete App: Backend

The combined PHP + MySQL (PDO) API powering the complete Savoria application — menu browsing, ordering, table reservations, and JWT authentication with role-based access control, all in one router.

## 📁 Structure

```
backend/
├── index.php              # Front controller / router (all routes)
├── test_db.php              # Quick connectivity + row-count check
├── config/
│   ├── db.php                # PDO connection factory
│   └── env.php                 # .env loader
├── lib/
│   ├── helpers.php              # Response + request helpers
│   ├── validate.php              # All payload validation
│   ├── auth.php                    # Bearer token extraction, require_auth(), require_role()
│   ├── jwt.php                      # Minimal HS256 JWT encode/decode
│   ├── images.php                   # Server-side image validation, crop & resize
│   ├── loyalty.php                  # Points rules + audit trail
│   ├── i18n.php                       # Language helpers, optional-column detection
│   └── site_content.php              # Website content schema, defaults, helpers
├── .env.example
└── README.md
```

## ⚙️ Setup

```bash
mysql -u root -p < ../database/savoria_full_schema.sql
# Existing installations: run this once to add the management, loyalty,
# image, and order-notes columns without removing existing data.
mysql -u root -p < ../database/savoria_admin_loyalty_upgrade.sql
# Website Content Management tables (site_settings, site_images, reviews):
mysql -u root -p < ../database/site_content_schema.sql
# Arabic companion columns (name_ar, description_ar, content_ar, …):
mysql -u root -p < ../database/add_multilanguage_support.sql
# Calorie value of every dish:
mysql -u root -p < ../database/add_calories_support.sql
cp .env.example .env
# edit .env with your DB credentials and a strong JWT_SECRET
php -S localhost:8000 index.php
```

Verify the connection:

```bash
php test_db.php
```

Seed accounts (password for all: `Password123!`):

| Role | Email |
|---|---|
| admin | admin@savoria.example |
| staff | staff@savoria.example |
| customer | ayesha@savoria.example |

## 📡 Full API Reference

### Public

| Method | Route | Description |
|---|---|---|
| GET | `/categories` | List categories |
| GET | `/menu-items` | List menu items — `?category_id=`, `?available_only=true` |
| GET | `/menu-items/{id}` | Get a single menu item |
| POST | `/auth/register` | Create a customer account |
| POST | `/auth/login` | Authenticate, receive a JWT |
| POST | `/auth/forgot-password` | Request a reset token (returned in-response when `APP_DEBUG=true`, since no email service is wired up) |
| POST | `/auth/reset-password` | Reset password using a token |
| POST | `/reservations` | Submit a table reservation (guest or logged-in) — `409` if the slot is fully booked |
| POST | `/orders` | Place an order (guest or logged-in — token optional) |
| GET | `/orders/{id}` | Look up a single order — guests must pass `?phone=` matching the order; owners/staff/admin can use their token instead |
| GET | `/orders/track` | Look up all orders for a phone number (`?phone=`) — no order ID needed |
| GET | `/reservations/track` | Look up all table reservations for a phone number (`?phone=`) — no reservation ID needed |
| GET | `/site-content` | The website content the storefront renders — texts, images and published reviews. Served with a weak ETag so it is always revalidated. Carries the English **and** the Arabic texts (`settings` / `settings_ar`) |

> Every read endpoint accepts an optional `?lang=en|ar`. The payloads contain
> both languages wherever a translation exists, so the client can switch
> instantly without another round trip.

### Authenticated (any role)

| Method | Route | Description |
|---|---|---|
| GET | `/auth/me` | Get the current user |
| POST | `/auth/change-password` | Change password while logged in |
| POST | `/auth/logout` | Client-side token discard instruction |
| GET | `/my/orders` | The logged-in customer's own order history |

### Staff & Admin

| Method | Route | Description |
|---|---|---|
| GET | `/orders` | List all orders |
| PATCH | `/orders/{id}` | Update order status |
| GET | `/reservations` | List all reservations |
| PATCH | `/reservations/{id}` | Update reservation status |
| GET | `/admin/summary` | Today's order count/revenue + pending order/reservation counts |

### Admin only

| Method | Route | Description |
|---|---|---|
| POST | `/menu-items` | Create a menu item |
| PUT | `/menu-items/{id}` | Update a menu item |
| DELETE | `/menu-items/{id}` | Delete a menu item |
| GET | `/admin/users` | List all users |
| PATCH | `/admin/users/{id}/role` | Change a user's role |
| GET | `/admin/site-content` | Full website-content payload: field schema, current values, image slots, reviews, version |
| PUT | `/admin/site-content` | Save website texts — `{ values: { key: value }, values_ar: { key: value }, version }`; `409` when another manager saved first |
| POST | `/admin/site-content/reset` | Restore one group (`{ group }`) — or everything — to the shipped defaults |
| POST | `/admin/site-content/image` | Replace an image slot — multipart upload (`key` + `file`) or JSON (`key` + `url`/`alt`) |
| DELETE | `/admin/site-content/image/{key}` | Restore an image slot to the shipped default |
| GET | `/admin/reviews` | All homepage reviews (any status) |
| POST | `/admin/reviews` | Create a review |
| PATCH | `/admin/reviews/{id}` | Edit a review (text, rating, source, status, order, featured) |
| DELETE | `/admin/reviews/{id}` | Delete a review |

## 🔐 Design Notes

- **Guest checkout supported** — `POST /orders` and `POST /reservations` accept an *optional* bearer token via `get_optional_user()`. If present and valid, the order/reservation is linked to that account; if absent, it's still accepted as a guest submission.
- **Prices always computed server-side** from the current `menu_items` table inside a transaction with row locking (`FOR UPDATE`), never trusted from the client.
- **RBAC enforced per-route** with `require_auth()` + `require_role()`, mirroring the pattern from Project 4.
- **Consistent response envelope**: `{ success, message, data | errors }` across every route.
- **Website content is data, not markup** — `lib/site_content.php` holds the schema of every editable storefront text and image slot. The admin form, the server-side validation and the public payload are all generated from that one schema, so a field can never exist in the panel without being bound to the site. Shipped defaults live in the same file: a missing or empty row simply falls back to the original content.
- **Optimistic locking on content saves** — the client sends the `version` it loaded; if another manager saved in the meantime the API answers `409` instead of overwriting the newer data.
- **Multi-tenant ready** — `site_settings`, `site_images` and `reviews` all carry a `restaurant_id` (currently always `1`), so a per-restaurant split is a data migration and not a rewrite.

## 🌍 Languages (Arabic / English)

The API is bilingual without changing its contract:

- **Nothing existing is renamed or removed.** Every translatable column gains
  an `_ar` companion (`menu_items.name_ar`, `categories.description_ar`,
  `reviews.content_ar`, `site_settings.content_value_ar`, …). The English
  column is untouched, so the current data and every existing query keep
  working.
- **A missing translation is never an error** — it falls back to the English
  value, and the shipped Arabic defaults live in `lib/site_content.php`
  (`default_ar` / `label_ar` next to `default` / `label`).
- **The API stays optional-aware**: `lib/i18n.php` checks whether the `_ar`
  columns exist before it uses them, so the API keeps working on a database
  that has not received `add_multilanguage_support.sql` yet.
- **The write endpoints accept the Arabic fields** — `POST`/`PUT`
  `/menu-items`, `/categories` and `/admin/reviews` take `name_ar`,
  `description_ar`, `content_ar`, `author_meta_ar`; `PUT
  /admin/site-content` takes a second `values_ar` map.
- **The public payload carries both languages** — `GET /site-content` returns
  `settings` (English) and `settings_ar` (Arabic, already resolved), and the
  list endpoints return `name` + `name_ar` on the same row, so the frontend
  can switch language instantly without another request.
- **Read requests may carry `?lang=en|ar`**; the frontend always sends the
  visitor's choice.

Run the migration once:

```bash
mysql -u root -p savoria_app < ../database/add_multilanguage_support.sql
```

It is additive and idempotent: it only creates missing columns and only
fills translations that are still empty, so a manager's own wording is never
overwritten.

## 🧾 Invoice number & order number

Two numbers with two different jobs — the admin panel shows both:

| | Source | Behaviour |
|---|---|---|
| **Invoice number** | the order's own id (`orders.invoice_number`) | permanent — never changes, never repeats, **never reset** |
| **Order number** | `orders.order_number`, a sequence of its own | the operational counter the kitchen works with — the manager can **reset** it from the panel |

- The order number is handed out **inside the order transaction** (the counter row is locked with `FOR UPDATE`), so a failed order never burns a number and two orders can never share one.
- `GET /admin/order-counter` returns the current value; `POST /admin/order-counter/reset` (admin + super admin) sets it back to zero, so the next order is order #1. The invoice numbers are **not** touched by a reset.
- Both numbers are searchable in the panel's order search.
- The history stays intact: resetting the counter only affects the orders placed afterwards.

```bash
mysql -u root -p savoria_app < ../database/add_invoice_number.sql
```

## 🔢 Calories
Every dish can carry a calorie value. The column is nullable, so a dish
without a published value simply shows nothing on the menu card.

- `GET /menu-items` returns `calories` (null when nothing is published).
- `POST` / `PUT /menu-items` accept `calories` (0–5000, `null` or `""`
  clears the value). Anything outside that range is rejected with `422`.
- The storefront appends the value to the existing muted label of the menu
  card ("Starters · 420 kcal"), so the card keeps exactly the same elements,
  the same styles and the same spacing.

```bash
mysql -u root -p savoria_app < ../database/add_calories_support.sql
```

## 🖼️ Images

Uploads are processed on the server, never trusted from the browser:

| Endpoint | Target size | Where it is shown |
|---|---|---|
| `POST /admin/upload` (`prefix=menu`) | 800 × 600 (4:3) | the menu card |
| `POST /admin/upload` (`prefix=category`) | 900 × 600 (3:2) | the category |
| `POST /admin/site-content/image` (`key=…`) | the slot's own size | hero, story, gallery, logo |

Every file is sniffed (never the browser-supplied name), size-limited to
5 MB, center-cropped to the **exact aspect ratio of the container it lives
in** and re-encoded as a clean JPEG. The result is identical to what CSS
`object-fit: cover` would do, so the layout never changes.

## 🔗 Where This Fits

This is the backend half of the full-stack build. The matching frontend lives in `../frontend/`, wired up via `js/api.js` for authenticated fetch calls and `js/app.js` for cart/order/reservation logic.
