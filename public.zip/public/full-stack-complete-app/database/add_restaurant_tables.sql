-- =========================================================
-- Savoria — Restaurant tables & QR codes
-- Schema: add_restaurant_tables.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- A "table" is a physical table of the restaurant. Every table owns:
--
--   • TABLE NUMBER — the number the staff and the guest know. It is
--     unique inside the restaurant, so two tables can never share one.
--
--   • QR TOKEN — a random, unguessable 32-character token. The printed
--     QR code carries that token in its URL, never the table number.
--     The server turns the token back into the real table when the order
--     is placed, so the number stored on the order can never be forged
--     by editing the link.
--
-- Orders keep a real reference to the table they were placed at
-- (orders.table_id) next to the frozen table_number they already had.
--
-- The application also creates this structure by itself on first use
-- (backend/lib/tables.php), so running this file is optional — it is
-- provided for a clean deployment and for documentation.
--
--   mysql -u root -p savoria_app < database/add_restaurant_tables.sql
-- =========================================================

USE savoria_app;
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- ---------------------------------------------------------
-- 1. The tables of the restaurant
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS restaurant_tables (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    table_number TINYINT UNSIGNED NOT NULL,
    label        VARCHAR(60) DEFAULT NULL,
    label_ar     VARCHAR(60) DEFAULT NULL,
    seats        TINYINT UNSIGNED NOT NULL DEFAULT 4,
    status       ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
    qr_token     CHAR(32) NOT NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_restaurant_tables_number (table_number),
    UNIQUE KEY uq_restaurant_tables_token (qr_token)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 2. The table reference on the orders
-- ---------------------------------------------------------
SET @db := DATABASE();

-- The Arabic name was added after the first release, so an older install
-- that already has the table gets the column here.
SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `restaurant_tables` ADD COLUMN `label_ar` VARCHAR(60) DEFAULT NULL AFTER `label`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'restaurant_tables' AND COLUMN_NAME = 'label_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `orders` ADD COLUMN `table_id` INT UNSIGNED DEFAULT NULL AFTER `table_number`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'table_id');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `orders` ADD INDEX `idx_orders_table` (`table_id`)',
  'DO 0') FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'orders' AND INDEX_NAME = 'idx_orders_table');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;