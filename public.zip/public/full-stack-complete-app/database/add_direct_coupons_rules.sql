-- =========================================================
-- Savoria — Direct coupons (percentage of invoice)
-- Migration: add_direct_coupons_rules.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- Replaces the points-based coupon value with a direct rule the
-- manager can understand: every qualifying invoice earns ONE coupon
-- worth a percentage of that invoice.
--
-- Adds:
--   1. loyalty_settings.coupon_percent  → % of the invoice (default 10%)
--   2. coupons.source = 'order'         → coupon earned from an invoice
--   3. coupons.issued_for_order_id      → UNIQUE, at most one coupon per order
--
-- Safe to re-run: every change is guarded.
--
--   mysql -u root -p savoria_app < database/add_direct_coupons_rules.sql
-- =========================================================

USE savoria_app;

DELIMITER $$

DROP PROCEDURE IF EXISTS savoria_direct_coupons_procedure $$
CREATE PROCEDURE savoria_direct_coupons_procedure()
BEGIN
    DECLARE db VARCHAR(64);
    SET db = DATABASE();

    /* -----------------------------------------------------
       1. loyalty_settings.coupon_percent
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'loyalty_settings'
          AND column_name = 'coupon_percent') = 0
    THEN
        ALTER TABLE loyalty_settings
            ADD COLUMN coupon_percent DECIMAL(5,2) NOT NULL DEFAULT 10.00
            AFTER coupon_points_cost;
    END IF;

    /* -----------------------------------------------------
       2. coupons.source — allow 'order'
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'coupons'
          AND column_name = 'source'
          AND column_type LIKE '%order%') = 0
    THEN
        ALTER TABLE coupons
            MODIFY COLUMN source ENUM('points','admin','order') NOT NULL DEFAULT 'points';
    END IF;

    /* -----------------------------------------------------
       3. coupons.issued_for_order_id — one earned coupon per order
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'coupons'
          AND column_name = 'issued_for_order_id') = 0
    THEN
        ALTER TABLE coupons
            ADD COLUMN issued_for_order_id INT UNSIGNED DEFAULT NULL
            AFTER order_id;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.statistics
        WHERE table_schema = db AND table_name = 'coupons'
          AND index_name = 'uq_coupons_issued_order') = 0
    THEN
        ALTER TABLE coupons
            ADD UNIQUE KEY uq_coupons_issued_order (issued_for_order_id);
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.table_constraints
        WHERE table_schema = db AND table_name = 'coupons'
          AND constraint_name = 'fk_coupons_issued_order') = 0
    THEN
        ALTER TABLE coupons
            ADD CONSTRAINT fk_coupons_issued_order
            FOREIGN KEY (issued_for_order_id) REFERENCES orders (id)
            ON DELETE SET NULL;
    END IF;
END$$

DELIMITER ;

CALL savoria_direct_coupons_procedure();
DROP PROCEDURE IF EXISTS savoria_direct_coupons_procedure;

UPDATE loyalty_settings SET coupon_percent = 10.00 WHERE coupon_percent IS NULL;
