-- Add discount_percent support to menu_items table
ALTER TABLE menu_items ADD COLUMN IF NOT EXISTS discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00;
