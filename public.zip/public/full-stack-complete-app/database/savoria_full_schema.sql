-- =========================================================
-- Savoria — Full-Stack Complete App
-- Schema: savoria_full_schema.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- Combines the schemas from Projects 3 and 4 into a single
-- database powering the complete application: menu, orders,
-- users, authentication, and table reservations.
-- =========================================================

CREATE DATABASE IF NOT EXISTS savoria_app
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE savoria_app;

-- ---------------------------------------------------------
-- users
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(120) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    phone         VARCHAR(20) DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM('customer', 'staff', 'admin', 'cashier', 'super_admin') NOT NULL DEFAULT 'customer',
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    force_password_change BOOLEAN NOT NULL DEFAULT FALSE,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- categories
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(60) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    sort_order  TINYINT UNSIGNED NOT NULL DEFAULT 0,
    is_visible  BOOLEAN NOT NULL DEFAULT TRUE,
    image_url   VARCHAR(500) DEFAULT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- menu_items
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu_items (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id       INT UNSIGNED NOT NULL,
    name              VARCHAR(120) NOT NULL,
    description       TEXT,
    price             DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    image_url         VARCHAR(500) DEFAULT NULL,
    spice_level       TINYINT UNSIGNED NOT NULL DEFAULT 0 CHECK (spice_level BETWEEN 0 AND 3),
    prep_time_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 15,
    is_available      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_menu_items_category
        FOREIGN KEY (category_id) REFERENCES categories(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX idx_menu_items_category (category_id),
    INDEX idx_menu_items_available (is_available)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- orders
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id           INT UNSIGNED DEFAULT NULL,
    customer_name     VARCHAR(120) NOT NULL,
    phone             VARCHAR(20) NOT NULL,
    order_type        ENUM('dine_in', 'pickup', 'delivery') NOT NULL DEFAULT 'delivery',
    delivery_address  VARCHAR(255) DEFAULT NULL,
    table_number      TINYINT UNSIGNED DEFAULT NULL,
    order_notes       VARCHAR(255) DEFAULT NULL,
    status            ENUM('pending','confirmed','preparing','out_for_delivery','delivered','cancelled')
                        NOT NULL DEFAULT 'pending',
    payment_method    VARCHAR(30) DEFAULT NULL,
    processed_by      INT UNSIGNED DEFAULT NULL,
    total_amount      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    promo_code        VARCHAR(30) DEFAULT NULL,
    discount_amount   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    points_discount   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_orders_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_orders_processed_by
        FOREIGN KEY (processed_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_orders_status (status),
    INDEX idx_orders_user (user_id),
    INDEX idx_orders_created (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- order_items
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id             INT UNSIGNED NOT NULL,
    menu_item_id         INT UNSIGNED NOT NULL,
    item_name_snapshot   VARCHAR(120) NOT NULL,
    unit_price           DECIMAL(10,2) NOT NULL,
    quantity             SMALLINT UNSIGNED NOT NULL DEFAULT 1 CHECK (quantity > 0),
    subtotal             DECIMAL(10,2) NOT NULL,
    special_instructions VARCHAR(255) DEFAULT NULL,
    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_order_items_menu_item
        FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX idx_order_items_order (order_id)
) ENGINE=InnoDB;

-- Customer-dismissed order cards (the × on the account page). Per account,
-- so hiding an order never changes what management or another customer sees.
CREATE TABLE IF NOT EXISTS customer_hidden_orders (
    user_id    INT UNSIGNED NOT NULL,
    order_id   INT UNSIGNED NOT NULL,
    hidden_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, order_id),
    INDEX idx_customer_hidden_order (order_id),
    CONSTRAINT fk_customer_hidden_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_customer_hidden_order
        FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- loyalty_settings / loyalty_accounts / loyalty_transactions
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS loyalty_settings (
    id                    TINYINT UNSIGNED NOT NULL PRIMARY KEY DEFAULT 1,
    enabled               BOOLEAN NOT NULL DEFAULT TRUE,
    earn_amount_per_point DECIMAL(10,2) NOT NULL DEFAULT 10.00 CHECK (earn_amount_per_point > 0),
    earn_min_order_amount DECIMAL(10,2) NOT NULL DEFAULT 500.00 CHECK (earn_min_order_amount >= 0),
    redeem_min_points     INT UNSIGNED NOT NULL DEFAULT 100 CHECK (redeem_min_points > 0),
    redeem_point_value    DECIMAL(10,2) NOT NULL DEFAULT 1.00 CHECK (redeem_point_value >= 0),
    updated_by            INT UNSIGNED DEFAULT NULL,
    updated_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_loyalty_settings_user
        FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO loyalty_settings (id) VALUES (1);

CREATE TABLE IF NOT EXISTS loyalty_accounts (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    phone           VARCHAR(15) NOT NULL UNIQUE,
    customer_name   VARCHAR(120) DEFAULT NULL,
    points_balance  INT NOT NULL DEFAULT 0 CHECK (points_balance >= 0),
    total_earned    INT NOT NULL DEFAULT 0,
    total_redeemed  INT NOT NULL DEFAULT 0,
    total_adjusted  INT NOT NULL DEFAULT 0,
    total_reversed  INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS loyalty_transactions (
    id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    loyalty_account_id    INT UNSIGNED NOT NULL,
    order_id              INT UNSIGNED DEFAULT NULL,
    type                  ENUM('earn','redeem','adjust','reverse') NOT NULL,
    points_delta          INT NOT NULL,
    points_balance_after  INT NOT NULL,
    qualified_amount      DECIMAL(10,2) DEFAULT NULL,
    cash_value            DECIMAL(10,2) DEFAULT NULL,
    reason                VARCHAR(255) DEFAULT NULL,
    created_by            INT UNSIGNED DEFAULT NULL,
    created_by_name       VARCHAR(120) DEFAULT NULL,
    created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    order_op_key VARCHAR(32) GENERATED ALWAYS AS (
        IF(order_id IS NULL OR type NOT IN ('earn','reverse'), NULL, CONCAT(type, '#', order_id))
    ) STORED,
    CONSTRAINT fk_tx_account FOREIGN KEY (loyalty_account_id) REFERENCES loyalty_accounts(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_tx_order FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_tx_user FOREIGN KEY (created_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT uq_tx_order_op UNIQUE (order_op_key),
    INDEX idx_tx_account_date (loyalty_account_id, created_at),
    INDEX idx_tx_order (order_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admin_audit_log (
    id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED DEFAULT NULL,
    actor_name   VARCHAR(120) DEFAULT NULL,
    action       VARCHAR(60) NOT NULL,
    entity_type  VARCHAR(40) DEFAULT NULL,
    entity_id    VARCHAR(40) DEFAULT NULL,
    details      TEXT DEFAULT NULL,
    ip_address   VARCHAR(45) DEFAULT NULL,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_audit_action (action),
    INDEX idx_audit_date (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- reservations
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS reservations (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id           INT UNSIGNED DEFAULT NULL,
    full_name         VARCHAR(120) NOT NULL,
    phone             VARCHAR(20) NOT NULL,
    party_size        TINYINT UNSIGNED NOT NULL,
    reservation_date  DATE NOT NULL,
    reservation_time  TIME NOT NULL,
    status            ENUM('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
    notes             VARCHAR(255) DEFAULT NULL,
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reservations_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_reservations_date (reservation_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- refresh_tokens
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    token_hash  VARCHAR(255) NOT NULL,
    expires_at  DATETIME NOT NULL,
    revoked     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_refresh_tokens_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_refresh_tokens_user (user_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- password_resets
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS password_resets (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    token_hash  VARCHAR(255) NOT NULL,
    expires_at  DATETIME NOT NULL,
    used_at     DATETIME DEFAULT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_password_resets_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_password_resets_user (user_id),
    INDEX idx_password_resets_token (token_hash)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Seed data — users (password for all: "Password123!")
-- ---------------------------------------------------------
INSERT INTO users (full_name, email, phone, password_hash, role) VALUES
    ('Savoria Admin', 'admin@savoria.example', '021111728674', '$2y$10$U5zI32dvnZEHaR2naPBlU.0lJ8ttwrm.IjKbDoJL0zk5xqSqmpulG', 'super_admin'),
    ('Front of House Staff', 'staff@savoria.example', '03001112233', '$2y$10$U5zI32dvnZEHaR2naPBlU.0lJ8ttwrm.IjKbDoJL0zk5xqSqmpulG', 'staff'),
    ('Ayesha Khan', 'ayesha@savoria.example', '03211234567', '$2y$10$U5zI32dvnZEHaR2naPBlU.0lJ8ttwrm.IjKbDoJL0zk5xqSqmpulG', 'customer');

-- ---------------------------------------------------------
-- Seed data — categories
-- ---------------------------------------------------------
INSERT INTO categories (name, description, sort_order) VALUES
    ('Starters', 'Small plates to begin the meal', 1),
    ('Mains', 'Chef-crafted main courses', 2),
    ('Desserts', 'Sweet finishes', 3),
    ('Beverages', 'House-made drinks and coolers', 4);

-- ---------------------------------------------------------
-- Seed data — menu_items
-- ---------------------------------------------------------
INSERT INTO menu_items (category_id, name, description, price, image_url, spice_level, prep_time_minutes, is_available) VALUES
    (1, 'Charred Corn & Burrata', 'Grilled sweet corn, torn burrata, chili oil, micro basil.', 950.00, 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&q=80', 1, 12, TRUE),
    (1, 'Smoked Prawn Toast', 'Brioche, smoked prawn butter, pickled shallot, lime zest.', 1150.00, 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=500&q=80', 2, 15, TRUE),
    (1, 'Roasted Beet Salad', 'Heirloom beets, whipped goat cheese, candied walnut, sherry vinaigrette.', 850.00, 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=500&q=80', 0, 10, TRUE),
    (2, 'Slow-Braised Lamb Shank', 'Red wine jus, saffron mash, roasted root vegetables.', 2450.00, 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&q=80', 1, 35, TRUE),
    (2, 'Charcoal Grilled Salmon', 'Miso glaze, sesame greens, ginger-scallion oil.', 2150.00, 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=500&q=80', 1, 25, TRUE),
    (2, 'Wild Mushroom Risotto', 'Arborio rice, truffle oil, aged parmesan, crisped sage.', 1850.00, 'https://images.unsplash.com/photo-1476124369491-e7addf5db371?w=500&q=80', 0, 28, FALSE),
    (3, 'Dark Chocolate Fondant', 'Molten center, pistachio crumble, vanilla bean ice cream.', 850.00, 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=500&q=80', 0, 18, TRUE),
    (3, 'Saffron Kunafa', 'Crisp shredded pastry, cream cheese filling, rose-saffron syrup.', 780.00, 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=500&q=80', 0, 20, TRUE),
    (4, 'Rose & Cardamom Cooler', 'House-made rose syrup, cardamom, soda, fresh mint.', 550.00, 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=500&q=80', 0, 5, TRUE),
    (4, 'Cold Brew Espresso Tonic', 'Slow-steeped cold brew, tonic water, orange peel.', 620.00, 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=500&q=80', 0, 5, TRUE),
    (1, 'Truffle Mushroom Arancini', 'Crisp risotto balls, wild mushroom, truffle aioli, shaved parmesan.', 890.00, 'https://images.unsplash.com/photo-1541529086526-db283c563270?w=500&q=80', 0, 14, TRUE),
    (2, 'Peri-Peri Grilled Chicken', 'Char-grilled chicken breast, peri-peri glaze, herbed rice, charred vegetables.', 2050.00, 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=500&q=80', 2, 30, TRUE);
