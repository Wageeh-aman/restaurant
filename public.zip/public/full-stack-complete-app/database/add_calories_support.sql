-- =========================================================
-- Savoria — Menu item calories
-- Schema: add_calories_support.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- Adds the calorie value of every dish to `menu_items` so the
-- management panel can publish it next to the price.
--
-- Design notes:
--   • The column is NULLABLE, so a dish without a published value
--     simply shows nothing (the storefront hides it completely).
--   • The column is added with a plain ALTER, so nothing existing is
--     renamed, retyped or dropped and no row is lost.
--   • The guard makes the statement safe to run more than once.
--
-- The seeded values below are indicative figures for the demo menu.
-- A manager edits them in the panel (Menu & Categories → Edit),
-- and the storefront picks them up immediately.
--
--   mysql -u root -p savoria_app < database/add_calories_support.sql
-- =========================================================

USE savoria_app;
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- ---------------------------------------------------------
-- 1. The new column
-- ---------------------------------------------------------
SET @db := DATABASE();
SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `menu_items` ADD COLUMN `calories` SMALLINT UNSIGNED DEFAULT NULL AFTER `price`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'menu_items' AND COLUMN_NAME = 'calories');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------
-- 2. Indicative values for the seeded menu
--
-- Only rows whose value is still empty are filled, so a value a
-- manager has already set is never overwritten.
-- ---------------------------------------------------------

UPDATE menu_items SET calories = 420 WHERE name = 'Charred Corn & Burrata'   AND calories IS NULL;
UPDATE menu_items SET calories = 380 WHERE name = 'Smoked Prawn Toast'         AND calories IS NULL;
UPDATE menu_items SET calories = 290 WHERE name = 'Roasted Beet Salad'        AND calories IS NULL;
UPDATE menu_items SET calories = 720 WHERE name = 'Slow-Braised Lamb Shank'    AND calories IS NULL;
UPDATE menu_items SET calories = 610 WHERE name = 'Charcoal Grilled Salmon'   AND calories IS NULL;
UPDATE menu_items SET calories = 560 WHERE name = 'Wild Mushroom Risotto'     AND calories IS NULL;
UPDATE menu_items SET calories = 480 WHERE name = 'Dark Chocolate Fondant'    AND calories IS NULL;
UPDATE menu_items SET calories = 520 WHERE name = 'Saffron Kunafa'             AND calories IS NULL;
UPDATE menu_items SET calories = 140 WHERE name = 'Rose & Cardamom Cooler'    AND calories IS NULL;
UPDATE menu_items SET calories = 35  WHERE name = 'Cold Brew Espresso Tonic'  AND calories IS NULL;
UPDATE menu_items SET calories = 410 WHERE name = 'Truffle Mushroom Arancini' AND calories IS NULL;
UPDATE menu_items SET calories = 650 WHERE name = 'Peri-Peri Grilled Chicken'  AND calories IS NULL;
