-- =========================================================
-- Savoria — Full-Stack Complete App
-- Upgrade: Coupons & Points-to-Coupon Rewards
--
-- Safe / idempotent upgrade for an EXISTING savoria_app database.
-- Re-running this file is harmless: every change is guarded.
--
-- Adds:
--   1. loyalty_settings — coupon value, points cost, max per order
--   2. orders           — coupon discount + redeemed-points discount
--   3. loyalty_transactions.type — new 'refund' entry (cancel reversal)
--   4. coupons          — one row per coupon, owned by a loyalty account
--   5. coupon_events    — created / reserved / used / released / cancelled
--   6. order_coupons    — which coupons paid which order (1 coupon = 1 order)
--
-- Nothing is dropped and no existing row is modified.
--
--   mysql -u root -p savoria_app < database/add_coupons_system.sql
-- =========================================================

USE savoria_app;

DELIMITER $$

DROP PROCEDURE IF EXISTS savoria_coupons_procedure $$
CREATE PROCEDURE savoria_coupons_procedure()
BEGIN
    DECLARE db VARCHAR(64);
    SET db = DATABASE();

    /* -----------------------------------------------------
       1. loyalty_settings — coupon rules
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'loyalty_settings'
          AND column_name = 'coupon_value') = 0
    THEN
        ALTER TABLE loyalty_settings
            ADD COLUMN coupon_value DECIMAL(10,2) NOT NULL DEFAULT 20.00
            AFTER redeem_point_value;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'loyalty_settings'
          AND column_name = 'coupon_points_cost') = 0
    THEN
        ALTER TABLE loyalty_settings
            ADD COLUMN coupon_points_cost INT UNSIGNED NOT NULL DEFAULT 20
            AFTER coupon_value;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'loyalty_settings'
          AND column_name = 'max_coupons_per_order') = 0
    THEN
        /* 0 = no limit — the customer may stack every available coupon. */
        ALTER TABLE loyalty_settings
            ADD COLUMN max_coupons_per_order INT UNSIGNED NOT NULL DEFAULT 0
            AFTER coupon_points_cost;
    END IF;

    /* -----------------------------------------------------
       2. orders — coupon discount + redeemed points
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'orders'
          AND column_name = 'coupon_discount') = 0
    THEN
        ALTER TABLE orders
            ADD COLUMN coupon_discount DECIMAL(10,2) NOT NULL DEFAULT 0.00
            AFTER points_discount;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'orders'
          AND column_name = 'redeemed_points') = 0
    THEN
        ALTER TABLE orders
            ADD COLUMN redeemed_points INT UNSIGNED NOT NULL DEFAULT 0
            AFTER coupon_discount;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'orders'
          AND column_name = 'redeemed_discount') = 0
    THEN
        ALTER TABLE orders
            ADD COLUMN redeemed_discount DECIMAL(10,2) NOT NULL DEFAULT 0.00
            AFTER redeemed_points;
    END IF;

    /* -----------------------------------------------------
       3. loyalty_transactions — allow refund rows
          (points returned when an order is cancelled)
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'loyalty_transactions'
          AND column_name = 'type' AND column_type LIKE '%refund%') = 0
    THEN
        ALTER TABLE loyalty_transactions
            MODIFY COLUMN type ENUM('earn','redeem','adjust','reverse','refund') NOT NULL;
    END IF;

    /* -----------------------------------------------------
       4. coupons — the coupon itself
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS coupons (
        id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code               VARCHAR(24) NOT NULL,
        loyalty_account_id INT UNSIGNED NOT NULL,
        user_id            INT UNSIGNED DEFAULT NULL,
        phone              VARCHAR(15) NOT NULL,
        customer_name      VARCHAR(120) DEFAULT NULL,
        value              DECIMAL(10,2) NOT NULL,
        points_spent       INT UNSIGNED NOT NULL DEFAULT 0,
        status             ENUM('available','reserved','used','cancelled','expired')
                           NOT NULL DEFAULT 'available',
        source             ENUM('points','admin') NOT NULL DEFAULT 'points',
        order_id           INT UNSIGNED DEFAULT NULL,
        reserved_at        DATETIME DEFAULT NULL,
        used_at            DATETIME DEFAULT NULL,
        cancelled_at       DATETIME DEFAULT NULL,
        cancel_reason      VARCHAR(255) DEFAULT NULL,
        expires_at         DATETIME DEFAULT NULL,
        created_by         INT UNSIGNED DEFAULT NULL,
        created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_coupon_account
            FOREIGN KEY (loyalty_account_id) REFERENCES loyalty_accounts(id)
            ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT fk_coupon_user
            FOREIGN KEY (user_id) REFERENCES users(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        CONSTRAINT fk_coupon_order
            FOREIGN KEY (order_id) REFERENCES orders(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        CONSTRAINT fk_coupon_creator
            FOREIGN KEY (created_by) REFERENCES users(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        UNIQUE KEY uq_coupon_code (code),
        KEY idx_coupon_owner (loyalty_account_id, status),
        KEY idx_coupon_phone (phone, status),
        KEY idx_coupon_order (order_id),
        KEY idx_coupon_status (status, created_at)
    ) ENGINE=InnoDB;

    /* -----------------------------------------------------
       5. coupon_events — immutable lifecycle log
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS coupon_events (
        id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        coupon_id     INT UNSIGNED NOT NULL,
        event         ENUM('created','reserved','used','released','cancelled','expired') NOT NULL,
        order_id      INT UNSIGNED DEFAULT NULL,
        actor_user_id INT UNSIGNED DEFAULT NULL,
        actor_name    VARCHAR(120) DEFAULT NULL,
        notes         VARCHAR(255) DEFAULT NULL,
        created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_coupon_event_coupon
            FOREIGN KEY (coupon_id) REFERENCES coupons(id)
            ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT fk_coupon_event_order
            FOREIGN KEY (order_id) REFERENCES orders(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        CONSTRAINT fk_coupon_event_actor
            FOREIGN KEY (actor_user_id) REFERENCES users(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        KEY idx_coupon_event_coupon (coupon_id, created_at),
        KEY idx_coupon_event_order (order_id)
    ) ENGINE=InnoDB;

    /* -----------------------------------------------------
       6. order_coupons — which coupons paid which order.
          A coupon may appear on more than one order over its life
          (used, order cancelled → returned, used again), so this is
          a history table, not a uniqueness constraint. Single-use is
          enforced by coupons.status under a row lock.
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS order_coupons (
        id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        order_id   INT UNSIGNED NOT NULL,
        coupon_id  INT UNSIGNED NOT NULL,
        code       VARCHAR(24) NOT NULL,
        value      DECIMAL(10,2) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_order_coupon_order
            FOREIGN KEY (order_id) REFERENCES orders(id)
            ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT fk_order_coupon_coupon
            FOREIGN KEY (coupon_id) REFERENCES coupons(id)
            ON DELETE CASCADE ON UPDATE CASCADE,
        KEY idx_order_coupon_order (order_id),
        KEY idx_order_coupon_coupon (coupon_id)
    ) ENGINE=InnoDB;

    /* A first cut of this table shipped with UNIQUE(coupon_id), which
       would block re-using a coupon after an order cancellation. The FK
       needs a plain index on the same column, so create it first. */
    IF (SELECT COUNT(*) FROM information_schema.statistics
        WHERE table_schema = db AND table_name = 'order_coupons'
          AND index_name = 'idx_order_coupon_coupon') = 0
    THEN
        ALTER TABLE order_coupons ADD KEY idx_order_coupon_coupon (coupon_id);
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.statistics
        WHERE table_schema = db AND table_name = 'order_coupons'
          AND index_name = 'uq_order_coupon') > 0
    THEN
        ALTER TABLE order_coupons DROP INDEX uq_order_coupon;
    END IF;
END $$

DELIMITER ;

CALL savoria_coupons_procedure();
DROP PROCEDURE savoria_coupons_procedure;

SELECT 'Coupons upgrade applied — verifying:' AS status;
SHOW TABLES LIKE 'coupon%';
SHOW TABLES LIKE 'order_coupons';
