-- =========================================================
-- Savoria — Multi-language support
-- Schema: add_multilanguage_support.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- Adds the Arabic companion columns next to the existing English
-- ones. The original columns are never renamed, retyped or dropped,
-- so:
--   • every existing row keeps working exactly as before;
--   • every existing query keeps working exactly as before;
--   • the API keeps its field names and its behaviour.
--
-- A missing Arabic value simply means "fall back to the English
-- value", so the migration can be applied at any time and the site
-- is never left in a half-translated state.
--
-- Safe to run on an existing database: every statement is guarded
-- and only fills columns that are still empty, so running it twice
-- is harmless and a manager's own translations are never overwritten.
--
--   mysql -u root -p savoria_app < database/add_multilanguage_support.sql
-- =========================================================

USE savoria_app;

-- The client connection must speak UTF-8. Without this line the server
-- would read the Arabic bytes of this file in the connection's default
-- charset and store them mangled (a "double encoded" value that shows
-- up as Ù¤Ï® instead of ذرة). This also repairs the values that were
-- written by an earlier run without the SET NAMES statement.
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- ---------------------------------------------------------
-- 1. The new columns
-- ---------------------------------------------------------

-- menu_items: the dish name and its description
SET @db := DATABASE();
SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `menu_items` ADD COLUMN `name_ar` VARCHAR(120) DEFAULT NULL AFTER `name`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'menu_items' AND COLUMN_NAME = 'name_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `menu_items` ADD COLUMN `description_ar` TEXT DEFAULT NULL AFTER `description`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'menu_items' AND COLUMN_NAME = 'description_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- categories: the category name and its description
SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `categories` ADD COLUMN `name_ar` VARCHAR(60) DEFAULT NULL AFTER `name`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'categories' AND COLUMN_NAME = 'name_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `categories` ADD COLUMN `description_ar` VARCHAR(255) DEFAULT NULL AFTER `description`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'categories' AND COLUMN_NAME = 'description_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- reviews: the review text and the short guest description
SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `reviews` ADD COLUMN `content_ar` TEXT DEFAULT NULL AFTER `content`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'reviews' AND COLUMN_NAME = 'content_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `reviews` ADD COLUMN `author_meta_ar` VARCHAR(160) DEFAULT NULL AFTER `author_meta`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'reviews' AND COLUMN_NAME = 'author_meta_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- site_settings: the Arabic text of every editable website string
SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `site_settings` ADD COLUMN `content_value_ar` TEXT DEFAULT NULL AFTER `content_value`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'site_settings' AND COLUMN_NAME = 'content_value_ar');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------
-- 2. Arabic content for the seeded menu
--
-- Every column is repaired on its own: a value is written only when
-- it is missing or when it is still mangled from an earlier run
-- (a mangled value contains no Arabic character at all). A real
-- translation written by a manager always contains Arabic and is
-- therefore never touched.
-- ---------------------------------------------------------

UPDATE categories SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'مقبلات', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'أطباق صغيرة تبدأ بها الوجبة', description_ar)
  WHERE name = 'Starters';

UPDATE categories SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'أطباق رئيسية', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'أطباق رئيسية يحضرها الشيف', description_ar)
  WHERE name = 'Mains';

UPDATE categories SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'حلويات', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'حلويات تُختم بها الوجبة', description_ar)
  WHERE name = 'Desserts';

UPDATE categories SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'مشروبات', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'مشروبات ومنعشات تُحضّر في المطعم', description_ar)
  WHERE name = 'Beverages';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'ذرة مشوية مع البوراتا', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'ذرة حلوة مشوية، بوراتا ممزقة، زيت الفلفل الحار، وريحان صغير.', description_ar)
  WHERE name = 'Charred Corn & Burrata';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'خبز الروبيان المدخّن', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'خبز بريوش، زبدة روبيان مدخّن، شالوت مخلّل، وبشور الليمون.', description_ar)
  WHERE name = 'Smoked Prawn Toast';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'سلطة الشمندر المشوية', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'شمندر أصناف قديمة، جبن ماعز مخفوق، جوز مكرمل، وصلصة شيري.', description_ar)
  WHERE name = 'Roasted Beet Salad';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'لحم غنم مطهو ببطء', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'صلصة النبيذ الأحمر، بطاطس مهروسة بالزعفران، وخضروات جذرية مشوية.', description_ar)
  WHERE name = 'Slow-Braised Lamb Shank';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'سلمون مشوي على الفحم', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'تتبيلة الميسو، خضار بالسمسم، وزيت الزنجبيل والأخضر.', description_ar)
  WHERE name = 'Charcoal Grilled Salmon';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'ريزوتو الفطر البري', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'أرز أربوريو، زيت الكمأة، بارميزان معتّق، ومريمية مقرمشة.', description_ar)
  WHERE name = 'Wild Mushroom Risotto';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'كيكة الشوكولاتة الداكنة الساخنة', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'قلب سائل، فتات الفستق، وآيس كريم فانيليا.', description_ar)
  WHERE name = 'Dark Chocolate Fondant';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'كنافة بالزعفران', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'عجين مبشور مقرمش، حشوة جبن كريمية، وشراب الورد والزعفران.', description_ar)
  WHERE name = 'Saffron Kunafa';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'مشروب الورد والهيل المثلج', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'شراب الورد المحضّر في المطعم، الهيل، صودا، ونعناع طازج.', description_ar)
  WHERE name = 'Rose & Cardamom Cooler';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'إسبرسو تونيك بالتخمير البارد', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'قهوة منقوعة ببطء، ماء تونيك، وقشر البرتقال.', description_ar)
  WHERE name = 'Cold Brew Espresso Tonic';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'أرانشيني الكمأة والفطر', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'كرات ريزوتو مقرمشة، فطر بري، مايونيز الكمأة، وبارميزان مبشور.', description_ar)
  WHERE name = 'Truffle Mushroom Arancini';

UPDATE menu_items SET
    name_ar = IF(name_ar IS NULL OR name_ar = '' OR name_ar NOT REGEXP '[؀-ۿ]', 'دجاج مشوي بصلصة بيريتشي', name_ar),
    description_ar = IF(description_ar IS NULL OR description_ar = '' OR description_ar NOT REGEXP '[؀-ۿ]', 'صدر دجاج مشوي على الفحم، صوص بيريتشي، أرز بالأعشاب، وخضروات مشوية.', description_ar)
  WHERE name = 'Peri-Peri Grilled Chicken';

-- ---------------------------------------------------------
-- 3. Arabic content for the seeded reviews
-- ---------------------------------------------------------

UPDATE reviews SET
    author_meta_ar = IF(author_meta_ar IS NULL OR author_meta_ar = '' OR author_meta_ar NOT REGEXP '[؀-ۿ]', 'ضيفة دائمة منذ 3 سنوات', author_meta_ar),
    content_ar = IF(content_ar IS NULL OR content_ar = '' OR content_ar NOT REGEXP '[؀-ۿ]', 'كان كل طبق متعمّدًا في اختياره. لحم الغنم المطهو ببطء جعلني أعيد التفكير في كل مطعم آخر جربته.', content_ar)
  WHERE author_name = 'Hina R.';

UPDATE reviews SET
    author_meta_ar = IF(author_meta_ar IS NULL OR author_meta_ar = '' OR author_meta_ar NOT REGEXP '[؀-ۿ]', 'عميل جديد', author_meta_ar),
    content_ar = IF(content_ar IS NULL OR content_ar = '' OR content_ar NOT REGEXP '[؀-ۿ]', 'طلبت التوصيل بعشوائية عبر الموقع — وصل الطلب ساخنًا، ولم تستغرق عملية الدفع أكثر من دقيقة.', content_ar)
  WHERE author_name = 'Bilal S.';

UPDATE reviews SET
    author_meta_ar = IF(author_meta_ar IS NULL OR author_meta_ar = '' OR author_meta_ar NOT REGEXP '[؀-ۿ]', 'عميلة للفعاليات المؤسسية', author_meta_ar),
    content_ar = IF(content_ar IS NULL OR content_ar = '' OR content_ar NOT REGEXP '[؀-ۿ]', 'حجزت طاولة لثمانية أشخاص في وقت قصير عبر الموقع — تجربة سلسة وتم التأكيد فورًا.', content_ar)
  WHERE author_name = 'Farah A.';

-- ---------------------------------------------------------
-- 4. Notes
-- ---------------------------------------------------------
-- The website texts (hero, story, contact, footer …) do not need a
-- row here: their English and Arabic defaults live in
-- backend/lib/site_content.php (site_content_fields). The
-- content_value_ar column only stores a manager's own Arabic
-- wording when they change it in the admin panel.
--
-- The site default language stays English. The visitor picks the
-- language with the switcher in the navbar, and the choice is
-- remembered in the browser (localStorage).
