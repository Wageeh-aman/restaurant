-- =========================================================
-- Savoria — Value Added Tax (VAT) System
-- Migration: add_vat_system.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- Adds configurable VAT (Value Added Tax / ضريبة القيمة المضافة)
-- support to loyalty_settings and orders tables.
-- Safe to re-run: checks if columns exist before altering.
-- =========================================================

USE savoria_app;

-- 1. Add vat_rate to loyalty_settings (default 15.00%)
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists
FROM information_schema.COLUMNS
WHERE table_schema = DATABASE()
  AND table_name = 'loyalty_settings'
  AND column_name = 'vat_rate';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE loyalty_settings ADD COLUMN vat_rate DECIMAL(5,2) NOT NULL DEFAULT 15.00 AFTER max_coupons_per_order;',
    'SELECT "vat_rate already exists in loyalty_settings";'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 2. Add vat_amount and vat_rate to orders table
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists
FROM information_schema.COLUMNS
WHERE table_schema = DATABASE()
  AND table_name = 'orders'
  AND column_name = 'vat_amount';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE orders ADD COLUMN vat_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER discount_amount, ADD COLUMN vat_rate DECIMAL(5,2) NOT NULL DEFAULT 15.00 AFTER vat_amount;',
    'SELECT "vat_amount already exists in orders";'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 3. Update existing default row if needed
UPDATE loyalty_settings SET vat_rate = 15.00 WHERE vat_rate IS NULL;
