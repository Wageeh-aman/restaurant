-- =========================================================
-- Savoria — Earned coupon is issued on confirmation
-- Migration: add_pending_earned_coupon.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- The coupon an invoice earns is promised at checkout but only issued
-- when management confirms the order. The promised amount is stored on
-- the order so a later change to the coupon percentage cannot shrink or
-- inflate what the customer was told.
--
-- Adds to orders:
--   earned_coupon_value    → promised coupon value (SAR), 0 = none
--   earned_coupon_percent  → percentage used to promise that value
--
-- Safe to re-run.
--
--   mysql -u root -p savoria_app < database/add_pending_earned_coupon.sql
-- =========================================================

USE savoria_app;

SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists
FROM information_schema.COLUMNS
WHERE table_schema = DATABASE()
  AND table_name = 'orders'
  AND column_name = 'earned_coupon_value';

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE orders ADD COLUMN earned_coupon_value DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER vat_rate, ADD COLUMN earned_coupon_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER earned_coupon_value;',
    'SELECT "earned_coupon_value already exists in orders";'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
