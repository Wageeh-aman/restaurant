-- =========================================================
-- Savoria — Invoice number & order number
-- Schema: add_invoice_number.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- Two numbers, two different jobs:
--
--   • INVOICE NUMBER — the permanent number of the order. It is the
--     order's own id: it never changes, never repeats and is never
--     reset, so it can be printed on a receipt and quoted to the
--     customer for years.
--
--   • ORDER NUMBER — the operational number the kitchen works with.
--     It is a sequence of its own that the manager can reset from the
--     admin panel (for a new service day, a new till, …). After a
--     reset the next order is order #1 and the counter counts up
--     again from there.
--
-- The invoice number therefore stays untouched when the order counter
-- is reset, and the order counter is the only thing the "Reset order
-- counter" button touches.
--
-- Existing orders keep their own id as both numbers, so the sequence
-- starts where the restaurant already is instead of jumping back.
--
--   mysql -u root -p savoria_app < database/add_invoice_number.sql
-- =========================================================

USE savoria_app;
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- ---------------------------------------------------------
-- 1. The order-number counter
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_counters (
    id            TINYINT UNSIGNED NOT NULL PRIMARY KEY DEFAULT 1,
    counter_name  VARCHAR(40) NOT NULL DEFAULT 'order',
    current_value INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO order_counters (id, counter_name, current_value) VALUES (1, 'order', 0);

-- The first version of this feature used a resettable counter for the
-- invoice number. It is replaced by the order counter above.
DROP TABLE IF EXISTS invoice_counters;

-- ---------------------------------------------------------
-- 2. The two columns on the orders
-- ---------------------------------------------------------
SET @db := DATABASE();

SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `orders` ADD COLUMN `invoice_number` INT UNSIGNED DEFAULT NULL AFTER `id`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'invoice_number');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE `orders` ADD COLUMN `order_number` INT UNSIGNED DEFAULT NULL AFTER `invoice_number`',
  'DO 0') FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'order_number');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------
-- 3. Existing orders
--
-- The invoice number is permanent: it IS the order's own id, so
-- every row is normalised to it (this also repairs rows that were
-- written by an earlier version of this feature).
--
-- The order number starts at the same place, so the two columns
-- agree until the manager resets the order counter by hand.
-- ---------------------------------------------------------
UPDATE orders SET invoice_number = id;
UPDATE orders SET order_number  = id WHERE order_number  IS NULL;

-- The counter continues from the highest number handed out so far.
UPDATE order_counters
   SET current_value = (SELECT COALESCE(MAX(order_number), 0) FROM orders)
 WHERE id = 1;
