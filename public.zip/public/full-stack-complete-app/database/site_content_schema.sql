-- =========================================================
-- Savoria — Website Content Management
-- Schema: site_content_schema.sql
-- Engine: MySQL 8.0+ / MariaDB 10.4+
--
-- Adds the tables that back the "Website Content Management"
-- section of the admin panel:
--   site_settings — editable storefront texts (key/value, typed)
--   site_images   — replaceable site images (custom + shipped default)
--   reviews       — the homepage testimonials
--
-- Safe to run on an existing database: every statement is
-- CREATE TABLE IF NOT EXISTS / INSERT IGNORE, so nothing that
-- already exists is modified or dropped.
--
--   mysql -u root -p savoria_app < database/site_content_schema.sql
-- =========================================================

USE savoria_app;

-- ---------------------------------------------------------
-- site_settings — one row per editable text on the website.
-- `restaurant_id` keeps the schema ready for a multi-restaurant
-- build; the current deployment uses restaurant_id = 1 only.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_settings (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT UNSIGNED NOT NULL DEFAULT 1,
    content_key   VARCHAR(80) NOT NULL,
    content_value TEXT DEFAULT NULL,
    content_group VARCHAR(40) NOT NULL DEFAULT 'general',
    updated_by    INT UNSIGNED DEFAULT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_site_settings_user
        FOREIGN KEY (updated_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    UNIQUE KEY uq_site_settings_key (restaurant_id, content_key),
    INDEX idx_site_settings_group (restaurant_id, content_group)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- site_images — one row per image slot on the website.
-- `image_url` holds the manager's upload; `default_url` keeps
-- the shipped image so it can always be restored.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_images (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT UNSIGNED NOT NULL DEFAULT 1,
    image_key     VARCHAR(80) NOT NULL,
    image_url     VARCHAR(500) DEFAULT NULL,
    default_url   VARCHAR(500) DEFAULT NULL,
    alt_text      VARCHAR(255) DEFAULT NULL,
    updated_by    INT UNSIGNED DEFAULT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_site_images_user
        FOREIGN KEY (updated_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    UNIQUE KEY uq_site_images_key (restaurant_id, image_key)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- reviews — homepage testimonials.
-- `source` keeps seeded demo content distinguishable from
-- genuine customer feedback, `status` drives visibility.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS reviews (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT UNSIGNED NOT NULL DEFAULT 1,
    author_name   VARCHAR(120) NOT NULL,
    author_meta   VARCHAR(160) DEFAULT NULL,
    author_avatar VARCHAR(500) DEFAULT NULL,
    rating        TINYINT UNSIGNED NOT NULL DEFAULT 5,
    content       TEXT DEFAULT NULL,
    source        ENUM('seed','customer','editorial') NOT NULL DEFAULT 'editorial',
    status        ENUM('published','pending','hidden') NOT NULL DEFAULT 'published',
    is_featured   BOOLEAN NOT NULL DEFAULT FALSE,
    display_order INT UNSIGNED NOT NULL DEFAULT 0,
    updated_by    INT UNSIGNED DEFAULT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_reviews_user
        FOREIGN KEY (updated_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_reviews_display (restaurant_id, status, is_featured, display_order)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Seed the three testimonials that are currently hard-coded in
-- the homepage, so the live site looks exactly the same after
-- the switch. They are flagged source='seed' (sample content)
-- so they can never be mistaken for verified customer reviews.
-- ---------------------------------------------------------
INSERT IGNORE INTO reviews
    (restaurant_id, author_name, author_meta, author_avatar, rating, content, source, status, is_featured, display_order)
VALUES
    (1, 'Hina R.', 'Regular guest, 3 years', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&q=80', 5,
     'Every course felt intentional. The lamb shank has genuinely ruined every other restaurant for me.',
     'seed', 'published', TRUE, 1),
    (1, 'Bilal S.', 'First-time customer', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&q=80', 5,
     'Ordered delivery on a whim through the site — it arrived hot, and the checkout took under a minute.',
     'seed', 'published', TRUE, 2),
    (1, 'Farah A.', 'Corporate events client', 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=100&q=80', 5,
     'Booked a table for eight on short notice through the site — smooth process, confirmed instantly.',
     'seed', 'published', TRUE, 3);
