-- =========================================================
-- Tarmez — Customer accounts & notification centre
--
-- Additive, idempotent upgrade for an EXISTING database.
-- Nothing is dropped and no existing row is modified destructively.
--
--   1. notifications        — one row per real event, per customer login
--   2. coupons.user_id      — the owning login (when one exists)
--   3. users.phone index    — speeds up phone-based login / duplicate check
--   4. Backfill             — links coupons already issued to a phone to
--                             that phone's existing customer login
--
-- Run with:
--   mysql -u root -p savoria_app < database/add_customer_accounts_notifications.sql
-- =========================================================

USE savoria_app;

DELIMITER $$

DROP PROCEDURE IF EXISTS tarmez_accounts_notifications $$
CREATE PROCEDURE tarmez_accounts_notifications()
BEGIN
    DECLARE db VARCHAR(64);
    SET db = DATABASE();

    /* -----------------------------------------------------
       1. notifications — customer notification centre
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS notifications (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id     INT UNSIGNED NOT NULL,
        type        ENUM('order','coupon','loyalty','account','reward','reservation') NOT NULL DEFAULT 'account',
        event_key   VARCHAR(64) NOT NULL,
        title       VARCHAR(160) NOT NULL,
        title_ar    VARCHAR(160) DEFAULT NULL,
        body        VARCHAR(500) DEFAULT NULL,
        body_ar     VARCHAR(500) DEFAULT NULL,
        link_type   VARCHAR(24) DEFAULT NULL,
        link_id     INT UNSIGNED DEFAULT NULL,
        dedupe_key  VARCHAR(190) DEFAULT NULL,
        is_read     TINYINT(1) NOT NULL DEFAULT 0,
        read_at     DATETIME DEFAULT NULL,
        created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_notification_dedupe (dedupe_key),
        KEY idx_notification_user (user_id, is_read, created_at),
        CONSTRAINT fk_notification_user
            FOREIGN KEY (user_id) REFERENCES users(id)
            ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB;

    /* Installations created before reservations existed still have the
       original five-value ENUM, so widen it in place. */
    ALTER TABLE notifications
        MODIFY COLUMN type ENUM('order','coupon','loyalty','account','reward','reservation') NOT NULL DEFAULT 'account';

    /* -----------------------------------------------------
       2. coupons.user_id — the login that owns the coupon
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'coupons'
          AND column_name = 'user_id') = 0
    THEN
        ALTER TABLE coupons
            ADD COLUMN user_id INT UNSIGNED DEFAULT NULL AFTER loyalty_account_id;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.statistics
        WHERE table_schema = db AND table_name = 'coupons'
          AND index_name = 'idx_coupon_user') = 0
    THEN
        ALTER TABLE coupons ADD KEY idx_coupon_user (user_id);
    END IF;

    /* -----------------------------------------------------
       3. users.phone index (not UNIQUE: legacy rows may repeat)
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.statistics
        WHERE table_schema = db AND table_name = 'users'
          AND index_name = 'idx_users_phone') = 0
    THEN
        ALTER TABLE users ADD KEY idx_users_phone (phone);
    END IF;

    /* -----------------------------------------------------
       4. Backfill: coupons issued to a phone now follow that
          phone's customer login. Only empty user_id rows are set.
       ----------------------------------------------------- */
    UPDATE coupons c
    JOIN users u
      ON u.role = 'customer'
     AND RIGHT(REGEXP_REPLACE(COALESCE(u.phone, ''), '[^0-9]', ''), 10)
       = RIGHT(REGEXP_REPLACE(COALESCE(c.phone, ''), '[^0-9]', ''), 10)
     AND RIGHT(REGEXP_REPLACE(COALESCE(u.phone, ''), '[^0-9]', ''), 10) <> ''
    SET c.user_id = u.id
    WHERE c.user_id IS NULL
      AND c.phone IS NOT NULL
      AND c.phone <> '';

END $$

DELIMITER ;

CALL tarmez_accounts_notifications();
DROP PROCEDURE tarmez_accounts_notifications;

SELECT 'Customer accounts & notifications upgrade applied.' AS status;
SHOW TABLES LIKE 'notifications';
SHOW COLUMNS FROM coupons LIKE 'user_id';
