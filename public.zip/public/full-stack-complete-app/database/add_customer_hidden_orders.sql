-- =========================================================
-- Tarmez — customer-dismissed order cards
--
-- The × button on an order in the customer account hides that order and
-- its notifications for that one account. Management still sees the order.
--
-- Additive and idempotent. The backend also creates this table on first
-- use, so running this file is optional.
--
--   mysql -u root -p savoria_app < database/add_customer_hidden_orders.sql
-- =========================================================

USE savoria_app;

CREATE TABLE IF NOT EXISTS customer_hidden_orders (
    user_id    INT UNSIGNED NOT NULL,
    order_id   INT UNSIGNED NOT NULL,
    hidden_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, order_id),
    INDEX idx_customer_hidden_order (order_id),
    CONSTRAINT fk_customer_hidden_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_customer_hidden_order
        FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;
