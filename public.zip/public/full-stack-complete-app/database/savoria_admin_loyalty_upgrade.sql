-- =========================================================
-- Savoria — Full-Stack Complete App
-- Upgrade: Site Management, Loyalty & Points, Accounts
--
-- Safe/idempotent upgrade for an EXISTING savoria_app database.
-- Re-running this file is harmless: every change is wrapped in
-- an IF EXISTS / IF NOT EXISTS guard.
--
-- Adds:
--   1. users      — new roles (cashier, super_admin) + forced password change flag
--   2. categories — visibility flag + image
--   3. orders     — payment method, processed_by, points_discount
--   4. loyalty_settings   — one editable row of loyalty rules
--   5. loyalty_accounts   — phone-keyed customer loyalty balances
--   6. loyalty_transactions — full points ledger (earn/redeem/adjust/reverse)
--   7. admin_audit_log    — audit trail for sensitive admin actions
-- =========================================================

USE savoria_app;

DELIMITER $$

DROP PROCEDURE IF EXISTS savoria_upgrade_procedure $$
CREATE PROCEDURE savoria_upgrade_procedure()
BEGIN
    DECLARE db VARCHAR(64);
    SET db = DATABASE();

    /* -----------------------------------------------------
       1. users — extend role enum + forced password change
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'users' AND column_name = 'force_password_change') = 0
    THEN
        ALTER TABLE users
            ADD COLUMN force_password_change BOOLEAN NOT NULL DEFAULT FALSE AFTER is_active;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'users' AND column_name = 'role'
          AND column_type = "enum('customer', 'staff', 'admin')") = 0
    THEN
        ALTER TABLE users
            MODIFY COLUMN role ENUM('customer','staff','admin','cashier','super_admin')
            NOT NULL DEFAULT 'customer';
    END IF;

    /* The original seeded admin becomes the Super Admin. */
    UPDATE users SET role = 'super_admin' WHERE email = 'admin@savoria.example' AND role = 'admin';

    /* -----------------------------------------------------
       2. categories — visibility + image
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'categories' AND column_name = 'is_visible') = 0
    THEN
        ALTER TABLE categories ADD COLUMN is_visible BOOLEAN NOT NULL DEFAULT TRUE AFTER sort_order;
        ALTER TABLE categories ADD INDEX idx_categories_visible (is_visible);
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'categories' AND column_name = 'image_url') = 0
    THEN
        ALTER TABLE categories ADD COLUMN image_url VARCHAR(500) DEFAULT NULL AFTER is_visible;
    END IF;

    /* -----------------------------------------------------
       3. orders — payment method, processed_by, points_discount
       ----------------------------------------------------- */
    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'orders' AND column_name = 'payment_method') = 0
    THEN
        ALTER TABLE orders ADD COLUMN payment_method VARCHAR(30) DEFAULT NULL
            AFTER status;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'orders' AND column_name = 'processed_by') = 0
    THEN
        ALTER TABLE orders ADD COLUMN processed_by INT UNSIGNED DEFAULT NULL
            AFTER payment_method;
        ALTER TABLE orders
            ADD CONSTRAINT fk_orders_processed_by
            FOREIGN KEY (processed_by) REFERENCES users(id)
            ON DELETE SET NULL ON UPDATE CASCADE;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'orders' AND column_name = 'points_discount') = 0
    THEN
        ALTER TABLE orders ADD COLUMN points_discount DECIMAL(10,2) NOT NULL DEFAULT 0.00
            AFTER discount_amount;
    END IF;

    IF (SELECT COUNT(*) FROM information_schema.columns
        WHERE table_schema = db AND table_name = 'orders' AND column_name = 'order_notes') = 0
    THEN
        ALTER TABLE orders ADD COLUMN order_notes VARCHAR(255) DEFAULT NULL
            AFTER table_number;
    END IF;

    /* -----------------------------------------------------
       4. loyalty_settings — single editable rules row
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS loyalty_settings (
        id                   TINYINT UNSIGNED NOT NULL PRIMARY KEY DEFAULT 1,
        enabled              BOOLEAN NOT NULL DEFAULT TRUE,
        earn_amount_per_point DECIMAL(10,2) NOT NULL DEFAULT 10.00 CHECK (earn_amount_per_point > 0),
        earn_min_order_amount DECIMAL(10,2) NOT NULL DEFAULT 500.00 CHECK (earn_min_order_amount >= 0),
        redeem_min_points    INT UNSIGNED NOT NULL DEFAULT 100 CHECK (redeem_min_points > 0),
        redeem_point_value   DECIMAL(10,2) NOT NULL DEFAULT 1.00 CHECK (redeem_point_value >= 0),
        updated_by           INT UNSIGNED DEFAULT NULL,
        updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_loyalty_settings_user
            FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE
    ) ENGINE=InnoDB;

    INSERT IGNORE INTO loyalty_settings (id) VALUES (1);

    /* -----------------------------------------------------
       5. loyalty_accounts — phone-keyed balance per customer
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS loyalty_accounts (
        id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        phone           VARCHAR(15) NOT NULL UNIQUE,
        customer_name   VARCHAR(120) DEFAULT NULL,
        points_balance  INT NOT NULL DEFAULT 0 CHECK (points_balance >= 0),
        total_earned    INT NOT NULL DEFAULT 0,
        total_redeemed  INT NOT NULL DEFAULT 0,
        total_adjusted  INT NOT NULL DEFAULT 0,
        total_reversed  INT NOT NULL DEFAULT 0,
        created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;

    /* -----------------------------------------------------
       6. loyalty_transactions — immutable points ledger
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS loyalty_transactions (
        id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        loyalty_account_id    INT UNSIGNED NOT NULL,
        order_id              INT UNSIGNED DEFAULT NULL,
        type                  ENUM('earn','redeem','adjust','reverse') NOT NULL,
        points_delta          INT NOT NULL,
        points_balance_after  INT NOT NULL,
        qualified_amount      DECIMAL(10,2) DEFAULT NULL,
        cash_value            DECIMAL(10,2) DEFAULT NULL,
        reason                VARCHAR(255) DEFAULT NULL,
        created_by            INT UNSIGNED DEFAULT NULL,
        created_by_name       VARCHAR(120) DEFAULT NULL,
        created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_tx_account
            FOREIGN KEY (loyalty_account_id) REFERENCES loyalty_accounts(id)
            ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT fk_tx_order
            FOREIGN KEY (order_id) REFERENCES orders(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        CONSTRAINT fk_tx_user
            FOREIGN KEY (created_by) REFERENCES users(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        /* Core double-count protection: 'earn' and 'reverse' rows for a
           given order get a generated unique key, so an order can never
           be accrued (or reversed) twice no matter how many code paths
           race. Redeem/adjust rows are not constrained — points spent
           are spent immediately, so they can never double-spend. */
        order_op_key VARCHAR(32) GENERATED ALWAYS AS (
            IF(order_id IS NULL OR type NOT IN ('earn','reverse'), NULL, CONCAT(type, '#', order_id))
        ) STORED,
        CONSTRAINT uq_tx_order_op UNIQUE (order_op_key),
        INDEX idx_tx_account_date (loyalty_account_id, created_at),
        INDEX idx_tx_order (order_id)
    ) ENGINE=InnoDB;

    /* -----------------------------------------------------
       7. admin_audit_log — sensitive admin action history
       ----------------------------------------------------- */
    CREATE TABLE IF NOT EXISTS admin_audit_log (
        id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id      INT UNSIGNED DEFAULT NULL,
        actor_name   VARCHAR(120) DEFAULT NULL,
        action       VARCHAR(60) NOT NULL,
        entity_type  VARCHAR(40) DEFAULT NULL,
        entity_id    VARCHAR(40) DEFAULT NULL,
        details      TEXT DEFAULT NULL,
        ip_address   VARCHAR(45) DEFAULT NULL,
        created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_audit_user
            FOREIGN KEY (user_id) REFERENCES users(id)
            ON DELETE SET NULL ON UPDATE CASCADE,
        INDEX idx_audit_action (action),
        INDEX idx_audit_date (created_at)
    ) ENGINE=InnoDB;
END $$

DELIMITER ;

CALL savoria_upgrade_procedure();
DROP PROCEDURE savoria_upgrade_procedure;

SELECT 'Upgrade applied — verifying tables:' AS status;
SHOW TABLES;
