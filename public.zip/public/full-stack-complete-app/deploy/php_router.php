<?php
/**
 * Single-origin router for the PHP built-in server (demo / tunnel).
 *
 *   C:/xampp/php/php.exe -S 127.0.0.1:8003 -t frontend deploy/php_router.php
 *
 * Static files are served from frontend/; /api/* is handed to
 * backend/index.php so the browser sees one origin (no CORS).
 */

declare(strict_types=1);

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

if ($uri === '/api' || str_starts_with($uri, '/api/')) {
    $_SERVER['REQUEST_URI'] = substr($uri, 4) ?: '/';
    $_SERVER['SCRIPT_NAME'] = '/index.php';
    require __DIR__ . '/../backend/index.php';
    return true;
}

$root = realpath(__DIR__ . '/../frontend');
$file = realpath($root . $uri);

if ($uri === '/' || ($file !== false && is_file($file) && str_starts_with($file, $root . DIRECTORY_SEPARATOR))) {
    return false;
}

http_response_code(404);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['success' => false, 'message' => 'Not found.']);
return true;
