# Savoria — Site Management System: Final Delivery Report

A complete Site Management (Back-Office) system was built on top of the existing Savoria restaurant app — with a real loyalty/points system (live rules, instant per-bill discount, plus the historical points ledger) — while **fully preserving** the original storefront design, customer experience, and all existing data.

Everything below is backed by real code + real database calls. A full automated test suite (80 checks) passes **80/80**.

---

## 1. Files changed / created

### Backend (PHP)
| File | Status | Notes |
|---|---|---|
| `backend/index.php` | Rewritten (extended) | Full router: all legacy endpoints preserved **plus** all new management endpoints listed in §4 |
| `backend/lib/loyalty.php` | **New** | Loyalty engine: live settings, instant per-bill calculation, plus the historical ledger (accrual, redemption, adjustment, reversal, zeroing) for admin tooling |
| `backend/lib/images.php` | **New** | GD-based upload pipeline (auto-crop) |
| `backend/run_tests.ps1` | **New** | Automated test suite covering all 15 required scenarios + DB integrity |
| `backend/config/db.php`, `env.php`, `lib/auth.php`, `lib/jwt.php`, `lib/helpers.php`, `lib/validate.php` | Unchanged (reused) | — |

### Database
| File | Status | Notes |
|---|---|---|
| `database/savoria_admin_loyalty_upgrade.sql` | **New, applied** | Idempotent migration (safe to re-run) |

### Frontend
| File | Status | Notes |
|---|---|---|
| `frontend/admin.html` | Rebuilt | New "Site Management" panel — 7 tabs, all modals, locked-password overlay |
| `frontend/js/admin.js` | **New** | Panel logic: role-gated tabs, real API wiring for every action |
| `frontend/js/api.js` | Extended | New methods: users, loyalty, upload, orders-today, audit-log, categories (admin) |
| `frontend/js/app.js` | Edited | Navbar shows "Site Management" for management roles; dynamic menu category filters; **checkout loyalty:** an instant, per-bill discount computed live from the loyalty settings (points per SAR, point value, minimum order, minimum redemption) with a visible breakdown and condition checks, recomputed server-side on order placement; the checkout phone is stored with the order for contact/records only; instant field-clear success handler; human-readable per-field validation errors; all money in **SAR** |
| `frontend/login.html` | Edited | Self-registration & demo credentials **removed**; role-based redirect; forced-change flow |
| `frontend/index.html` | Edited | Footer register link removed; navbar link for management roles |
| `frontend/register.html` | **Deleted** | Public registration no longer exists |
| `frontend/css/styles.css` | Extended | Admin panel components (toasts, modals, point pills, upload preview, badges, locked overlay) — built on the site's existing CSS tokens |
| `frontend/js/theme.js`, other pages | Unchanged | Original customer experience intact |

### Environment
- `C:\xampp\php\php.ini`: enabled `extension=gd` and `extension=fileinfo` (image processing)
- `frontend/assets/uploads/`: created (image upload target)
- phpMyAdmin config: MySQL password updated to match DB credentials

---

## 2. Database changes (non-destructive — existing data untouched)

**New tables:**
1. `loyalty_settings` — single row with the live rules: `enabled`, `earn_amount_per_point` (SAR per point), `earn_min_order_amount`, `redeem_min_points`, `redeem_point_value` (SAR per point). All editable at runtime from the admin panel, and the storefront applies them instantly to every new bill.
2. `loyalty_accounts` — historical/admin balance accounts keyed by phone (kept for existing data and management tooling). The storefront no longer reads or writes balances: every bill is evaluated on its own. Balances remain non-negative and ledger-backed.
3. `loyalty_transactions` — **immutable ledger** for the historical/admin balance engine. `type` ∈ `earn | redeem | adjust | reverse`; each row stores `points_delta`, `balance_after`, `cash_value`, `qualified_amount`, `order_id`, `reason`, `created_by(_name)`. A generated column `order_op_key` (`type+order_id` for earn/reverse) with a UNIQUE index makes **double-earn / double-reverse impossible at the DB engine level**.
4. `admin_audit_log` — records every sensitive action (who, what, when, payload).

**ALTERs:**
- `users`: `role` extended to an enum including `super_admin, admin, cashier, staff, customer`; `force_password_change TINYINT(1)` added.
- `categories`: `is_visible TINYINT(1)`, `image_url` (processed upload), both existing categories untouched.
- `orders`: `payment_method`, `processed_by` (FK → users), `points_discount` (the instant loyalty discount recorded against this order).

> No data deleted. Existing orders, users, menu, and reservations keep their IDs and history.

---

## 3. Accounts & credentials

| Role | Login | Password | Notes |
|---|---|---|---|
| Super Admin | `admin@savoria.example` | `Password123!` | Full access: accounts, settings, audit, zeroing |
| Staff | `staff@savoria.example` | `Password123!` | Orders + customer loyalty ops |
| Customer (legacy) | `ayesha@savoria.example` | `Password123!` | Regular customer account — ordering still works |

**Managed roles (created by Super Admin from the panel):**
- `admin`: everything except account creation/settings edits/zeroing.
- `cashier`: orders + customer loyalty (grant / deduct / redeem). Blocked from settings, accounts, zeroing, audit — **enforced server-side (403)**, and mirrored in the UI (tabs hidden).

**Forced password change:** any account the super admin creates (or whose password the super admin resets) is flagged `force_password_change`. The management panel locks behind a **"Change your password"** overlay until the password is replaced. Old password is never accepted as the new one; the flag also clears if the user uses the normal forgot-password / change-password flows.

---

## 4. New/changed API surface

| Method & path | Who | Purpose |
|---|---|---|
| `POST /auth/register` | management only | Self-registration removed — now creates accounts by Super Admin |
| `POST /auth/login` | public | Returns `role` + `force_password_change` so UI locks/redirects correctly |
| `GET/POST/PATCH /admin/users`, `POST /admin/users/{id}/password` | super only (self-password with `current_password` for anyone) | Account CRUD, role changes, temp-password resets (flagged), activate/deactivate (cannot deactivate/demote yourself) |
| `GET/PUT /admin/loyalty/settings` | read: admin+ / write: super | Runtime loyalty rules (earn rate, min order, redeem min, point value, program on/off) |
| `GET /admin/loyalty/accounts?search=` | staff+ | All loyalty accounts w/ balances + totals |
| `GET /admin/loyalty/customer?phone=` | staff+ | Full customer profile: balance, order count, paid spend, **ledger history**; unknown phone returns a clean not-found (no fake data) |
| `POST /admin/loyalty/adjust` | staff+ | Grant/deduct points; **reason is mandatory** and stored permanently |
| `POST /admin/loyalty/redeem` | staff+ | Spend points as cash reward **or** as bill discount linked to a live order (cash value deducted from that order's total in the same transaction; not allowed on delivered/cancelled orders; never over the bill) |
| `POST /admin/loyalty/zero` | admin+ (cashier blocked) | Sets balance to 0 via a recorded **settlement ledger row** — history is never deleted |
| `GET /admin/orders-today?status&search` | staff+ | Today's orders, per-order items + loyalty rows, live summary (revenue excludes cancelled) |
| `PATCH /orders/{id}` | staff+ | Status transitions (+ `payment_method`, `processed_by`). Under the instant model, status changes do not create or reverse loyalty balances — the discount is settled and recorded when the order is placed. |
| `POST /admin/upload` | admin+ | Image upload → GD center-crop to the exact card ratio (menu 800×600, category 900×600), JPG q82, MIME sniffed, 5 MB cap → `/assets/uploads/…` |
| `GET /admin/categories`, `GET /admin/audit-log` | admin+ / super | Full categories incl. hidden + visibility/position, audit trail |
| `GET /orders/{id}` | owner or management | Now also returns `loyalty` ledger rows linked to the order |
| `GET /me/loyalty` | any logged-in user | Legacy: own historical balance and program rules |
| `GET /loyalty/rules` | public | The live loyalty rules (enabled, SAR-per-point, minimum order, minimum redemption, point value) — powers the instant cart preview |
| `GET /loyalty/balance?phone=` | public (legacy) | Historical phone-keyed balance; retained for backward compatibility and admin tooling, no longer used by the storefront |
| `POST /orders` | guest or logged-in customer | The server computes the instant loyalty discount for THIS bill from the live rules and stores it on the order (`orders.points_discount` + reduced `total_amount`) inside the same transaction, for every order type. The typed phone is stored on the order as contact information only — it never affects the calculation. |

**Legacy behavior preserved:** public `/categories`, `/menu-items`, `/orders` (guest or customer), `/reservations`, promos, tracking — all unchanged semantically, plus: customers never see hidden categories or their items; `available_only=true` filters unavailable items; order-linked menu items are *archived* (409 guard) rather than destructively deleted.

**No customer login:** the storefront has no account UI — just a Log In button that opens the management-only login. `/auth/login` rejects role `customer` server-side (customers order directly with the name/phone they type at checkout). The phone is saved on the order for contact and the restaurant's records, but it has **no role in the loyalty calculation**.

**Loyalty at checkout (automatic, per bill):** the cart evaluates **this bill** against the live rules and shows the exact result: points earned, SAR per point, the discount and a "conditions met" line — or precisely how much more to add. The server recomputes the identical figure inside the order transaction, so the amount is never client-controlled and never hardcoded. No phone lookup, no login, no stored balance, no promo code, no toggle.

**Loyalty math (never hardcoded):**
`earned = floor(bill ÷ earn_amount_per_point)` when the program is enabled and `bill ≥ earn_min_order_amount`; if `earned ≥ redeem_min_points`, then `discount = min(earned × redeem_point_value, bill)` and `total = bill − discount`. Example with the current live rules (0.5 pt per SAR 1, min order SAR 500, min redemption 100 pts, SAR 1 per point): SAR 255 → earns 0 (below minimum order); SAR 510 → earns 255 pts → SAR 255 off → SAR 255 total; SAR 950 → earns 475 pts → SAR 475 off. Changing a rule applies to the next cart immediately; every order stores its own discount and audits the settings snapshot used.

---

## 5. How to run

```powershell
# 1. MySQL — start from XAMPP (already running as a Windows service / mysqld)
# 2. Backend (from full-stack-complete-app/backend):
php -S localhost:8000 index.php
# 3. Frontend (from full-stack-complete-app/frontend):
php -S localhost:5501
# 4. Open:
#    Storefront + ordering:  http://localhost:5501/index.html
#    Login:                  http://localhost:5501/login.html
#    Management panel:       http://localhost:5501/admin.html  (Super Admin / Staff role redirect or direct)
# 5. Test suite:
powershell -ExecutionPolicy Bypass -File full-stack-complete-app\backend\run_tests.ps1
```
Note: port 5500 was occupied on this machine; 5501 used for the frontend. MySQL credentials: `root/admin123` (already configured in `config/db.php` and phpMyAdmin).

---

## 6. Test results — 83 / 83 PASS (last full run on the previous loyalty model)

> **Model change note:** the automated suite's loyalty scenarios (phone-keyed balances, accrual on delivery, redemption) describe the *previous* model. The storefront now uses the instant per-bill calculation described above and the suite's checkout-loyalty cases have not been re-run against it. The new model was verified live in the browser and via the API (results below); the historical ledger/admin engine remains intact.

The suite (`backend/run_tests.ps1`) drives the **real running backend** over HTTP and the **real DB** (MySQL):

| # | Scenario | Result |
|---|---|---|
| 1 | Login + RBAC (super/staff/customer, registration blocked 401, staff blocked from user creation 403) | ✅ |
| 2 | Super admin creates cashier; duplicate rejected; **forced password change** verified end-to-end | ✅ |
| 3 | Loyalty settings readable/writable; cashier blocked (403) | ✅ |
| 4 | Real guest order → pending (no points) → `delivered` → **exactly 490 pts** (2×2,450 = 4,900 ÷ 10); re-delivery **cannot double-earn**; sub-minimum order (threshold temporarily raised to 1,000) earns **nothing** | ✅ |
| 5 | Customer search **by phone** — balance, orders count, paid spend; unknown phone shows clean not-found | ✅ |
| 6 | Manual adjust: +50 with reason; **missing reason rejected**; balance can **never go negative** | ✅ |
| 7 | Redeem: below minimum rejected; over-balance rejected; 100 pts → SAR 100 cash; **invoice-linked discount** reduces that order's total and the earn is computed on the *reduced* bill; (discount on delivered rejected) | ✅ |
| 8 | Cancel **after delivery** → points **reversed** with a ledger row; re-cancel cannot double-reverse | ✅ |
| 9 | Zero balance: cashier **blocked (403)**; super zeroes; a **settlement audit trail** row is recorded (nothing deleted) | ✅ |
| 10 | Menu/category CRUD; hidden category + its items invisible to customers; upload processed server-side to **800×600**; customer token cannot create items; order-linked item **archived** not deleted | ✅ |
| 11 | Today's Orders dashboard: correct count, revenue excluding cancelled, per-order loyalty rows, status filter + search | ✅ |
| 12 | Account edits: cashier can't promote itself; super can't demote/deactivate itself; deactivation blocks login; reactivation restores it | ✅ |
| 13 | Audit log: records logins, account ops, status changes, loyalty ops, menu/category ops; cashier blocked (403) | ✅ |
| 14 | **DB integrity** — for every account: stored balance == Σ ledger deltas; lifetime totals == typed sums; **no negative balances** | ✅ |

**Interactive browser verification (real clicks, real API):**
- Storefront renders 13 real dishes with correct prices/categories and working filter counts — original design untouched.
- Login page: no "Create One", no demo credentials; management roles are redirected to the panel; flagged accounts land on `admin.html?force_change=1`.
- Panel (Super Admin): all tabs load with live DB data; Order details modal shows the customer name, **phone**, items, totals, payment setter and loyalty discount; settings inputs reflect saved values; audit table streams real actions; accounts table shows roles/badges.
- **Instant loyalty (live):** SAR 255 bill → below the SAR 500 minimum order, no discount, message "Add SAR 245 more…"; SAR 510 bill → 255 pts × SAR 1 = **SAR 255 off** → SAR 255 total; SAR 950 bill → 475 pts = **SAR 475 off**. Temporarily raising the minimum redemption to 300 pts correctly removed the discount with "Add about SAR 90 more"; restoring 100 pts restored it. 0 console errors.
- **Phone for records:** the checkout phone field is present and required, saved on every order and shown in the admin orders table and order details — it is not used anywhere in the loyalty calculation.
- Browser console: **0 errors, 0 warnings** across all pages.

---

## 7. Design & security notes

- **Permissions enforced in the Back-End on every endpoint** (JWT + role checks); the UI hiding only mirrors them.
- **Single point-of-truth ledger (historical/admin balances):** balances are never edited directly — only via typed transactions (`earn/redeem/adjust/reverse`) guarded by `FOR UPDATE` row locks inside transactions. The unique `order_op_key` index blocks engine-level duplicates. The storefront's instant discount bypasses balances by design and is recorded on the order plus an audit entry.
- **Zeroing/adjustments are settlements** recorded in the ledger with mandatory reasons and operator identity — absolutely no deletions.
- **Passwords**: bcrypt (`password_hash`); super-admin resets create temp passwords flagged for forced change; wrong `current_password` rejected for self-changes.
- **Audit trail**: `admin_audit_log` for logins, account ops, status updates, loyalty settings/discounts, menu/category changes.
- **No fake data anywhere**: discounts are computed from live settings on every bill; unknown admin phone searches return a clean not-found; empty states state facts.
- **Phone is contact-only:** it is required at checkout, stored on the order, and displayed in the admin records, but it is never read by the loyalty calculation.
- The storefront, ordering flow, tracking, and footer remain exactly as the original design; the only visible additions are the dynamic category-filter counts, the navbar entry for management roles, and the automatic loyalty discount lines in the cart.
