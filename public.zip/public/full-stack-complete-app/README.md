# 🛎️  Savoria — Full-Stack Complete App

The complete, deployable Savoria application — combining the static frontend (Project 1), the ordering domain and MySQL integration (Project 3), and JWT authentication with RBAC (Project 4) into a single working restaurant platform.

## 📁 Structure

```
full-stack-complete-app/
├── database/
│   └── savoria_full_schema.sql   # Combined schema: users, menu, orders, reservations
├── backend/                       # PHP + MySQL (PDO) REST API — see backend/README.md
└── frontend/                      # Live site: menu, cart, checkout, reservations, auth — see frontend/README.md
```

## ⚙️ Quick Start

```bash
# 1. Create and seed the database
mysql -u root -p < database/savoria_full_schema.sql
# Existing database already created from an earlier version? Run the safe upgrade too:
mysql -u root -p < database/savoria_admin_loyalty_upgrade.sql
# Website Content Management tables (site_settings, site_images, reviews):
mysql -u root -p < database/site_content_schema.sql

# 2. Start the backend API
cd backend
cp .env.example .env   # edit with your DB credentials + a strong JWT_SECRET
php -S localhost:8000 index.php

# 3. In a new terminal, serve the frontend
cd ../frontend
python3 -m http.server 8080
```

Visit **http://localhost:8080**.

Demo accounts (password `Password123!` for all): `admin@savoria.example`, `staff@savoria.example`, `ayesha@savoria.example`.

## 🗂️ Website Content Management

The **Website Content** tab in the Site Management panel (`admin.html` → *Website Content*) lets the restaurant owner change everything the public website shows — without touching the code:

| Sub-section | What it manages |
|---|---|
| Restaurant Info | Name, page title, SEO description, hero eyebrow / headline / intro / buttons / rating badge / stats |
| Website Images | Logo, hero photos, story photos and the five gallery images — uploaded, previewed and crop-fitted to the exact ratio of each slot, with "use default" restore |
| Our Story | Section eyebrow, headline, story paragraph and the three highlight points |
| Contact & Hours | Address, phones, email, Google Maps link, opening-hours rows, contact card text and the social links |
| Reviews | The homepage testimonials — visibility, order, rating, text, avatar and a clear "seed content" marker so sample reviews are never passed off as real guest feedback |
| Website Texts | Menu / reservation / reviews section headings and the footer copy |

Everything is stored in MySQL (`site_settings`, `site_images`, `reviews`) and served to visitors through `GET /site-content`. The shipped defaults stay in `backend/lib/site_content.php`, so a section that was never customised looks exactly as it did before — and "Restore defaults" puts it back in one click. Only `super_admin` and `admin` accounts can reach these endpoints; the server rejects everyone else even if they call the API directly.

## 🧭 What You Can Do

- Browse the live menu, filter by category, add dishes to a cart
- Check out as a guest or while logged in — orders are priced and validated server-side
- Book a table through the reservation form
- Register/log in and see an auth-aware navbar (account menu + role badge)
- As `staff`/`admin`: manage order status and reservations via the API
- As `admin`: create/edit/delete menu items and change user roles via the API

## 🔗 How This Relates to Projects 1–4

| Project | What it demonstrates | Present here as |
|---|---|---|
| 1 — Static Frontend | HTML/CSS/JS fundamentals, responsive design | The visual foundation of `frontend/` |
| 2 — JSON API | REST routing without a database | (superseded by Project 3's approach) |
| 3 — Database Integration | MySQL + PDO, transactions, prepared statements | Core of `backend/index.php` |
| 4 — Auth & Authorization | JWT, RBAC, bcrypt | Auth routes + middleware in `backend/` |

Each numbered project remains a standalone, focused submission; this folder shows how they come together in a single production-style app.
